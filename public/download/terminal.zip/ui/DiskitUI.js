//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
import {btnIcon} from "../gear/btnIcon.js";
/*#{1FBR233GG0Imports*/
import {UIConsole} from "../gear/UIConsole.js";
/*}#1FBR233GG0Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var DiskitUI=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FBR233GG1ExLocal*/
	/*}#1FBR233GG1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FBR233GG3ExState*/
		/*}#1FBR233GG3ExState*/
	},);
	/*#{1FBR233GG1PostState*/
	/*}#1FBR233GG1PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FBR233GG1", 
		"locked": 1, "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, 
		items: [
			{
				"type": "box", "jaxId": "1FBR2S8SB0", "id": "BoxList", "x": 0, "y": appCfg.size.headerH, "w": "FW", "h": "FH-"+(appCfg.size.headerH+appCfg.size.stateBoxH), 
				"color": appCfg.color.window, "shadowColor": [0,0,0,0.5], 
				items: [
					{
						"type": "box", "jaxId": "1FBR5JL960", "id": "BoxListHead", "x": 0, "y": 1, "w": "FW", "h": appCfg.size.listHeadH, "color": appCfg.color.headBox, 
						"shadowColor": [0,0,0,0.5], 
						items: [
							{
								"type": "box", "jaxId": "1FBR5C1N60", "id": "BtmLine", "x": 0, "y": appCfg.size.listHeadH, "w": "FW", "h": 1, "autoLayout": 1, "color": 787878, 
								"shadowColor": [0,0,0,0.5]
							},
							{
								"type": "box", "jaxId": "1FBR5F4TH0", "id": "TopLine", "x": 0, "y": 0, "w": "FW", "h": 1, "autoLayout": 1, "color": [255,255,255,1], "shadowColor": [0,0,0,0.5]
							},
							{
								"type": "text", "jaxId": "1FM3LE7810", "id": "TxtPath", "x": 10, "y": 0, "w": 100, "h": 24, "text": "/coke/", "color": [0,0,0], "alignV": 1, "fontSize": appCfg.txtSize.mid
							}
						]
					},
					{
						"type": "dock", "jaxId": "1FF4L6KQ00", "id": "DKConsoles", "x": 0, "y": appCfg.size.listHeadH, "w": "FW", "h": "FH-"+appCfg.size.listHeadH, "ui": -1
					}
				]
			},
			{
				"type": "box", "jaxId": "1FBR26ACL0", "id": "BoxHead", "x": 0, "y": 0, "w": "FW", "h": appCfg.size.headerH, "autoLayout": 1, "color": appCfg.color.headBox, 
				"shadowColor": [0,0,0,0.5], 
				items: [
					{
						"type": "box", "jaxId": "1FBR2C50N0", "id": "BtmLine", "x": 0, "y": appCfg.size.headerH, "w": "FW", "h": 1, "autoLayout": 1, "color": 787878, "shadowColor": [0,0,0,0.5]
					},
					{
						"type": "hud", "jaxId": "1FBR4H3UE0", "id": "BoxHeadNavi", "x": 0, "y": 0, "w": "FW", "h": "FH", 
						items: [
							{
								"type": "box", "jaxId": "1FBR4H3UF0", "x": 3, "y": 3, "w": 1, "h": "FH-6", "color": [150,150,150,1], "shadowColor": [0,0,0,0.5]
							},
							{
								"type": btnIcon(app,24,"diskadd.svg",null),"jaxId": "1FBR4H3UF3", 
								"locked": 0, "id": "BtnNewDisk", "x": 6, "y": "(FH-24)/2", "tip": "Add new disk", 
								//函数
								OnClick:function(){
									/*#{1FC2G7GMM0Code*/
									/*}#1FC2G7GMM0Code*/
								}
							},
							{
								"type": btnIcon(app,24,"trash.svg",null),"jaxId": "1FBR4KQEH0", 
								"locked": 0, "id": "BtnNaviDel", "x": 54, "y": "(FH-24)/2", "tip": "Delete item", 
								//函数
								OnClick:function(){
									/*#{1FBR50B8K4Code*/
									/*}#1FBR50B8K4Code*/
								}
							},
							{
								"type": btnIcon(app,24,"diskdownload.svg",null),"jaxId": "1FC2R95CR0", 
								"locked": 0, "id": "BtnDownloadDisk", "x": 30, "y": "(FH-24)/2", "tip": "Download disk as zip", 
								//函数
								OnClick:function(){
									/*#{1FC2R95CR4Code*/
									/*}#1FC2R95CR4Code*/
								}
							}
						]
					}
				]
			},
			{
				"type": "box", "jaxId": "1FBR439899", "id": "BoxState", "x": 0, "y": "FH", "w": "FW", "h": appCfg.size.stateBoxH, "anchorV": 2, "autoLayout": 1, "color": appCfg.color.stateBox, 
				"shadowColor": [0,0,0,0.5], 
				items: [
					{
						"type": "text", "jaxId": "1FBR4H3UF8", "id": "TxtState", "x": 10, "y": 0, "w": 100, "h": 24, "text": "Ready.", "color": [0,0,0], "alignV": 1, "fontSize": appCfg.txtSize.small
					},
					{
						"type": "box", "jaxId": "1FBR46FJ50", "id": "Line", "x": 0, "y": -1, "w": "FW", "h": 1, "color": [150,150,150,1], "shadowColor": [0,0,0,0.5]
					}
				]
			}
		],
		faces: {
		},
		/*#{1FBR233GG1ExAttrs*/
		/*}#1FBR233GG1ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FBR233GG1CreateFunc*/
			let cssVO;
			app.mainUI=this;
			cssVO=UIConsole(app);
			this.DKConsoles.showNewUI(cssVO);
			/*}#1FBR233GG1CreateFunc*/
		
		}
	};
	/*#{1FBR233GG1ExViewDef*/
	/*}#1FBR233GG1ExViewDef*/
	
	return cssVO;
};

export {DiskitUI};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "DiskitUI.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FBR233GG0", 
//			"attrs": {
//				"viewName": "\"DiskitUI\"", "device": "iPad 1024x768", "w": "1024", "h": "768", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FBR233GG1", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FBR233GG2", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FBR233GG3", 
//						"attrs": {}, "funcs": {"jaxId":"1FBR233GG4","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "1", "viewName": "\"uiView\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "autoLayout": "On"
//					}, 
//					"faces": null, "viewFaces": {"jaxId":"1FBR233GG6","entrys":[]}, 
//					"funcs": {"jaxId":"1FBR233GG7","funcs":[]}, 
//					"subs": [
//						{
//							"type": "object", "def": "HudBox", "jaxId": "1FBR2S8SB0", 
//							"attrs": {
//								"locked": "1", "id": "\"BoxList\"", "x": "0", "y": "#appCfg.size.headerH", "w": "#\"FW\"", "h": "#\"FH-\"+(appCfg.size.headerH+appCfg.size.stateBoxH)", 
//								"anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "color": "#appCfg.color.window", "border": "0", 
//								"borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", 
//								"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FBR2S8SB2","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudBox", "jaxId": "1FBR5JL960", 
//									"attrs": {
//										"locked": "1", "id": "\"BoxListHead\"", "x": "0", "y": "1", "w": "\"FW\"", "h": "#appCfg.size.listHeadH", "anchorH": "Left", "anchorV": "Top", 
//										"autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "color": "#appCfg.color.headBox", "border": "0", "borderStyle": "Solid", 
//										"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", 
//										"shadowColor": "[0,0,0,0.5]", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FBR5JL962","funcs":[]}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudBox", "jaxId": "1FBR5C1N60", 
//											"attrs": {
//												"locked": "1", "id": "\"BtmLine\"", "x": "0", "y": "#appCfg.size.listHeadH", "w": "\"FW\"", "h": "1", "anchorH": "Left", "anchorV": "Top", 
//												"autoLayout": "On", "display": "Show", "clip": "Off", "uiEvent": "On", "color": "#787878", "border": "0", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", 
//												"coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", 
//												"alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//											}, 
//											"funcs": {"jaxId":"1FBR5C1N70","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudBox", "jaxId": "1FBR5F4TH0", 
//											"attrs": {
//												"locked": "1", "id": "\"TopLine\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "1", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "color": "[255,255,255,1]", "border": "0", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", 
//												"gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", "alpha": "1", 
//												"rotate": "0", "cursor": "\"\"", "zIndex": "0"
//											}, 
//											"funcs": {"jaxId":"1FBR5F4TJ0","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FM3LE7810", 
//											"attrs": {
//												"locked": "0", "id": "\"TxtPath\"", "x": "10", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "text": "\"/coke/\"", "color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", 
//												"alignH": "Left", "alignV": "Center", "font": "\"\"", "fontSize": "#appCfg.txtSize.mid", "bold": "0", "italic": "0", "underline": "0", "alpha": "1", 
//												"rotate": "0", "cursor": "\"\"", "zIndex": "0"
//											}, 
//											"funcs": {"jaxId":"1FM3LE7811","funcs":[]}, "subs": []
//										}
//									]
//									
//								},
//								{
//									"type": "object", "def": "HudDock", "jaxId": "1FF4L6KQ00", 
//									"attrs": {
//										"locked": "0", "id": "\"DKConsoles\"", "x": "0", "y": "#appCfg.size.listHeadH", "w": "\"FW\"", "h": "#\"FH-\"+appCfg.size.listHeadH", "ui": "-1", 
//										"anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", 
//										"zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FF4L6KQ02","funcs":[]}, "subs": []
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudBox", "jaxId": "1FBR26ACL0", 
//							"attrs": {
//								"locked": "1", "id": "\"BoxHead\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "#appCfg.size.headerH", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "color": "#appCfg.color.headBox", "border": "0", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", 
//								"coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", 
//								"alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FBR26ACL2","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudBox", "jaxId": "1FBR2C50N0", 
//									"attrs": {
//										"locked": "1", "id": "\"BtmLine\"", "x": "0", "y": "#appCfg.size.headerH", "w": "\"FW\"", "h": "1", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "color": "#787878", "border": "0", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", 
//										"gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", "alpha": "1", 
//										"rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FBR2C50N2","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FBR4H3UE0", 
//									"attrs": {
//										"locked": "1", "id": "\"BoxHeadNavi\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FBR4H3UE2","funcs":[]}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudBox", "jaxId": "1FBR4H3UF0", 
//											"attrs": {
//												"locked": "1", "id": "\"\"", "x": "3", "y": "3", "w": "1", "h": "\"FH-6\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "color": "[150,150,150,1]", "border": "0", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", 
//												"gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", "alpha": "1", 
//												"rotate": "0", "cursor": "\"\"", "zIndex": "0"
//											}, 
//											"funcs": {"jaxId":"1FBR4H3UF2","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "Gear1FBOMHCB70", "jaxId": "1FBR4H3UF3", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FBR4H3UF4", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "24", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"image": {
//														"type": "string", "valText": "\"diskadd.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FBR4H3UF5", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnNewDisk\"", "x": "6", "y": "\"(FH-24)/2\"", 
//												"tip": {
//													"type": "auto", "valText": "\"Add new disk\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}, 
//												"autoLayout": "Off"
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FBR4H3UF7", 
//												"funcs": [
//													{
//														"jaxId": "1FC2G7GMM0", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FC2G8P0U0", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FBOMHCB70", "jaxId": "1FBR4KQEH0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FBR4KQEH1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "24", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"image": {
//														"type": "string", "valText": "\"trash.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FBR4KQEH2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnNaviDel\"", "x": "54", "y": "\"(FH-24)/2\"", 
//												"tip": {
//													"type": "auto", "valText": "\"Delete item\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}, 
//												"autoLayout": "Off"
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FBR4KQEH3", 
//												"funcs": [
//													{
//														"jaxId": "1FBR50B8K4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FBR50B8K5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FBOMHCB70", "jaxId": "1FC2R95CR0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FC2R95CR1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "24", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"image": {
//														"type": "string", "valText": "\"diskdownload.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FC2R95CR2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnDownloadDisk\"", "x": "30", "y": "\"(FH-24)/2\"", 
//												"tip": {
//													"type": "auto", "valText": "\"Download disk as zip\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}, 
//												"autoLayout": "Off"
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FC2R95CR3", 
//												"funcs": [
//													{
//														"jaxId": "1FC2R95CR4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FC2R95CR5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										}
//									]
//									
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudBox", "jaxId": "1FBR439899", 
//							"attrs": {
//								"locked": "1", "id": "\"BoxState\"", "x": "0", "y": "\"FH\"", "w": "\"FW\"", "h": "#appCfg.size.stateBoxH", "anchorH": "Left", "anchorV": "Bottom", 
//								"autoLayout": "On", "display": "Show", "clip": "Off", "uiEvent": "On", "color": "#appCfg.color.stateBox", "border": "0", "borderStyle": "Solid", 
//								"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", 
//								"shadowColor": "[0,0,0,0.5]", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FBR4398911","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FBR4H3UF8", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtState\"", "x": "10", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "text": "\"Ready.\"", "color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", 
//										"alignH": "Left", "alignV": "Center", "font": "\"\"", "fontSize": "#appCfg.txtSize.small", "bold": "0", "italic": "0", "underline": "0", "alpha": "1", 
//										"rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FBR4H3UF10","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudBox", "jaxId": "1FBR46FJ50", 
//									"attrs": {
//										"locked": "1", "id": "\"Line\"", "x": "0", "y": "-1", "w": "\"FW\"", "h": "1", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "color": "[150,150,150,1]", "border": "0", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", 
//										"gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", "alpha": "1", 
//										"rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FBR46FJ52","funcs":[]}, "subs": []
//								}
//							]
//							
//						}
//					]
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FBR233GG8", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FBR233GG10","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}