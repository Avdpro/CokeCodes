prj={
	"name": undefined, "appCfg": "cfg/appCfg.js", "txtLib": "text/textLib.js", "appData": "data/appData.js", "appHtml": "app.html", 
	"dataFiles": ["CCEnv.js"], "cssFiles": ["btnIcon.js","UIConsole.js"], 
	"uiFiles": ["DiskitUI.js"], "srcFiles": ["cmd_pwd.js"]
};
