### Commnad: *mkdir* -- create new directory

#### Usage:
       mkdir [-p] [-d] [new-dir]

The mkdir utility creates the directory named as operands.  
In coke environment, only **disk** can be created at the root path **/**. When create disk needed, **mkdir** will ask you to confirm it. Use **-d** option to ignor the ask.

- -p: Create intermediate directories as required.  If this option is not specified, the full path prefix of each operand must already 
exist.  
On the other hand, with this option specified, no error 
will be reported if a directory given as an operand already 
exists.  Intermediate directories are created with permission

- -d: Creat new disk when needed.

#### Examples:
      mkdir images
Create a new dir **images** in current directory.

      mkdir -p -d /MyCoolApp/images/buttons
Create a new dir **/MyCoolApp/images/buttons** and dir **/MyCoolApp/images** and disk **MyCoolApp** if they are missing.
