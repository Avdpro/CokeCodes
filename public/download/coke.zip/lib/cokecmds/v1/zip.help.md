### Commnad: *zip* -- make zip file

#### Usage:
       zip srcpath zipname
       zip srcpath ... zipname

Pack srcpath contents into zipname zip-file.

#### Examples:
      zip logs/* logs.zip
Packs all files in logs dir into logs.zip under currrent path.

