### Commnad: *pwd* -- show current directory path.

#### Usage:
       pwd

The pwd utility writes the absolute pathname of the current working directory to the standard output.
