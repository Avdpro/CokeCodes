Cokecodes brings the essence of morden OS (like MacOS, Windows, Linux) to the browser. It will enable a full **development tool-chain right in the browser.**  

**Note:** Current concept preview has only limited support for mobile devices or tablets. Try desktop version to discover more features.  

**Code base:** [CokeCokes on Github](https://github.com/Avdpro/CokeCodes)
