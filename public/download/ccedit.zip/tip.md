### CCEdit tips

#### Concept Demo:
This is CokeCokes code editor **concept demo**. More features and addons incomming.

#### Shortcut keys:
- Switch docs: `Alt+tab`/`Ctrl+~(The key on left of key "1")`
- Save doc: `Cmd+S`
- Save doc as: `Shift+Cmd+S`
- Copy: `Cmd+C`(macOS)/`Ctrl+C`(PC)
- Paste: `Cmd+V`(macOS)/`Ctrl+V`(PC)
- Undo: `Cmd+Z`(macOS)/`Ctrl+Z`(PC)
- Redo: `Shift+Cmd+Z`,`Cmd+Y`(macOS)/`Shift+Ctrl+V`,`Ctrl+Y`(PC)
- Find: `Cmd+F`(macOS)/`Ctrl+F`(PC)
- Find Next: `Cmt+G`(macOS)/`Ctrl+G`(PC)
- Replace: `Cmd+Alt+F`(macOS)/`Ctrl+Alt+F`(PC)
- Auto-complete: `Ctrl+Space`

#### Run project:
Conifg your project's **disk.json**, declare main entry (a path to a ***.js*** or ***.html*** file). CCEditor's **Run button** will execute that main entry.

#### Book mark and todo mark:
- Comments start with `//:` will be treat as bookmarks.  
- Comments start with `//TODO:` will be treat as todo-reminders.

#### Addons:
CCEdit is based on CodeMirror, you can import addons or write your own.
