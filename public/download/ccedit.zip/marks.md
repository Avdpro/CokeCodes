**Add mark:**
Comments start with `//:` will be treat as bookmarks.

**Add todo:**
Comments start with `//TODO:` will be treat as todo-reminders.
