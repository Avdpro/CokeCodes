//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {JAXDataObj} from "/jaxweb/lib/JAXDataObj.js"
/*App的总数据文件*/
/*#{1FD92U5OB0Imports*/
import cokeNT from "/@cokecodes/cokeNT.js"
import {WebAPI} from "./lib/WebAPI.js";
import {CCUser} from "./data/CCUser.js";
/*}#1FD92U5OB0Imports*/

//----------------------------------------------------------------------------
/*App的入口文件*/
var appData={};

//App数据初始化函数:
appData.initData=function(jaxEnv){
	/*#{1FD92U5OB0initPre*/
	JAXDataObj.call(this,jaxEnv,jaxEnv.app,"appData");
	/*}#1FD92U5OB0initPre*/
	this.jaxEnv=jaxEnv;
	this.version="0.0.0";
	/*#{1FD92U5OB0initPost*/
	this.cokeNT=cokeNT;
	this.user=new CCUser(this);
	this.userId="";
	this.loginVO=null;
	this.loginDone=0;
	/*}#1FD92U5OB0initPost*/
};
/*#{1FD92U5OB0ExFuncs*/

//----------------------------------------------------------------------------
//用户注册:
appData.register=async function(regVO){
	var self,vo;
	self=this;
	vo=await WebAPI.makeCall("userReg",regVO);
	if(vo.code===200){
		vo.apiPath=WebAPI.path;
		self.saveLoginInfo(vo);	
		self.loginDone=1;
		self.loginVO=vo;
		self.userId=vo.userid;
		self.user.loadLoginInfo(vo);
		self.emitNotify("Online");
		return true;
	}else{
		throw "Register error "+vo.code+": "+vo.info;
	}
	return false;
};

//----------------------------------------------------------------------------
//用户登录:
appData.login=async function(callVO){
	let vo,self,savedVO;
	let loginKey,time;

	self=this;
	if(!callVO){
		savedVO=this.loadLoginInfo();
		if(!savedVO ||savedVO.userId){
			throw "No saved login info.";
		}
		callVO={
			"userId":savedVO.userId,
			"time":Date.now(),
		};
		if(savedVO.token){
			if(time>savedVO.tokenExpire){
				//token已过期:
				throw "Login token is expired.";
			}
			callVO.token=savedVO.token;
		}else{
			//没有token
			throw "Login token is invalid.";
		}
	}
	vo=await WebAPI.makeCall("apiPath",{});
	if(vo && vo.path){
		WebAPI.setAPIPath(vo.path);
		vo=await WebAPI.makeCall("userLogin",callVO);
		if(vo.code===200){
			vo.apiPath=WebAPI.path;
			self.saveLoginInfo(vo);	
			this.loginDone=1;
			this.loginVO=vo;
			this.userId=vo.userid;
			this.user.loadLoginInfo(vo);
			this.emitNotify("Online");
			return true;
		}else{
			throw "Login error "+vo.code+": "+vo.info;
		}
	}
	throw "Login error: can't get API-Path.";
};

//----------------------------------------------------------------------------
//读取保存在本地的登录信息:
appData.loadLoginInfo=function(){
	let voText,vo;
	voText=localStorage.getItem("LoginVO");
	if(voText){
		vo=JSON.parse(voText);
		return this.loginVO;
	}
	return null;
};

//----------------------------------------------------------------------------
//保存登陆信息:
appData.saveLoginInfo=function(vo){
	let voText;
	this.loginVO=vo;
	voText=JSON.stringify(vo);
	localStorage.setItem("LoginVO",voText);
};

//----------------------------------------------------------------------------
//通过appData进行call，需要login:
appData.makeCall=async function(msg,vo){
	if(!this.loginDone){
		await this.login();
	}
	vo.userId=this.loginVO.userId;
	vo.token=this.loginVO.token;
	return await WebAPI.makeCall(msg,vo);
};

/*}#1FD92U5OB0ExFuncs*/

export {appData};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"jaxId": "1FD92U5OB0", "dataObj": {"version":"\"0.0.0\""}, 
//			"funcs": {"jaxId":"1FD92U5OB1","funcs":[]}
//		}/*Doc}#*/;
//	}