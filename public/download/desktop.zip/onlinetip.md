## CokeCodes cloud usage tip:
CokeCodes is under developing now, current feature set is limited. At this moment, you can:

- Sync local disk with CokeCodes cloud repository, share between devices. Use the **Diskit** app or use **disk command in terminal**.

- Create your own package, share with other developers: Use the **pkg command in terminal**.

### More features incomming:
- Share preview of your prjects to others via **Bar-Code**.

- Invite other developers to your project.

- Setup your full-stack project test environment.

### Upgrade your rank
To save my mantainess cost, **GUEST** user's repository is limited both with file-size and total-size at present. 
If you are really interested in work within CokeCodes and need more capacity, you can contact me at ***pxavdpro@gmail.com***.

