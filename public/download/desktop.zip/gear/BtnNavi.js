//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FD988DIR0Imports*/
/*}#1FD988DIR0Imports*/
//----------------------------------------------------------------------------
/*按钮控件，支持鼠标悬浮、不可用状态*/
var BtnNavi=function (app, img, text, $state){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FD988DIR1ExLocal*/
	/*}#1FD988DIR1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state={
		/*#{1FD988DIR3ExState*/
		/*}#1FD988DIR3ExState*/
	};
	if($state){
		Object.assign(state,$state);
	}
	state=jaxHudState(jaxEnv,state);
	
	/*#{1FD988DIR1Mid*/
	/*}#1FD988DIR1Mid*/
	
	cssVO={
		"type": "button", "jaxId": "1FD988DIR1", "x": (appCfg.size.btnNavi)+61, "y": 140, "w": appCfg.size.btnNavi, "h": appCfg.size.btnNavi, "anchorH": 1, 
		"anchorV": 2, 
		"hudState": state, 
		items: [
			{
				"type": "image", "jaxId": "1FD98FB2D0", "id": "ImgIcon", "x": 16, "y": 32, "w": appCfg.size.btnNavi, "h": appCfg.size.btnNavi, "anchorH": 1, "anchorV": 2, 
				"display": 0, "cursor": "pointer", "image": "assets/"+img, "autoSize": 0, "fitSize": 1, "filter": ""
			},
			{
				"type": "text", "jaxId": "1FD991V240", "id": "TxtName", "x": "FW/2", "y": 0, "w": 100, "h": 32, "cursor": "pointer", "text": text, "color": appCfg.color.headMain, 
				"alignV": 1, "fontSize": appCfg.txtSize.bigMid
			}
		],
		faces: {
			"blur": {
				/*ImgIcon*/"#1FD98FB2D0": {
					"w": 32, "h": 32
				},
				/*TxtName*/"#1FD991V240": {
					"underline": 0, "color": appCfg.color.headSub, "bold": 0
				},
			},
			"hot": {
				/*ImgIcon*/"#1FD98FB2D0": {
					"w": 40, "h": 40
				},
				/*TxtName*/"#1FD991V240": {
					"underline": 1, "color": appCfg.color.headMain, "bold": 1
				},
			},
			"up": {
				/**/"#self": {
					"alpha": 1
				},
			},
			"down": {
				/**/"#self": {
					"alpha": 0.75
				},
			},
			"gray": {
				/**/"#self": {
					"alpha": 0.35
				},
			}
		},
		OnCreate: function(){
			self=this;
			/*#{1FD988DIR1CreateFunc*/
			/*}#1FD988DIR1CreateFunc*/
		}
	};
	/*#{1FD988DIR1ExViewDef*/
	/*}#1FD988DIR1ExViewDef*/
	
	return cssVO;
};

/*#{1FD988DIR0PostCode*/
/*}#1FD988DIR0PostCode*/

export {BtnNavi};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"type": "object", "name": "BtnNavi.js", "def": "CdyFileUIGear", "jaxId": "1FD988DIR0", 
//			"attrs": {
//				"gearName": "\"BtnNavi\"", "device": "iPhone 375x750", "w": "375", "h": "750", "desc": "\"\"", 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FD988DJ00", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FD988DJ02","entrys":[]}, "subs": []
//				}
//			}, 
//			"uiGear": {
//				"type": "object", "def": "HudBtn", "jaxId": "1FD988DIR1", 
//				"args": {
//					"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD988DIR2", 
//					"attrs": {
//						"img": {
//							"type": "string", "valText": "\"home.svg\"", "initVal": "", "info": null, 
//							"tip": null
//						}, 
//						"text": {
//							"type": "string", "valText": "\"Home\"", "initVal": "", "info": null, 
//							"tip": null
//						}
//					}
//				}, 
//				"stateObj": {
//					"name": "stateObj", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FD988DIR3", 
//					"attrs": {}, "funcs": {"jaxId":"1FD988DJ03","funcs":[]}
//				}, 
//				"attrs": {
//					"locked": "0", "id": "\"\"", "x": "#(appCfg.size.btnNavi)+61", "y": "140", "w": "#appCfg.size.btnNavi", "h": "#appCfg.size.btnNavi", "anchorH": "Center", 
//					"anchorV": "Bottom", "autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", 
//					"drag": "NA", "enable": "On"
//				}, 
//				"viewFaces": {
//					"jaxId": "1FD988DJ04", 
//					"entrys": [
//						{
//							"jaxId": "1FMHBOTU10", "attrs": {"Face Name":"\"blur\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHC30S11", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FMHBS2A90", "attrs": {"Face Name":"\"hot\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHC30S12", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FMHCE2HE0", "attrs": {"Face Name":"\"up\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHCFTEC0", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FMHCEV6B0", "attrs": {"Face Name":"\"down\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHCFTEC1", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FMHCJ0SB0", "attrs": {"Face Name":"\"gray\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHCK6HK0", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						}
//					]
//				}, 
//				"faces": {
//					"jaxId": "1FMHBEKFO0", 
//					"entrys": [
//						{
//							"jaxId": "1FMHCFTEC2", "entryId": "1FMHCE2HE0", "faceName": "up", 
//							"attrs": {"alpha":"1"}, 
//							"anis": {
//								"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMHCFTEC3", 
//								"attrs": []
//							}
//							
//						},
//						{
//							"jaxId": "1FMHCFTEC4", "entryId": "1FMHCEV6B0", "faceName": "down", 
//							"attrs": {"alpha":"0.75"}, 
//							"anis": {
//								"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMHCFTEC5", 
//								"attrs": []
//							}
//							
//						},
//						{
//							"jaxId": "1FMHCK6HK1", "entryId": "1FMHCJ0SB0", "faceName": "gray", 
//							"attrs": {"alpha":"0.35"}, 
//							"anis": {
//								"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMHCK6HK2", 
//								"attrs": []
//							}
//							
//						}
//					]
//				}, 
//				"funcs": {"jaxId":"1FD988DJ06","funcs":[]}, "btnHuds": {}, 
//				"subs": [
//					{
//						"type": "object", "def": "HudImage", "jaxId": "1FD98FB2D0", 
//						"attrs": {
//							"locked": "0", "id": "\"ImgIcon\"", "x": "16", "y": "32", "w": "#appCfg.size.btnNavi", "h": "#appCfg.size.btnNavi", "anchorH": "Center", "anchorV": "Bottom", 
//							"autoLayout": "Off", "display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "image": "#\"assets/\"+img", 
//							"autoSize": "0", "fitSize": "1", "filter": "\"\""
//						}, 
//						"faces": {
//							"jaxId": "1FMHBEKFO1", 
//							"entrys": [
//								{
//									"jaxId": "1FMHC30S13", "entryId": "1FMHBOTU10", "faceName": "blur", 
//									"attrs": {"w":"32","h":"32"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMHC30S14", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FMHC30S15", "entryId": "1FMHBS2A90", "faceName": "hot", 
//									"attrs": {"w":"40","h":"40"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMHC30S16", 
//										"attrs": []
//									}
//									
//								}
//							]
//						}, 
//						"funcs": {"jaxId":"1FD98FB2D2","funcs":[]}, "subs": []
//					},
//					{
//						"type": "object", "def": "HudTxt", "jaxId": "1FD991V240", 
//						"attrs": {
//							"locked": "0", "id": "\"TxtName\"", "x": "\"FW/2\"", "y": "0", "w": "100", "h": "32", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//							"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "text": "#text", "color": "#appCfg.color.headMain", 
//							"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Center", "font": "\"\"", "fontSize": "#appCfg.txtSize.bigMid", 
//							"bold": "0", "italic": "0", "underline": "0"
//						}, 
//						"faces": {
//							"jaxId": "1FMHBEKFO2", 
//							"entrys": [
//								{
//									"jaxId": "1FMHC30S17", "entryId": "1FMHBOTU10", "faceName": "blur", 
//									"attrs": {"underline":"0","color":"#appCfg.color.headSub","bold":"0"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMHC30S18", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FMHC30S19", "entryId": "1FMHBS2A90", "faceName": "hot", 
//									"attrs": {"underline":"1","color":"#appCfg.color.headMain","bold":"1"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMHC30S110", 
//										"attrs": []
//									}
//									
//								}
//							]
//						}, 
//						"funcs": {"jaxId":"1FD991V242","funcs":[]}, "subs": []
//					}
//				]
//			}
//		}/*Doc}#*/;
//	}