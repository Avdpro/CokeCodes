//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FMOETBUK0Imports*/
/*}#1FMOETBUK0Imports*/
//----------------------------------------------------------------------------
/*图片控件*/
var LabelNew=function (app, w, $state){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FMOETBUK1ExLocal*/
	/*}#1FMOETBUK1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state={
		/*#{1FMOETBUK3ExState*/
		/*}#1FMOETBUK3ExState*/
	};
	if($state){
		Object.assign(state,$state);
	}
	state=jaxHudState(jaxEnv,state);
	
	/*#{1FMOETBUK1Mid*/
	/*}#1FMOETBUK1Mid*/
	
	cssVO={
		"type": "image", "jaxId": "1FMOETBUK1", "x": 125, "y": 152, "w": w, "h": w*0.5, "anchorH": 1, "image": "assets/newlabel.svg", "autoSize": 0, "fitSize": 1, 
		"filter": "", 
		"hudState": state, 
		faces: {
		},
		OnCreate: function(){
			self=this;
			/*#{1FMOETBUK1CreateFunc*/
			/*}#1FMOETBUK1CreateFunc*/
		}
	};
	/*#{1FMOETBUK1ExViewDef*/
	/*}#1FMOETBUK1ExViewDef*/
	
	return cssVO;
};

/*#{1FMOETBUK0PostCode*/
/*}#1FMOETBUK0PostCode*/

export {LabelNew};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"type": "object", "name": "LabelNew.js", "def": "CdyFileUIGear", "jaxId": "1FMOETBUK0", 
//			"attrs": {
//				"gearName": "\"LabelNew\"", "device": "iPhone 375x750", "w": "375", "h": "750", "desc": "\"\"", 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FMOETBUL0", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FMOETBUL2","entrys":[]}, "subs": []
//				}
//			}, 
//			"uiGear": {
//				"type": "object", "def": "HudImage", "jaxId": "1FMOETBUK1", 
//				"args": {
//					"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMOETBUK2", 
//					"attrs": {
//						"w": {"type":"int","valText":"100","initVal":"","info":null,"tip":null}
//					}
//				}, 
//				"stateObj": {
//					"name": "stateObj", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FMOETBUK3", 
//					"attrs": {}, "funcs": {"jaxId":"1FMOETBUL3","funcs":[]}
//				}, 
//				"attrs": {
//					"locked": "0", "id": "\"\"", "x": "125", "y": "152", "w": "#w", "h": "#w*0.5", "anchorH": "Center", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//					"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "assets/newlabel.svg", "autoSize": "0", "fitSize": "1", 
//					"filter": "\"\""
//				}, 
//				"viewFaces": {"jaxId":"1FMOETBUL4","entrys":[]}, 
//				"funcs": {"jaxId":"1FMOETBUL6","funcs":[]}, "subs": []
//			}
//		}/*Doc}#*/;
//	}