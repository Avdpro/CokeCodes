//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FQUBKLDU0Imports*/
/*}#1FQUBKLDU0Imports*/
//----------------------------------------------------------------------------
/*按钮控件，支持鼠标悬浮、不可用状态*/
var BlkApp=function (app, image, text, info, $state){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FQUBKLDU1ExLocal*/
	/*}#1FQUBKLDU1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state={
		/*#{1FQUBKLDU3ExState*/
		/*}#1FQUBKLDU3ExState*/
	};
	if($state){
		Object.assign(state,$state);
	}
	state=jaxHudState(jaxEnv,state);
	
	/*#{1FQUBKLDU1Mid*/
	/*}#1FQUBKLDU1Mid*/
	
	cssVO={
		"type": "button", "jaxId": "1FQUBKLDU1", "x": 54, "y": 50, "w": 240, "h": 80, "cursor": "pointer", 
		"hudState": state, 
		items: [
			{
				"type": "box", "jaxId": "1FQUC8V2V0", "id": "BG", "x": 0, "y": 0, "w": "FW", "h": "FH", "color": appCfg.color.appBoxBG, "border": 3, "borderColor": [194,243,255,1], 
				"coner": 16, "shadowColor": [0,0,0,0.5], "coners": [0,20,0,20], 
				items: [
					{
						"type": "image", "jaxId": "1FQUC8V302", "id": "ImgIcon", "x": 15, "y": "(FH-50)/2", "w": 50, "h": 50, "image": image, "autoSize": 0, "fitSize": 1, 
						"filter": ""
					},
					{
						"type": "text", "jaxId": "1FQUCMMVG0", "id": "TxtText", "x": 80, "y": 18, "w": 100, "h": 20, "text": text, "color": [255,255,255], "fontSize": 16, 
						"bold": 1
					},
					{
						"type": "text", "jaxId": "1FQUCMUFC0", "id": "TxtText", "x": 80, "y": 40, "w": 100, "h": 20, "alpha": 0.8, "text": info, "color": [255,255,255], 
						"fontSize": appCfg.txtSize.smallMid
					}
				]
			}
		],
		faces: {
			"up": {
				/*BG*/"#1FQUC8V2V0": {
					"color": appCfg.color.appBoxBG
				},
			},
			"over": {
				/*BG*/"#1FQUC8V2V0": {
					"color": appCfg.color.appBoxBGOver
				},
			},
			"down": {
				/*BG*/"#1FQUC8V2V0": {
					"color": appCfg.color.appBoxBG
				},
			},
			"gray": {
				/*BG*/"#1FQUC8V2V0": {
					"color": appCfg.color.appBoxBGGray
				},
			}
		},
		OnCreate: function(){
			self=this;
			/*#{1FQUBKLDU1CreateFunc*/
			/*}#1FQUBKLDU1CreateFunc*/
		}
	};
	/*#{1FQUBKLDU1ExViewDef*/
	/*}#1FQUBKLDU1ExViewDef*/
	
	return cssVO;
};

/*#{1FQUBKLDU0PostCode*/
/*}#1FQUBKLDU0PostCode*/

export {BlkApp};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"type": "object", "name": "BlkApp.js", "def": "CdyFileUIGear", "jaxId": "1FQUBKLDU0", 
//			"attrs": {
//				"gearName": "\"BlkApp\"", "device": "iPhone 375x750", "w": "375", "h": "750", "desc": "\"\"", 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FQUBKLDV0", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FQUBKLDV2","entrys":[]}, "subs": []
//				}
//			}, 
//			"uiGear": {
//				"type": "object", "def": "HudBtn", "jaxId": "1FQUBKLDU1", 
//				"args": {
//					"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUBKLDU2", 
//					"attrs": {
//						"image": {
//							"type": "string", "valText": "\"assets/cloud.svg\"", "initVal": "", 
//							"info": null, "tip": null
//						}, 
//						"text": {
//							"type": "string", "valText": "\"REACT/JS\"", "initVal": "", "info": null, 
//							"tip": null
//						}, 
//						"info": {
//							"type": "string", "valText": "\"With HMR\"", "initVal": "", "info": null, 
//							"tip": null
//						}
//					}
//				}, 
//				"stateObj": {
//					"name": "stateObj", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FQUBKLDU3", 
//					"attrs": {}, "funcs": {"jaxId":"1FQUBKLDV3","funcs":[]}
//				}, 
//				"attrs": {
//					"locked": "0", "id": "\"\"", "x": "54", "y": "50", "w": "240", "h": "80", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//					"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "drag": "NA", "enable": "On"
//				}, 
//				"viewFaces": {
//					"jaxId": "1FQUBKLDV4", 
//					"entrys": [
//						{
//							"jaxId": "1FQUCSEHR0", "attrs": {"Face Name":"\"up\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUD3JU80", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FQUCSR5T0", "attrs": {"Face Name":"\"over\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUD3JU81", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FQUCSUQF0", "attrs": {"Face Name":"\"down\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUD3JU82", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FQUCTEQ70", "attrs": {"Face Name":"\"gray\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUD3JU83", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						}
//					]
//				}, 
//				"funcs": {"jaxId":"1FQUBKLDV6","funcs":[]}, "btnHuds": {}, 
//				"subs": [
//					{
//						"type": "object", "def": "HudBox", "jaxId": "1FQUC8V2V0", 
//						"attrs": {
//							"locked": "0", "id": "\"BG\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//							"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "#appCfg.color.appBoxBG", "border": "3", 
//							"borderStyle": "Solid", "borderColor": "[194,243,255,1]", "coner": "16", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", 
//							"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]", 
//							"coners": {"type":"auto","valText":"[0,20,0,20]","info":null,"tip":null}
//						}, 
//						"faces": {
//							"jaxId": "1FQUCGNCS4", 
//							"entrys": [
//								{
//									"jaxId": "1FQUD3JU84", "entryId": "1FQUCTEQ70", "faceName": "gray", 
//									"attrs": {"color":"#appCfg.color.appBoxBGGray"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FQUD3JU85", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FQUDG7A60", "entryId": "1FQUCSEHR0", "faceName": "up", 
//									"attrs": {"color":"#appCfg.color.appBoxBG"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FQUDG7A61", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FQUDG7A62", "entryId": "1FQUCSR5T0", "faceName": "over", 
//									"attrs": {"color":"#appCfg.color.appBoxBGOver"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FQUDG7A63", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FQUDG7A64", "entryId": "1FQUCSUQF0", "faceName": "down", 
//									"attrs": {"color":"#appCfg.color.appBoxBG"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FQUDG7A65", 
//										"attrs": []
//									}
//									
//								}
//							]
//						}, 
//						"funcs": {"jaxId":"1FQUC8V301","funcs":[]}, 
//						"subs": [
//							{
//								"type": "object", "def": "HudImage", "jaxId": "1FQUC8V302", 
//								"attrs": {
//									"locked": "0", "id": "\"ImgIcon\"", "x": "15", "y": "\"(FH-50)/2\"", "w": "50", "h": "50", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//									"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "#image", "autoSize": "0", 
//									"fitSize": "1", "filter": "\"\""
//								}, 
//								"funcs": {"jaxId":"1FQUC8V304","funcs":[]}, "subs": []
//							},
//							{
//								"type": "object", "def": "HudTxt", "jaxId": "1FQUCMMVG0", 
//								"attrs": {
//									"locked": "0", "id": "\"TxtText\"", "x": "80", "y": "18", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//									"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "#text", "color": "[255,255,255]", "autoSizeW": "0", 
//									"autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "16", "bold": "1", 
//									"italic": "0", "underline": "0"
//								}, 
//								"funcs": {"jaxId":"1FQUCMMVG1","funcs":[]}, "subs": []
//							},
//							{
//								"type": "object", "def": "HudTxt", "jaxId": "1FQUCMUFC0", 
//								"attrs": {
//									"locked": "0", "id": "\"TxtText\"", "x": "80", "y": "40", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//									"clip": "Off", "uiEvent": "On", "alpha": "0.8", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "#info", "color": "[255,255,255]", "autoSizeW": "0", 
//									"autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.smallMid", 
//									"bold": "0", "italic": "0", "underline": "0"
//								}, 
//								"funcs": {"jaxId":"1FQUCMUFC1","funcs":[]}, "subs": []
//							}
//						]
//						
//					}
//				]
//			}
//		}/*Doc}#*/;
//	}