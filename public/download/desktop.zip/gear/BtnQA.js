//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FQUTH9G60Imports*/
/*}#1FQUTH9G60Imports*/
//----------------------------------------------------------------------------
/*按钮控件，支持鼠标悬浮、不可用状态*/
var BtnQA=function (app, text, $state){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FQUTH9G61ExLocal*/
	/*}#1FQUTH9G61ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state={
		/*#{1FQUTH9G63ExState*/
		/*}#1FQUTH9G63ExState*/
	};
	if($state){
		Object.assign(state,$state);
	}
	state=jaxHudState(jaxEnv,state);
	
	/*#{1FQUTH9G61Mid*/
	/*}#1FQUTH9G61Mid*/
	
	cssVO={
		"type": "button", "jaxId": "1FQUTH9G61", "x": 74, "y": 59, "w": 100, "h": 30, 
		"hudState": state, 
		items: [
			{
				"type": "box", "jaxId": "1FQUTN6JF0", "x": 0, "y": 0, "w": 100, "h": "FH", "cursor": "pointer", "color": appCfg.color.btnQAUp, "coner": 12, "shadowColor": [0,0,0,0.5], 
				items: [
					{
						"type": "text", "jaxId": "1FQUV7M2C9", "x": 0, "y": 0, "w": 100, "h": 30, "uiEvent": -1, "text": text, "color": [255,255,255], "alignH": 1, "alignV": 1, 
						"fontSize": 16
					}
				]
			}
		],
		faces: {
			"up": {
				/**/"#1FQUTN6JF0": {
					"color": appCfg.color.btnQAUp
				},
			},
			"over": {
				/**/"#1FQUTN6JF0": {
					"color": appCfg.color.btnQAOver
				},
			},
			"down": {
				/**/"#1FQUTN6JF0": {
					"color": appCfg.color.btnQADown
				},
			}
		},
		OnCreate: function(){
			self=this;
			/*#{1FQUTH9G61CreateFunc*/
			/*}#1FQUTH9G61CreateFunc*/
		}
	};
	/*#{1FQUTH9G61ExViewDef*/
	/*}#1FQUTH9G61ExViewDef*/
	
	return cssVO;
};

/*#{1FQUTH9G60PostCode*/
/*}#1FQUTH9G60PostCode*/

export {BtnQA};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"type": "object", "name": "BtnQA.js", "def": "CdyFileUIGear", "jaxId": "1FQUTH9G60", 
//			"attrs": {
//				"gearName": "\"BtnQA\"", "device": "iPhone 375x750", "w": "375", "h": "750", "desc": "\"\"", 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FQUTH9G70", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FQUTH9G72","entrys":[]}, "subs": []
//				}
//			}, 
//			"uiGear": {
//				"type": "object", "def": "HudBtn", "jaxId": "1FQUTH9G61", 
//				"args": {
//					"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUTH9G62", 
//					"attrs": {
//						"text": {
//							"type": "string", "valText": "\"Full-stack?\"", "initVal": "", "info": null, 
//							"tip": null
//						}
//					}
//				}, 
//				"stateObj": {
//					"name": "stateObj", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FQUTH9G63", 
//					"attrs": {}, "funcs": {"jaxId":"1FQUTH9G73","funcs":[]}
//				}, 
//				"attrs": {
//					"locked": "0", "id": "\"\"", "x": "74", "y": "59", "w": "100", "h": "30", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//					"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "drag": "NA", "enable": "On"
//				}, 
//				"viewFaces": {
//					"jaxId": "1FQUTH9G74", 
//					"entrys": [
//						{
//							"jaxId": "1FQUV2Q420", "attrs": {"Face Name":"\"up\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUV7M2C0", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FQUV32250", "attrs": {"Face Name":"\"over\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUV7M2C1", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FQUV3FSD0", "attrs": {"Face Name":"\"down\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUV7M2C2", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						}
//					]
//				}, 
//				"funcs": {"jaxId":"1FQUTH9G76","funcs":[]}, "btnHuds": {}, 
//				"subs": [
//					{
//						"type": "object", "def": "HudBox", "jaxId": "1FQUTN6JF0", 
//						"attrs": {
//							"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//							"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "color": "#appCfg.color.btnQAUp", "border": "0", 
//							"borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "12", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", 
//							"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//						}, 
//						"faces": {
//							"jaxId": "1FQUTN6JF1", 
//							"entrys": [
//								{
//									"jaxId": "1FQUV7M2C3", "entryId": "1FQUV2Q420", "faceName": "up", 
//									"attrs": {"color":"#appCfg.color.btnQAUp"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FQUV7M2C4", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FQUV7M2C5", "entryId": "1FQUV32250", "faceName": "over", 
//									"attrs": {"color":"#appCfg.color.btnQAOver"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FQUV7M2C6", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FQUV7M2C7", "entryId": "1FQUV3FSD0", "faceName": "down", 
//									"attrs": {"color":"#appCfg.color.btnQADown"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FQUV7M2C8", 
//										"attrs": []
//									}
//									
//								}
//							]
//						}, 
//						"funcs": {"jaxId":"1FQUTN6JF2","funcs":[]}, 
//						"subs": [
//							{
//								"type": "object", "def": "HudTxt", "jaxId": "1FQUV7M2C9", 
//								"attrs": {
//									"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "30", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//									"clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "#text", "color": "[255,255,255]", 
//									"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Center", "font": "\"\"", "fontSize": "16", 
//									"bold": "0", "italic": "0", "underline": "0"
//								}, 
//								"funcs": {"jaxId":"1FQUV7M2C11","funcs":[]}, "subs": []
//							}
//						]
//						
//					}
//				]
//			}
//		}/*Doc}#*/;
//	}