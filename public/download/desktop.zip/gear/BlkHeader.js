//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FQUKUAUG0Imports*/
/*}#1FQUKUAUG0Imports*/
//----------------------------------------------------------------------------
/*Hud控件节点，没有内容，可以有子节点*/
var BlkHeader=function (app, color, text, $state){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FQUKUAUG1ExLocal*/
	let tipHud=null;
	/*}#1FQUKUAUG1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state={
		/*#{1FQUKUAUG3ExState*/
		/*}#1FQUKUAUG3ExState*/
	};
	if($state){
		Object.assign(state,$state);
	}
	state=jaxHudState(jaxEnv,state);
	
	/*#{1FQUKUAUG1Mid*/
	/*}#1FQUKUAUG1Mid*/
	
	cssVO={
		"type": "box", "jaxId": "1FQUKUAUG1", "x": 0, "y": 0, "w": "FW", "h": 30, "color": [255,255,255,1], "gradient": appCfg.color["gntBlockHead"+color], 
		"shadowColor": [0,0,0,0.5], 
		items: [
			{
				"type": "text", "jaxId": "1FQUL2K5K0", "id": "TxtText", "x": 10, "y": 0, "w": 100, "h": 30, "text": text, "color": appCfg.color.headMain, "alignV": 1, 
				"fontSize": appCfg.txtSize.big
			}
		],
		"hudState": state, 
		faces: {
		},
		OnCreate: function(){
			self=this;
			/*#{1FQUKUAUG1CreateFunc*/
			/*}#1FQUKUAUG1CreateFunc*/
		}
	};
	/*#{1FQUKUAUG1ExViewDef*/
	//------------------------------------------------------------------------
	//Show tip:
	cssVO.showTip=function(hud,tip){
		self.TxtText.text=tip;
		tipHud=hud;
	};
	
	//------------------------------------------------------------------------
	//Hide tip:
	cssVO.abortTip=function(hud){
		if(hud===tipHud){
			self.TxtText.text=text;
			tipHud=null;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setText=function(newText){
		text=newText;
		self.TxtText.text=newText;
	};
	/*}#1FQUKUAUG1ExViewDef*/
	
	return cssVO;
};

/*#{1FQUKUAUG0PostCode*/
/*}#1FQUKUAUG0PostCode*/

export {BlkHeader};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"type": "object", "name": "BlkHeader.js", "def": "CdyFileUIGear", "jaxId": "1FQUKUAUG0", 
//			"attrs": {
//				"gearName": "\"BlkHeader\"", "device": "iPhone 375x750", "w": "375", "h": "750", "desc": "\"\"", 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FQUKUAUH0", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FQUKUAUH2","entrys":[]}, "subs": []
//				}
//			}, 
//			"uiGear": {
//				"type": "object", "def": "HudBox", "jaxId": "1FQUKUAUG1", 
//				"args": {
//					"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQUKUAUG2", 
//					"attrs": {
//						"color": {"type":"int","valText":"2","initVal":"","info":null,"tip":null}, 
//						"text": {
//							"type": "string", "valText": "\"Dev. Tools\"", "initVal": "", "info": null, 
//							"tip": null
//						}
//					}
//				}, 
//				"stateObj": {
//					"name": "stateObj", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FQUKUAUG3", 
//					"attrs": {}, "funcs": {"jaxId":"1FQUKUAUH3","funcs":[]}
//				}, 
//				"attrs": {
//					"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "30", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//					"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[255,255,255,1]", "border": "0", "borderStyle": "Solid", 
//					"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "#appCfg.color[\"gntBlockHead\"+color]", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", 
//					"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//				}, 
//				"viewFaces": {"jaxId":"1FQUKUAUH4","entrys":[]}, 
//				"funcs": {"jaxId":"1FQUKUAUH6","funcs":[]}, 
//				"subs": [
//					{
//						"type": "object", "def": "HudTxt", "jaxId": "1FQUL2K5K0", 
//						"attrs": {
//							"locked": "0", "id": "\"TxtText\"", "x": "10", "y": "0", "w": "100", "h": "30", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//							"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "#text", "color": "#appCfg.color.headMain", 
//							"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Center", "font": "\"\"", "fontSize": "#appCfg.txtSize.big", 
//							"bold": "0", "italic": "0", "underline": "0"
//						}, 
//						"funcs": {"jaxId":"1FQUL2K5K1","funcs":[]}, "subs": []
//					}
//				]
//			}
//		}/*Doc}#*/;
//	}