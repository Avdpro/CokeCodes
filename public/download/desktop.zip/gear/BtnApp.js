//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FDH24MFV1Imports*/
/*}#1FDH24MFV1Imports*/
//----------------------------------------------------------------------------
/*按钮控件，支持鼠标悬浮、不可用状态*/
var BtnApp=function (app, w, img, text, $state){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FDH24MG02ExLocal*/
	if(img[0]==="/"){
		img=`/${document.location.origin}/${img}`;
	}
	let barBox=null;
	let hudView=null;
	/*}#1FDH24MG02ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state={
		"hasImg": 1
		/*#{1FDH24MG04ExState*/
		/*}#1FDH24MG04ExState*/
	};
	if($state){
		Object.assign(state,$state);
	}
	state=jaxHudState(jaxEnv,state);
	
	/*#{1FDH24MG02Mid*/
	let isMobile=appCfg.isMobile;
	if(!img){
		state.hasImg=false;
	}
	/*}#1FDH24MG02Mid*/
	
	cssVO={
		"type": "button", "jaxId": "1FDH24MG02", "x": appCfg.size.btnNavi, "y": 80, "w": w, "h": w, "cursor": "pointer", 
		"hudState": state, 
		"hudBtnUp": {
			"type": "box", "jaxId": "1FDHA2SPS0", "x": 0, "y": 0, "w": w, "h": w, "uiEvent": -1, "color": [255,255,255,1], "border": 3, "borderColor": [100,100,100,1], 
			"coner": w*0.2, "shadowX": 0, "shadowBlur": 5, "shadowColor": [0,0,0,0.5]
		},
		"hudBtnDown": {
			"type": "box", "jaxId": "1FDHA90JU2", "x": 0, "y": 2, "w": w, "h": w, "uiEvent": -1, "color": [255,255,255,1], "border": 1, "borderColor": appCfg.color.highLight, 
			"coner": w*0.2, "shadowX": 0, "shadowY": 0, "shadowColor": [0,0,0,0.5]
		},
		items: [
			{
				"type": "image", "jaxId": "1FDH24MG08", "id": "ImgIcon", "x": w*0.1, "y": w*0.1, "w": w*0.8, "h": w*0.8, "uiEvent": -1, "image": (img&&img[0]==="/")?img.substring(1):("assets/"+img), 
				"autoSize": 0, "fitSize": 1, "filter": "", "skipCreate": !state.hasImg
			},
			{
				"type": "text", "jaxId": "1FDH24MG010", "id": "TxtName", "x": "FW/2", "y": "FH+5", "w": 100, "h": 20, "anchorH": 1, "uiEvent": -1, "text": text, "color": [0,0,0], 
				"alignH": 1, "fontSize": appCfg.txtSize.smallMid
			},
			{
				"type": "text", "jaxId": "1FMB64J5Q0", "id": "TxtIcon", "x": 0, "y": 0, "w": 80, "h": 80, "display": img?0:1, "uiEvent": -1, "text": text[0], "color": [80,80,80], 
				"alignH": 1, "alignV": 1, "fontSize": 50, "bold": 1
			}
		],
		faces: {
			"up": {
				/*ImgIcon*/"#1FDH24MG08": {
					"y": w*0.1, "alpha": 1
				},
				/*TxtName*/"#1FDH24MG010": {
					"alpha": 1
				},
				/*TxtIcon*/"#1FMB64J5Q0": {
					"y": 0, "alpha": 1
				},
			},
			"down": {
				/*ImgIcon*/"#1FDH24MG08": {
					"y": w*0.1+2
				},
				/*TxtIcon*/"#1FMB64J5Q0": {
					"y": 2
				},
			},
			"gray": {
				/*ImgIcon*/"#1FDH24MG08": {
					"alpha": 0.5
				},
				/*TxtName*/"#1FDH24MG010": {
					"alpha": 0.5
				},
				/*TxtIcon*/"#1FMB64J5Q0": {
					"alpha": 0.5
				},
			}
		},
		OnCreate: function(){
			self=this;
			/*#{1FDH24MG02CreateFunc*/
			hudView=self.hudView;
			/*}#1FDH24MG02CreateFunc*/
		}
	};
	/*#{1FDH24MG02ExViewDef*/
	//------------------------------------------------------------------------
	//Handle mouse in/out
	cssVO.OnMouseInOut=function(isIn){
		if(self.tip && self.bar>0 && (!isMobile)){
			if(isIn){
				if(!barBox){
					barBox=hudView.blockBars[self.bar-1];
				}
				barBox.showTip(self,self.tip);
			}else{
				if(!barBox){
					barBox=hudView.blockBars[self.bar-1];
				}
				barBox.abortTip(self);
			}
		}
	};
	
	//------------------------------------------------------------------------
	//Show bar-bage:
	cssVO.showBar=function(text,color=[190,190,190,1],textColor=[0,0,0]){
		if(self.bageBar){
			self.removeChild(self.bageBar);
		}
		self.bageBar=self.appendNewChild({
			type:"box",x:3,y:"FW-19",w:"FW-6",h:16,color:color,coners:[0,0,w*0.2-3,w*0.2-3],
			items:[
				{type:"text",text:text,x:0,y:1,w:"FW",h:"FH","alignH":1,"alignV":1,fontSize:appCfg.txtSize.small,color:textColor,bold:1}
			]
		});
	};
	
	//------------------------------------------------------------------------
	//Remove bage:
	cssVO.hideBar=function(){
		if(self.bageBar){
			self.removeChild(self.bageBar);
		}
		self.bageBar=null;
	};
	
	/*}#1FDH24MG02ExViewDef*/
	
	return cssVO;
};

/*#{1FDH24MFV1PostCode*/
/*}#1FDH24MFV1PostCode*/

export {BtnApp};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"type": "object", "name": "BtnApp.js", "def": "CdyFileUIGear", "jaxId": "1FDH24MFV1", 
//			"attrs": {
//				"gearName": "\"BtnApp\"", "device": "iPhone 375x750", "w": "375", "h": "750", "desc": "\"\"", 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FDH24MG00", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FDH24MG01","entrys":[]}, "subs": []
//				}
//			}, 
//			"uiGear": {
//				"type": "object", "def": "HudBtn", "jaxId": "1FDH24MG02", 
//				"args": {
//					"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDH24MG03", 
//					"attrs": {
//						"w": {"type":"int","valText":"80","initVal":"","info":null,"tip":null}, 
//						"img": {
//							"type": "string", "valText": "\"home.svg\"", "initVal": "", "info": null, 
//							"tip": null
//						}, 
//						"text": {
//							"type": "string", "valText": "\"Home\"", "initVal": "", "info": null, 
//							"tip": null
//						}
//					}
//				}, 
//				"stateObj": {
//					"name": "stateObj", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FDH24MG04", 
//					"attrs": {"hasImg":{"type":"auto","valText":"1","info":"","tip":""}}, 
//					"funcs": {"jaxId":"1FDH24MG05","funcs":[]}
//				}, 
//				"attrs": {
//					"locked": "0", "id": "\"\"", "x": "#appCfg.size.btnNavi", "y": "80", "w": "#w", "h": "#w", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//					"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "drag": "NA", "enable": "On"
//				}, 
//				"viewFaces": {
//					"jaxId": "1FDH24MG06", 
//					"entrys": [
//						{
//							"jaxId": "1FDHA78Q70", "attrs": {"Face Name":"\"up\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDHA90JU0", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FDHA7GCF0", "attrs": {"Face Name":"\"down\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDHA90JU1", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						},
//						{
//							"jaxId": "1FRBFAKHU0", "attrs": {"Face Name":"\"gray\"","Face Function":"0"}, 
//							"state": {
//								"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRBFC66K0", 
//								"attrs": {}
//							}, 
//							"faceTimes": []
//						}
//					]
//				}, 
//				"funcs": {"jaxId":"1FDH24MG07","funcs":[]}, 
//				"btnHuds": {
//					"hudBtnUp": {
//						"type": "object", "def": "HudBox", "jaxId": "1FDHA2SPS0", 
//						"attrs": {
//							"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "#w", "h": "#w", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//							"clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[255,255,255,1]", "border": "3", "borderStyle": "Solid", 
//							"borderColor": "[100,100,100,1]", "coner": "#w*0.2", "gradient": "\"\"", "shadow": "0", "shadowX": "0", "shadowY": "2", "shadowBlur": "5", "shadowSpread": "0", 
//							"shadowColor": "[0,0,0,0.5]"
//						}, 
//						"funcs": {"jaxId":"1FDHA2SPS2","funcs":[]}, "subs": []
//					}, 
//					"hudBtnDown": {
//						"type": "object", "def": "HudBox", "jaxId": "1FDHA90JU2", 
//						"attrs": {
//							"locked": "0", "id": "\"\"", "x": "0", "y": "2", "w": "#w", "h": "#w", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//							"clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[255,255,255,1]", "border": "1", "borderStyle": "Solid", 
//							"borderColor": "#appCfg.color.highLight", "coner": "#w*0.2", "gradient": "\"\"", "shadow": "0", "shadowX": "0", "shadowY": "0", "shadowBlur": "3", 
//							"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//						}, 
//						"funcs": {"jaxId":"1FDHA90JU4","funcs":[]}, "subs": []
//					}
//				}, 
//				"subs": [
//					{
//						"type": "object", "def": "HudImage", "jaxId": "1FDH24MG08", 
//						"attrs": {
//							"locked": "0", "id": "\"ImgIcon\"", "x": "#w*0.1", "y": "#w*0.1", "w": "#w*0.8", "h": "#w*0.8", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//							"display": "Show", "clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "#(img&&img[0]===\"/\")?img.substring(1):(\"assets/\"+img)", 
//							"autoSize": "0", "fitSize": "1", "filter": "\"\"", 
//							"skipCreate": {"type":"auto","valText":"#!state.hasImg","info":null,"tip":null}
//						}, 
//						"faces": {
//							"jaxId": "1FDH258P40", 
//							"entrys": [
//								{
//									"jaxId": "1FDHA90JU5", "entryId": "1FDHA78Q70", "faceName": "up", 
//									"attrs": {"y":"#w*0.1","alpha":"1"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDHA90JU6", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FDHA90JU7", "entryId": "1FDHA7GCF0", "faceName": "down", 
//									"attrs": {"y":"#w*0.1+2"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDHA90JU8", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FRBFC66K1", "entryId": "1FRBFAKHU0", "faceName": "gray", 
//									"attrs": {"alpha":"0.5"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRBFC66K2", 
//										"attrs": []
//									}
//									
//								}
//							]
//						}, 
//						"funcs": {"jaxId":"1FDH24MG09","funcs":[]}, "subs": []
//					},
//					{
//						"type": "object", "def": "HudTxt", "jaxId": "1FDH24MG010", 
//						"attrs": {
//							"locked": "0", "id": "\"TxtName\"", "x": "\"FW/2\"", "y": "\"FH+5\"", "w": "100", "h": "20", "anchorH": "Center", "anchorV": "Top", "autoLayout": "Off", 
//							"display": "Show", "clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "#text", "color": "[0,0,0]", 
//							"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.smallMid", 
//							"bold": "0", "italic": "0", "underline": "0"
//						}, 
//						"faces": {
//							"jaxId": "1FRBCUP753", 
//							"entrys": [
//								{
//									"jaxId": "1FRBFC66K3", "entryId": "1FRBFAKHU0", "faceName": "gray", 
//									"attrs": {"alpha":"0.5"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRBFC66K4", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FRBFD3BS0", "entryId": "1FDHA78Q70", "faceName": "up", 
//									"attrs": {"alpha":"1"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRBFD3BS1", 
//										"attrs": []
//									}
//									
//								}
//							]
//						}, 
//						"funcs": {"jaxId":"1FDH24MG011","funcs":[]}, "subs": []
//					},
//					{
//						"type": "object", "def": "HudTxt", "jaxId": "1FMB64J5Q0", 
//						"attrs": {
//							"locked": "0", "id": "\"TxtIcon\"", "x": "0", "y": "0", "w": "80", "h": "80", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "#img?0:1", 
//							"clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "#text[0]", "color": "[80,80,80]", "autoSizeW": "0", 
//							"autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Center", "font": "\"\"", "fontSize": "50", "bold": "1", 
//							"italic": "0", "underline": "0"
//						}, 
//						"faces": {
//							"jaxId": "1FMB64J5Q1", 
//							"entrys": [
//								{
//									"jaxId": "1FMB6DKHR0", "entryId": "1FDHA7GCF0", "faceName": "down", 
//									"attrs": {"y":"2"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMB6DKHR1", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FMB6E9SP0", "entryId": "1FDHA78Q70", "faceName": "up", 
//									"attrs": {"y":"0","alpha":"1"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMB6E9SP1", 
//										"attrs": []
//									}
//									
//								},
//								{
//									"jaxId": "1FRBFC66K5", "entryId": "1FRBFAKHU0", "faceName": "gray", 
//									"attrs": {"alpha":"0.5"}, 
//									"anis": {
//										"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRBFC66K6", 
//										"attrs": []
//									}
//									
//								}
//							]
//						}, 
//						"funcs": {"jaxId":"1FMB64J5Q2","funcs":[]}, "subs": []
//					}
//				]
//			}
//		}/*Doc}#*/;
//	}