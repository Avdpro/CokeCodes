prj={
	"name": undefined, "appCfg": "cfg/appCfg.js", "txtLib": "text/textLib.js", "appData": "data/appData.js", "appHtml": "app.html", 
	"dataFiles": ["CCDisk.js","CCUser.js"], 
	"cssFiles": [
		"BtnNavi.js", "BtnStd.js", "BtnApp.js", "BtnIcon.js", "LabelNew.js", "BlkApp.js", "BlkHeader.js", "BtnQA.js"
	], 
	"uiFiles": ["WebHome.js","UIHome.js","dlgLogin.js","UIAccount.js","PhoneUI.js"], 
	"srcFiles": ["WebAPI.js","setupPrj.js"]
};
