//Auto genterated by Cody
import {$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FDBM50MC0Imports*/
/*}#1FDBM50MC0Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var WebHome1=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FDBM50MC1ExLocal*/
	/*}#1FDBM50MC1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FDBM50MC3ExState*/
		/*}#1FDBM50MC3ExState*/
	},);
	/*#{1FDBM50MC1PostState*/
	/*}#1FDBM50MC1PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FDBM50MC1", 
		"locked": 0, "w": "FW", "h": "FH", 
		items: [],
		faces: {
		},
		/*#{1FDBM50MC1ExAttrs*/
		/*}#1FDBM50MC1ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FDBM50MC1CreateFunc*/
			/*}#1FDBM50MC1CreateFunc*/
		
		}
	};
	/*#{1FDBM50MC1ExViewDef*/
	/*}#1FDBM50MC1ExViewDef*/
	
	return cssVO;
};

export {WebHome1};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "WebHome1.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FDBM50MC0", 
//			"attrs": {
//				"viewName": "\"WebHome1\"", "device": "iPhone 375x750", "w": "375", "h": "750", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FDBM50MC1", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBM50MC2", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FDBM50MC3", 
//						"attrs": {}, "funcs": {"jaxId":"1FDBM50MC4","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "0", "viewName": "\"uiView\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\""
//					}, 
//					"faces": null, "viewFaces": {"jaxId":"1FDBM50MC6","entrys":[]}, 
//					"funcs": {"jaxId":"1FDBM50MC7","funcs":[]}, "subs": []
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FDBM50MC8", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FDBM50MC10","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}