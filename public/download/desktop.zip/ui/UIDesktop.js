//Auto genterated by Cody
import {$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FDAD0DMF0Imports*/
/*}#1FDAD0DMF0Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var UIDesktop=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FDAD0DMF1ExLocal*/
	/*}#1FDAD0DMF1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FDAD0DMF3ExState*/
		/*}#1FDAD0DMF3ExState*/
	},);
	/*#{1FDAD0DMF1PostState*/
	/*}#1FDAD0DMF1PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FDAD0DMF1", 
		"locked": 0, "w": "FW", "h": "FH", 
		items: [],
		faces: {
		},
		/*#{1FDAD0DMF1ExAttrs*/
		/*}#1FDAD0DMF1ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FDAD0DMF1CreateFunc*/
			/*}#1FDAD0DMF1CreateFunc*/
		
		}
	};
	/*#{1FDAD0DMF1ExViewDef*/
	/*}#1FDAD0DMF1ExViewDef*/
	
	return cssVO;
};

export {UIDesktop};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "UIDesktop.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FDAD0DMF0", 
//			"attrs": {
//				"viewName": "\"UIDesktop\"", "device": "iPad 1024x768", "w": "1024", "h": "768", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FDAD0DMF1", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDAD0DMF2", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FDAD0DMF3", 
//						"attrs": {}, "funcs": {"jaxId":"1FDAD0DMF4","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "0", "viewName": "\"uiView\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\""
//					}, 
//					"faces": null, "viewFaces": {"jaxId":"1FDAD0DMF6","entrys":[]}, 
//					"funcs": {"jaxId":"1FDAD0DMF7","funcs":[]}, "subs": []
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FDAD0DMF8", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FDAD0DMF10","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}