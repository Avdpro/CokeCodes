//Auto genterated by Cody
import {$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
import {BtnStd} from "../gear/BtnStd.js";
/*#{1FDAD06P60Imports*/
import {CCWorker} from "../data/CCWorker.js";

const STAGE_CHECK="check";				//正在检查版本
const STAGE_INSTALL="install";			//需要安装
const STAGE_UPDATE="update";			//可以升级
const STAGE_WORK="work";				//正在安装/升级
const STAGE_ERROR="error";				//安装/升级发生了错误
const STAGE_CHECKED="checked";			//版本检测通过
const STAGE_INSTALLED="installed";		//安装完成
const STAGE_UPDATED="updated";			//升级完成
/*}#1FDAD06P60Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var UIInstall=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FDAD06P70ExLocal*/
	let showVO=null;
	let stage=null;
	/*}#1FDAD06P70ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FDAD06P72ExState*/
		/*}#1FDAD06P72ExState*/
	},);
	/*#{1FDAD06P70PostState*/
	/*}#1FDAD06P70PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FDAD06P70", 
		"locked": 0, "w": "FW", "h": "FH", "autoLayout": 1, 
		items: [
			{
				"type": "text", "jaxId": "1FDAETASS0", "id": "TextInfo", "x": 32, "y": 32, "w": 962, "h": 28, "text": "Checking dev-tools ...", "color": [0,0,0], 
				"fontSize": appCfg.txtSize.large
			},
			{
				"type": "hud", "jaxId": "1FDAETASS3", "id": "BoxVersions", "x": 32, "y": 80, "w": "FW-64", "h": 300, 
				items: [
					{
						"type": "text", "jaxId": "1FDADTGLO0", "id": "TxtWokerVsn", "w": 100, "text": "Service worker: not installed", "color": [0,0,0], "fontSize": appCfg.txtSize.mid
					},
					{
						"type": "text", "jaxId": "1FDADTHN00", "id": "TxtJAXVsn", "y": 32, "w": 100, "text": "JAX base lib: V0.3.1 / 02", "color": [0,0,0], "fontSize": appCfg.txtSize.mid
					},
					{
						"type": "text", "jaxId": "1FDAE37LE0", "id": "TxtExtVsn", "y": 64, "w": 100, "text": "Extern libs: V0.0.1 / 01", "color": [0,0,0], "fontSize": appCfg.txtSize.mid
					},
					{
						"type": BtnStd(app,150,"Install",null),"jaxId": "1FDAFVKI10", 
						"locked": 0, "id": "BtnInstall", "x": 0, "y": 240
					},
					{
						"type": "text", "jaxId": "1FDBSVU400", "id": "TxtDeskopVsn", "y": 96, "w": 100, "text": "CCDeskop: V0.0.1 / 01", "color": [0,0,0], "fontSize": appCfg.txtSize.mid
					},
					{
						"type": "text", "jaxId": "1FDBT2NI30", "id": "TxtDiskitVsn", "y": 128, "w": 100, "text": "CCDiskit: V0.0.1 / 01", "color": [0,0,0], "fontSize": appCfg.txtSize.mid
					},
					{
						"type": "text", "jaxId": "1FDBT4BNU0", "id": "TxtEditVsn", "y": 160, "w": 100, "text": "CCEdit: V0.0.1 / 01", "color": [0,0,0], "fontSize": appCfg.txtSize.mid
					},
					{
						"type": "text", "jaxId": "1FDBTA7IQ0", "id": "TxtCodyVsn", "y": 192, "w": 100, "text": "Cody: V0.0.1 / 01", "color": [0,0,0], "fontSize": appCfg.txtSize.mid
					}
				]
			}
		],
		faces: {
			"check": {
				"$":function(vo){
					/*#{1FDBIT1P10Func*/
					stage=STAGE_CHECK;
					/*}#1FDBIT1P10Func*/
				},
				/*TextInfo*/"#1FDAETASS0": {
					"text": "Checking dev-tools..."
				},
				/*BoxVersions*/"#1FDAETASS3": {
					"display": 0
				},
			},
			"install": {
				"$":function(vo){
					/*#{1FDBIUSNA0Func*/
					stage=STAGE_INSTALL;
					/*}#1FDBIUSNA0Func*/
				},
				/*TextInfo*/"#1FDAETASS0": {
					"text": "Install dev-tools"
				},
				/*BoxVersions*/"#1FDAETASS3": {
					"display": 1
				},
				/*BtnInstall*/"#1FDAFVKI10": {
					"%text": "Install"
				},
			},
			"update": {
				"$":function(vo){
					/*#{1FDBJ276J0Func*/
					stage=STAGE_UPDATE;
					/*}#1FDBJ276J0Func*/
				},
				/*TextInfo*/"#1FDAETASS0": {
					"text": "Dev-tools update available"
				},
				/*BoxVersions*/"#1FDAETASS3": {
					"display": 1
				},
				/*BtnInstall*/"#1FDAFVKI10": {
					"%text": "Update"
				},
			},
			"checked": {
				"$":function(vo){
					/*#{1FDBKAE2F0Func*/
					stage=STAGE_CHECKED;
					/*}#1FDBKAE2F0Func*/
				},
				/*TextInfo*/"#1FDAETASS0": {
					"text": "Your dev-tools is checked"
				},
				/*BoxVersions*/"#1FDAETASS3": {
					"display": 1
				},
				/*BtnInstall*/"#1FDAFVKI10": {
					"%text": "Done"
				},
			},
			"installed": {
				"$":function(vo){
					/*#{1FDBKDMT60Func*/
					stage=STAGE_INSTALLED;
					/*}#1FDBKDMT60Func*/
				},
				/*TextInfo*/"#1FDAETASS0": {
					"text": "Dev-tools installed"
				},
				/*BtnInstall*/"#1FDAFVKI10": {
					"%text": "Done"
				},
			},
			"updated": {
				"$":function(vo){
					/*#{1FDBKDTLG0Func*/
					stage=STAGE_UPDATED;
					/*}#1FDBKDTLG0Func*/
				},
				/*TextInfo*/"#1FDAETASS0": {
					"text": "Dev-tools updated"
				},
				/*BtnInstall*/"#1FDAFVKI10": {
					"%text": "Done"
				},
			},
			"error": {
				"$":function(vo){
					/*#{1FDBKRPJL0Func*/
					stage=STAGE_ERROR;
					/*}#1FDBKRPJL0Func*/
				},
				/*TextInfo*/"#1FDAETASS0": {
					"text": "Task failed by error"
				},
				/*BoxVersions*/"#1FDAETASS3": {
					"display": 1
				},
				/*BtnInstall*/"#1FDAFVKI10": {
					"%text": "Retry"
				},
			}
		},
		/*#{1FDAD06P70ExAttrs*/
		/*}#1FDAD06P70ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FDAD06P70CreateFunc*/
			/*}#1FDAD06P70CreateFunc*/
		
		}
	};
	/*#{1FDAD06P70ExViewDef*/
	//------------------------------------------------------------------------
	//显示界面:
	cssVO.showUI=function(vo){
		self.showFace("check");
		window.setTimeout(()=>{
			CCWorker.checkWorker().then(workerReady=>{
				//TODO: 得到JAXLib和JAXExt的版本号
				if(workerReady){
					self.TxtWokerVsn="Service worker installed.";
					self.checkDisks().then(()=>{
						//TODO: Code this:
						self.showFace("install");
					});
				}else{
					//Show install tool-chain UI
					self.showFace("install");
				}
			});
		},1000);
	};
	
	//------------------------------------------------------------------------
	//检查系统工具磁盘:
	cssVO.checkDisks=async function(){
		let libs;
		libs=await CCWorker.checkLibs();
		self.TxtJAXVsn.text="JAX framework: "+(libs.jaxlib?libs.jaxlib.version:"not installed.");
		self.TxtExtVsn.text="JAX external: "+(libs.jaxext?libs.jaxext.version:"not installed.");
		self.TxtDeskopVsn.text="CokeCodes Desktop: "+(libs.desktop?libs.desktop.version:" not installed.");
		self.TxtDiskitVsn.text="CC Distkit: "+(libs.diskit?libs.diskit.version:"not installed.");
		self.TxtEditVsn.text="CC Editor: "+(libs.ccedit?libs.ccedit.version:"not installed.");
		self.TxtCodyVsn.text="Cody Creator: "+(libs.cody?libs.cody.version:"not installed.");
	};
	
	/*}#1FDAD06P70ExViewDef*/
	
	return cssVO;
};

export {UIInstall};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "UIInstall.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FDAD06P60", 
//			"attrs": {
//				"viewName": "\"UIInstall\"", "device": "Custom size", "w": "1024", "h": "600", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FDAD06P70", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDAD06P71", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FDAD06P72", 
//						"attrs": {}, "funcs": {"jaxId":"1FDAD06P73","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "0", "viewName": "\"uiView\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "autoLayout": "On"
//					}, 
//					"faces": null, 
//					"viewFaces": {
//						"jaxId": "1FDAD06P75", 
//						"entrys": [
//							{
//								"jaxId": "1FDBIT1P10", "attrs": {"Face Name":"\"check\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBL4U8Q0", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FDBIUSNA0", 
//								"attrs": {"Face Name":"\"install\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBL4U8Q1", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FDBJ276J0", 
//								"attrs": {"Face Name":"\"update\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBL4U8Q2", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FDBKAE2F0", 
//								"attrs": {"Face Name":"\"checked\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBL4U8Q3", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FDBKDMT60", 
//								"attrs": {"Face Name":"\"installed\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBL4U8Q4", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FDBKDTLG0", 
//								"attrs": {"Face Name":"\"updated\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBL4U8Q5", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FDBKRPJL0", "attrs": {"Face Name":"\"error\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBL4U8Q6", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							}
//						]
//					}, 
//					"funcs": {"jaxId":"1FDAD06P76","funcs":[]}, 
//					"subs": [
//						{
//							"type": "object", "def": "HudTxt", "jaxId": "1FDAETASS0", 
//							"attrs": {
//								"locked": "0", "id": "\"TextInfo\"", "x": "32", "y": "32", "w": "962", "h": "28", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//								"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Checking dev-tools ...\"", "color": "[0,0,0]", 
//								"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.large", 
//								"bold": "0", "italic": "0", "underline": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FDAG9B4P1", 
//								"entrys": [
//									{
//										"jaxId": "1FDBL4U8Q7", "entryId": "1FDBIT1P10", "faceName": "check", 
//										"attrs": {"text":"\"Checking dev-tools...\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q8", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q9", "entryId": "1FDBJ276J0", "faceName": "update", 
//										"attrs": {"text":"\"Dev-tools update available\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q10", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q11", "entryId": "1FDBIUSNA0", "faceName": "install", 
//										"attrs": {"text":"\"Install dev-tools\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q12", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q13", "entryId": "1FDBKAE2F0", "faceName": "checked", 
//										"attrs": {"text":"\"Your dev-tools is checked\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q14", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q15", "entryId": "1FDBKDMT60", "faceName": "installed", 
//										"attrs": {"text":"\"Dev-tools installed\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q16", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q17", "entryId": "1FDBKDTLG0", "faceName": "updated", 
//										"attrs": {"text":"\"Dev-tools updated\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q18", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q19", "entryId": "1FDBKRPJL0", "faceName": "error", 
//										"attrs": {"text":"\"Task failed by error\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q20", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FDAETASS2","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FDAETASS3", 
//							"attrs": {
//								"locked": "0", "id": "\"BoxVersions\"", "x": "32", "y": "80", "w": "\"FW-64\"", "h": "300", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FDAG9B4P2", 
//								"entrys": [
//									{
//										"jaxId": "1FDBL4U8Q21", "entryId": "1FDBIT1P10", "faceName": "check", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q22", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q23", "entryId": "1FDBJ276J0", "faceName": "update", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q24", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q25", "entryId": "1FDBIUSNA0", "faceName": "install", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q26", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q27", "entryId": "1FDBKAE2F0", "faceName": "checked", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q28", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDBL4U8Q29", "entryId": "1FDBKRPJL0", "faceName": "error", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q30", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FDAETASS5","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDADTGLO0", 
//									"attrs": {
//										"locked": "1", "id": "\"TxtWokerVsn\"", "x": "0", "y": "0", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Service worker: not installed\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.mid", "bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDADTGLO2","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDADTHN00", 
//									"attrs": {
//										"locked": "1", "id": "\"TxtJAXVsn\"", "x": "0", "y": "32", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"JAX base lib: V0.3.1 / 02\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.mid", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDADTHN10","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDAE37LE0", 
//									"attrs": {
//										"locked": "1", "id": "\"TxtExtVsn\"", "x": "0", "y": "64", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Extern libs: V0.0.1 / 01\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.mid", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDAE37LE1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FDAETMLJ0", "jaxId": "1FDAFVKI10", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDAFVKI11", 
//										"attrs": {
//											"w": {"type":"int","valText":"150","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"Install\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDAFVKI12", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnInstall\"", "x": "0", "y": "240", "autoLayout": "Off"
//									}, 
//									"faces": {
//										"jaxId": "1FDAG9B4P6", 
//										"entrys": [
//											{
//												"jaxId": "1FDBL4U8Q31", "entryId": "1FDBIUSNA0", "faceName": "install", 
//												"attrs": {"[state].text":"\"Install\""}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q32", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDBL4U8Q33", "entryId": "1FDBJ276J0", "faceName": "update", 
//												"attrs": {"[state].text":"\"Update\""}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q34", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDBL4U8Q35", "entryId": "1FDBKAE2F0", "faceName": "checked", 
//												"attrs": {"[state].text":"\"Done\""}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q36", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDBL4U8Q37", "entryId": "1FDBKDMT60", "faceName": "installed", 
//												"attrs": {"[state].text":"\"Done\""}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q38", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDBL4U8Q39", "entryId": "1FDBKDTLG0", "faceName": "updated", 
//												"attrs": {"[state].text":"\"Done\""}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q40", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDBL4U8Q41", "entryId": "1FDBKRPJL0", "faceName": "error", 
//												"attrs": {"[state].text":"\"Retry\""}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDBL4U8Q42", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FDAFVKI14","funcs":[]}
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDBSVU400", 
//									"attrs": {
//										"locked": "1", "id": "\"TxtDeskopVsn\"", "x": "0", "y": "96", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"CCDeskop: V0.0.1 / 01\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.mid", "bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDBSVU410","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDBT2NI30", 
//									"attrs": {
//										"locked": "1", "id": "\"TxtDiskitVsn\"", "x": "0", "y": "128", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"CCDiskit: V0.0.1 / 01\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.mid", "bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDBT2NI40","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDBT4BNU0", 
//									"attrs": {
//										"locked": "1", "id": "\"TxtEditVsn\"", "x": "0", "y": "160", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"CCEdit: V0.0.1 / 01\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.mid", "bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDBT4BNV0","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDBTA7IQ0", 
//									"attrs": {
//										"locked": "1", "id": "\"TxtCodyVsn\"", "x": "0", "y": "192", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Cody: V0.0.1 / 01\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.mid", "bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDBTA7IR0","funcs":[]}, "subs": []
//								}
//							]
//							
//						}
//					]
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FDAD06P77", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FDAD06P79","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}