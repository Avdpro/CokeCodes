//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
import {BtnApp} from "../gear/BtnApp.js";
/*#{1FP88D6A60Imports*/
import {JAXDisk} from "/jaxweb/lib/JAXDisk.js";
import pathLib from "/jaxweb/lib/JAXPath.js";
import markdownit from "/@markdownit";
/*}#1FP88D6A60Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var PhoneUI=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FP88D6A61ExLocal*/
	/*}#1FP88D6A61ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FP88D6A63ExState*/
		/*}#1FP88D6A63ExState*/
	},);
	/*#{1FP88D6A61PostState*/
	/*}#1FP88D6A61PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FP88D6A61", 
		"locked": 0, "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, 
		items: [
			{
				"type": "hud", "jaxId": "1FP88F2V90", "id": "BoxTitle", "x": 0, "y": 0, "w": "FW", "h": appCfg.size.titleBoxH, 
				items: [
					{
						"type": "text", "jaxId": "1FP88F2V92", "id": "TxtTitle", "x": 0, "y": 10, "w": "FW", "h": 60, "text": "CokeCodes", "color": [0,0,0], "alignH": 1, 
						"alignV": 1, "fontSize": appCfg.txtSize.huge
					},
					{
						"type": "text", "jaxId": "1FP88G9DQ0", "x": 0, "y": 30, "w": "FW", "h": 60, "autoLayout": 1, "text": "CONCEPT PREVIEW", "color": [100,100,100], 
						"alignH": 1, "alignV": 2, "fontSize": appCfg.txtSize.big
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FP89SULH0", "x": 0, "y": 100, "w": "FW", "h": "FH-100", 
				items: [
					{
						"type": "text", "jaxId": "1FP89A50I0", "x": 0, "y": 20, "w": "FW", "h": 30, "text": "Applications", "color": [100,100,100], "alignH": 1, "alignV": 1, 
						"fontSize": 24
					},
					{
						"type": BtnApp(app,80,"terminal.svg","Terminal",null),"jaxId": "1FP88V08B0", 
						"locked": 0, "id": "BtnTerminal", "x": "FW/2-80-80", "y": 66, 
						//函数
						OnClick:function(){
							/*#{1FP88V08B4Code*/
							app.DoOpenDiskApp("terminal");
							/*}#1FP88V08B4Code*/
						}
					},
					{
						"type": BtnApp(app,80,"edit.svg","CCEdit",null),"jaxId": "1FP88VCIM0", 
						"locked": 0, "id": "BtnDiskit", "x": "FW/2+80", "y": 66, 
						//函数
						OnClick:function(){
							/*#{1FP88VCIM4Code*/
							app.DoOpenDiskApp("ccedit");
							/*}#1FP88VCIM4Code*/
						}
					},
					{
						"type": BtnApp(app,80,"disk.svg","Diskit",null),"jaxId": "1FP88VH6D0", 
						"locked": 0, "id": "BtnDiskit", "x": "FW/2-40", "y": 66, 
						//函数
						OnClick:function(){
							/*#{1FP88VH6D4Code*/
							app.DoOpenDiskApp("diskit");
							/*}#1FP88VH6D4Code*/
						}
					},
					{
						"type": "text", "jaxId": "1FP895E3D0", "x": 0, "y": 200, "w": "FW", "h": 24, "cursor": "pointer", "text": "About CokeCodes", "color": [0,0,0], "select": 1, 
						"alignH": 1, "fontSize": appCfg.txtSize.big, "underline": 1, 
						//函数
						OnClick:function(){
							/*#{1FP895E3E1Code*/
							let path;
							path=pathLib.join(app.appDir,"cokecodes.md");
							window.open(document.location.origin+"/@markdownit/mdview.html#file="+encodeURIComponent(path),`MDView_${path}`);
							/*}#1FP895E3E1Code*/
						}
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FPE4P7DG0", "id": "BoxTip", "x": 20, "y": 360, "w": "FW-40", "h": 300
			}
		],
		faces: {
		},
		/*#{1FP88D6A61ExAttrs*/
		/*}#1FP88D6A61ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FP88D6A61CreateFunc*/
			self.showTip();
			/*}#1FP88D6A61CreateFunc*/
		
		}
	};
	/*#{1FP88D6A61ExViewDef*/
	//------------------------------------------------------------------------
	//Show tip markdown file:
	cssVO.showTip=async function(){
		let path=pathLib.join(app.dirPath,"tipmobile.md");
		try{
			let text=await JAXDisk.readFile(path,"utf8");
			text=markdownit().render(text);
			this.BoxTip.webObj.innerHTML=text;
		}catch(err){
		}
	};
	/*}#1FP88D6A61ExViewDef*/
	
	return cssVO;
};

/*#{1FP88D6A60PostCode*/
/*}#1FP88D6A60PostCode*/

export {PhoneUI};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "PhoneUI.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FP88D6A60", 
//			"attrs": {
//				"viewName": "\"PhoneUI\"", "device": "iPhone 375x750", "w": "375", "h": "750", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FP88D6A61", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88D6A62", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FP88D6A63", 
//						"attrs": {}, "funcs": {"jaxId":"1FP88D6A64","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "0", "viewName": "\"uiView\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "autoLayout": "On"
//					}, 
//					"faces": null, "viewFaces": {"jaxId":"1FP88D6A70","entrys":[]}, 
//					"funcs": {"jaxId":"1FP88D6A71","funcs":[]}, 
//					"subs": [
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FP88F2V90", 
//							"attrs": {
//								"locked": "1", "id": "\"BoxTitle\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "#appCfg.size.titleBoxH", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FP88F2V91","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FP88F2V92", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtTitle\"", "x": "0", "y": "10", "w": "\"FW\"", "h": "60", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"CokeCodes\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Center", "font": "\"\"", "fontSize": "#appCfg.txtSize.huge", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FP88F2V93","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FP88G9DQ0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "30", "w": "\"FW\"", "h": "60", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"CONCEPT PREVIEW\"", "color": "[100,100,100]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Bottom", "font": "\"\"", "fontSize": "#appCfg.txtSize.big", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FP88G9DQ1","funcs":[]}, "subs": []
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FP89SULH0", 
//							"attrs": {
//								"locked": "1", "id": "\"\"", "x": "0", "y": "100", "w": "\"FW\"", "h": "\"FH-100\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FP89SULH2","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FP89A50I0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "20", "w": "\"FW\"", "h": "30", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Applications\"", "color": "[100,100,100]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Center", "font": "\"\"", "fontSize": "24", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FP89A50I1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FP88V08B0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88V08B1", 
//										"attrs": {
//											"w": {"type":"int","valText":"80","initVal":0,"info":null,"tip":null}, 
//											"img": {
//												"type": "string", "valText": "\"terminal.svg\"", "initVal": "", 
//												"info": null, "tip": null
//											}, 
//											"text": {
//												"type": "string", "valText": "\"Terminal\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88V08B2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnTerminal\"", "x": "\"FW/2-80-80\"", "y": "66", "autoLayout": "Off"
//									}, 
//									"faces": null, 
//									"funcs": {
//										"jaxId": "1FP88V08B3", 
//										"funcs": [
//											{
//												"jaxId": "1FP88V08B4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88V08B5", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FP88VCIM0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88VCIM1", 
//										"attrs": {
//											"w": {"type":"int","valText":"80","initVal":0,"info":null,"tip":null}, 
//											"img": {
//												"type": "string", "valText": "\"edit.svg\"", "initVal": "", "info": null, 
//												"tip": null
//											}, 
//											"text": {
//												"type": "string", "valText": "\"CCEdit\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88VCIM2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnDiskit\"", "x": "\"FW/2+80\"", "y": "66", "autoLayout": "Off"
//									}, 
//									"faces": null, 
//									"funcs": {
//										"jaxId": "1FP88VCIM3", 
//										"funcs": [
//											{
//												"jaxId": "1FP88VCIM4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88VCIM5", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FP88VH6D0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88VH6D1", 
//										"attrs": {
//											"w": {"type":"int","valText":"80","initVal":0,"info":null,"tip":null}, 
//											"img": {
//												"type": "string", "valText": "\"disk.svg\"", "initVal": "", "info": null, 
//												"tip": null
//											}, 
//											"text": {
//												"type": "string", "valText": "\"Diskit\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88VH6D2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnDiskit\"", "x": "\"FW/2-40\"", "y": "66", "autoLayout": "Off"
//									}, 
//									"faces": null, 
//									"funcs": {
//										"jaxId": "1FP88VH6D3", 
//										"funcs": [
//											{
//												"jaxId": "1FP88VH6D4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP88VH6D5", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FP895E3D0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "200", "w": "\"FW\"", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "text": "\"About CokeCodes\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "1", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.big", 
//										"bold": "0", "italic": "0", "underline": "1"
//									}, 
//									"funcs": {
//										"jaxId": "1FP895E3E0", 
//										"funcs": [
//											{
//												"jaxId": "1FP895E3E1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FP895E3E2", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}, 
//									"subs": []
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FPE4P7DG0", 
//							"attrs": {
//								"locked": "0", "id": "\"BoxTip\"", "x": "20", "y": "360", "w": "\"FW-40\"", "h": "300", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FPE4Q3JV12","funcs":[]}, "subs": []
//						}
//					]
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FP88D6A72", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FP88D6A74","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}