//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
/*#{1FMHD293N0Imports*/
import cokeNT from "/@cokecodes/cokeNT.js";
import pathLib from "/jaxweb/utils/path.js";
import markdownit from "/@markdownit/markdown-it.min.mjs";
/*}#1FMHD293N0Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var UIAccount=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FMHD293N1ExLocal*/
	/*}#1FMHD293N1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FMHD293N3ExState*/
		/*}#1FMHD293N3ExState*/
	},);
	/*#{1FMHD293N1PostState*/
	/*}#1FMHD293N1PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FMHD293N1", 
		"locked": 0, "x": 0, "y": 0, "w": "FW", "h": "FH", 
		items: [
			{
				"type": "image", "jaxId": "1FRRCCD0R0", "x": "FW-530", "y": "FH-500", "w": 500, "h": 500, "autoLayout": 1, "alpha": 0.2, "image": "assets/cloud.svg", 
				"autoSize": 0, "fitSize": 1
			},
			{
				"type": "hud", "jaxId": "1FRRAELID3", "id": "BoxOfflineInfo", "x": 20, "y": 20, "w": "FW-40", "h": "FH-40"
			},
			{
				"type": "scroll", "jaxId": "1FMHDP7F50", "x": 0, "y": 0, "w": "FW", "h": "FH", "column": 1, "id": "BoxCloud", 
				subs:[
					{
						"type": "hud", "jaxId": "1FMHDP7F53", "x": 0, "y": 0, "w": 100, "h": 20
					},
					{
						"type": "text", "jaxId": "1FMHD8P6H0", "id": "TxtAccount", "x": 20, "y": 0, "w": 100, "h": 24, "text": "Account: ", "color": [0,0,0], "fontSize": appCfg.txtSize.midder, 
						"bold": 1
					},
					{
						"type": "hud", "jaxId": "1FMHD9D5D0", "x": 0, "y": 0, "w": 100, "h": 10
					},
					{
						"type": "text", "jaxId": "1FMHD8PU80", "id": "TxtName", "x": 20, "y": 0, "w": 100, "h": 24, "text": "User name: ", "color": [0,0,0], "fontSize": appCfg.txtSize.midder, 
						"bold": 1
					},
					{
						"type": "hud", "jaxId": "1FMHD9E1S0", "x": 0, "y": 0, "w": 100, "h": 10
					},
					{
						"type": "text", "jaxId": "1FMHD9U7E0", "id": "TxtRank", "x": 20, "y": 0, "w": 100, "h": 24, "text": "Rank: ", "color": [0,0,0], "fontSize": appCfg.txtSize.midder, 
						"bold": 1
					},
					{
						"type": "hud", "jaxId": "1FMHDFC1K0", "x": 0, "y": 0, "w": 100, "h": 10
					},
					{
						"type": "text", "jaxId": "1FMHDFEF50", "id": "TxtCloud", "x": 20, "y": 0, "w": 100, "h": 24, "text": "Cloud disks: ", "color": [0,0,0], "fontSize": appCfg.txtSize.midder, 
						"bold": 1
					},
					{
						"type": "hud", "jaxId": "1FRRA72980", "x": 0, "y": 0, "w": 100, "h": 10
					},
					{
						"type": "text", "jaxId": "1FRRA7BAN0", "id": "TxtFileSize", "x": 20, "y": 0, "w": 100, "h": 24, "text": "Cloud single file size: limited", "color": [0,0,0], 
						"fontSize": appCfg.txtSize.midder, "bold": 1
					},
					{
						"type": "hud", "jaxId": "1FRRAF2O00", "x": 0, "y": 0, "w": 100, "h": 10
					},
					{
						"type": "text", "jaxId": "1FRRAEQ4G0", "id": "TxtDiskSize", "x": 20, "y": 0, "w": 100, "h": 24, "text": "Cloud disk size: limited", "color": [0,0,0], 
						"fontSize": appCfg.txtSize.midder, "bold": 1
					},
					{
						"type": "hud", "jaxId": "1FRRAE5HQ0", "x": 0, "y": 0, "w": 100, "h": 20
					},
					{
						"type": "hud", "jaxId": "1FRRA99AE0", "id": "BoxOnlineInfo", "x": 10, "y": 0, "w": "FW-20", "h": 200
					},
				]
			},
			{
				"type": "image", "jaxId": "1FRRCEGBJ0", "x": "FW-320", "y": "FH-672", "w": 300, "h": 300, "autoLayout": 1, "alpha": 0.2, "image": "assets/cloud.svg", 
				"autoSize": 0, "fitSize": 1
			}
		],
		faces: {
			"online": {
				/*BoxOfflineInfo*/"#1FRRAELID3": {
					"display": 0
				},
				/*BoxCloud*/"#1FMHDP7F50": {
					"display": 1
				},
			},
			"offline": {
				/*BoxOfflineInfo*/"#1FRRAELID3": {
					"display": 1
				},
				/*BoxCloud*/"#1FMHDP7F50": {
					"display": 0
				},
			}
		},
		/*#{1FMHD293N1ExAttrs*/
		/*}#1FMHD293N1ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FMHD293N1CreateFunc*/
			self.renderMD(document.location.origin+app.appDir+"/offlinetip.md",self.BoxOfflineInfo.webObj,"url");
			self.renderMD(document.location.origin+app.appDir+"/onlinetip.md",self.BoxOnlineInfo.webObj,"url");
			/*}#1FMHD293N1CreateFunc*/
		
		}
	};
	/*#{1FMHD293N1ExViewDef*/
	cssVO.renderMD=async function(path,tgtDiv,mode){
		let text,div,lnkPath,hrefPath,baseDir;
		try{
			text= await (await fetch(path)).text();
		}catch(err){
			text=`### Error in reading ${path}: ${err}`;
		}
		if(!text){
			let text="# Hello Markdown!";
		}
		baseDir=pathLib.dirname(path);
		let md=markdownit();
		text=md.render(text);
		div=tgtDiv;
		div.style.maxWidth="800px";
		div.innerHTML =text;
		//Deal with links:
		let tags=div.getElementsByTagName("a");
		for(let tag of tags){
			hrefPath=tag.href;
			lnkPath=tag.attributes.href.nodeValue||tag.attributes.href.value;
			if(pathLib.extname(lnkPath)===".md"){
				tag.onclick=function(evt){
					let pos=baseDir.lastIndexOf("//");
					let lnkPath=tag.attributes.href.nodeValue||tag.attributes.href.value;
					if(pos>=0){
						self.openLink(baseDir.substring(0,pos+2)+pathLib.join(baseDir.substring(pos+2),lnkPath));
					}else{
						self.openLink(pathLib.join(baseDir,lnkPath));
					}
					evt.stopPropagation();
					evt.preventDefault();
				};
			}else{
				tag.target="_blank";
				tag.rel="noopener noreferrer";
			}
		}
		tags=div.getElementsByTagName("img");
		for(let tag of tags){
			hrefPath=tag.src;
			lnkPath=tag.attributes.src.nodeValue||tag.attributes.href.value;
			if(lnkPath.indexOf("://")<0){
				let pos=baseDir.lastIndexOf("//");
				tag.src=baseDir.substring(0,pos+2)+pathLib.join(baseDir.substring(pos+2),lnkPath);
			}
			tag.style.maxWidth="780px";
		}
	}

	cssVO.showUI=function(vo){
		if(cokeNT.loginDone){
			let loginVO=cokeNT.loginVO;
			self.TxtAccount.text="Account: "+loginVO.email;
			self.TxtName.text="User name: "+loginVO.name;
			self.TxtRank.text="Rank: "+loginVO.rank;
			self.TxtCloud.text="Coud disks: "+loginVO.disks.length;
			switch(loginVO.rank){
				case "GUEST":
					break
				case "MEMBER":
					break
				case "MASTER":
					break
				case "LORD":
					break
			}
			self.showFace("online");
		}else{
			self.TxtAccount.text="Account: Offline";
			self.TxtName.text="User name: NA";
			self.TxtRank.text="Rank: NA";
			self.TxtCloud.text="Coud disks: NA";
			self.showFace("offline");
		}
	};
	
	/*}#1FMHD293N1ExViewDef*/
	
	return cssVO;
};

/*#{1FMHD293N0PostCode*/
/*}#1FMHD293N0PostCode*/

export {UIAccount};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "UIAccount.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FMHD293N0", 
//			"attrs": {
//				"viewName": "\"UIAccount\"", "device": "iPad 1024x768", "w": "1024", "h": "768", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FMHD293N1", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHD293N2", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FMHD293N3", 
//						"attrs": {}, "funcs": {"jaxId":"1FMHD293N4","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "0", "viewName": "\"uiView\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\""
//					}, 
//					"faces": null, 
//					"viewFaces": {
//						"jaxId": "1FMHD293N6", 
//						"entrys": [
//							{
//								"jaxId": "1FRR8KBOG0", 
//								"attrs": {"Face Name":"\"online\"","Face Function":"0"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRRAELID1", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FRR8KK370", 
//								"attrs": {"Face Name":"\"offline\"","Face Function":"0"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRRAELID2", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							}
//						]
//					}, 
//					"funcs": {"jaxId":"1FMHD293N7","funcs":[]}, 
//					"subs": [
//						{
//							"type": "object", "def": "HudImage", "jaxId": "1FRRCCD0R0", 
//							"attrs": {
//								"locked": "0", "id": "\"\"", "x": "\"FW-530\"", "y": "\"FH-500\"", "w": "500", "h": "500", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "0.2", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "assets/cloud.svg", 
//								"autoSize": "0", "fitSize": "1"
//							}, 
//							"funcs": {"jaxId":"1FRRCCD0R2","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FRRAELID3", 
//							"attrs": {
//								"locked": "0", "id": "\"BoxOfflineInfo\"", "x": "20", "y": "20", "w": "\"FW-40\"", "h": "\"FH-40\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FRRAELID4", 
//								"entrys": [
//									{
//										"jaxId": "1FRRAELID5", "entryId": "1FRR8KBOG0", "faceName": "online", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRRAELID6", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRRAELID7", "entryId": "1FRR8KK370", "faceName": "offline", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRRAELID8", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FRRAELID9","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudScrollBox", "jaxId": "1FMHDP7F50", 
//							"attrs": {
//								"locked": "0", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "column": "1", "cursor": "\"\"", "zIndex": "0", "id": "\"BoxCloud\""
//							}, 
//							"faces": {
//								"jaxId": "1FRRAELIE0", 
//								"entrys": [
//									{
//										"jaxId": "1FRRAELIE1", "entryId": "1FRR8KBOG0", "faceName": "online", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRRAELIE2", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRRAELIE3", "entryId": "1FRR8KK370", "faceName": "offline", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRRAELIE4", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FMHDP7F52","funcs":[]}, 
//							"subGroup": [
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FMHDP7F53", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHDP7F55","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FMHD8P6H0", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtAccount\"", "x": "20", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Account: \"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.midder", 
//										"bold": "1", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHD8P6H2","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FMHD9D5D0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "10", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHD9D5D2","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FMHD8PU80", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtName\"", "x": "20", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"User name: \"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.midder", 
//										"bold": "1", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHD8PU81","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FMHD9E1S0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "10", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHD9E1S1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FMHD9U7E0", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtRank\"", "x": "20", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Rank: \"", "color": "[0,0,0]", "autoSizeW": "0", 
//										"autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.midder", 
//										"bold": "1", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHD9U7E1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FMHDFC1K0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "10", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHDFC1K1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FMHDFEF50", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtCloud\"", "x": "20", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Cloud disks: \"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.midder", 
//										"bold": "1", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FMHDFEF60","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FRRA72980", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "10", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FRRA72981","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FRRA7BAN0", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtFileSize\"", "x": "20", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Cloud single file size: limited\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.midder", "bold": "1", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FRRA7BAN1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FRRAF2O00", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "10", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FRRAF2O01","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FRRAEQ4G0", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtDiskSize\"", "x": "20", "y": "0", "w": "100", "h": "24", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Cloud disk size: limited\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.midder", "bold": "1", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FRRAEQ4G1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FRRAE5HQ0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FRRAE5HQ1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FRRA99AE0", 
//									"attrs": {
//										"locked": "0", "id": "\"BoxOnlineInfo\"", "x": "10", "y": "0", "w": "\"FW-20\"", "h": "200", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//									}, 
//									"funcs": {"jaxId":"1FRRA99AF0","funcs":[]}, "subs": []
//								}
//							], 
//							"subs": []
//						},
//						{
//							"type": "object", "def": "HudImage", "jaxId": "1FRRCEGBJ0", 
//							"attrs": {
//								"locked": "0", "id": "\"\"", "x": "\"FW-320\"", "y": "\"FH-672\"", "w": "300", "h": "300", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "0.2", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "assets/cloud.svg", 
//								"autoSize": "0", "fitSize": "1"
//							}, 
//							"funcs": {"jaxId":"1FRRCEGBJ1","funcs":[]}, "subs": []
//						}
//					]
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FMHD293N8", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FMHD293N10","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}