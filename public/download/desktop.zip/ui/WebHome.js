//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
import {BtnNavi} from "../gear/BtnNavi.js";
/*#{1FD93OB830Imports*/
import {UIHome} from "./UIHome.js";
import {UIAccount} from "./UIAccount.js";
import {dlgLogin} from "./dlgLogin.js";
import {MainUI as UIBook} from "/@markbook/ui/MainUI.js";
import pathLib from "/jaxweb/lib/JAXPath.js";
import cokeNT from "/@cokecodes/cokeNT.js";
/*}#1FD93OB830Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var WebHome=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FD93OB831ExLocal*/
	let uiDock;
	let uiHome,uiAccount,uiDocs;
	let curTab,curTabBtn,curTabUI;
	/*}#1FD93OB831ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FD93OB833ExState*/
		/*}#1FD93OB833ExState*/
	},);
	/*#{1FD93OB831PostState*/
	/*}#1FD93OB831PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FD93OB831", 
		"locked": 0, "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, 
		items: [
			{
				"type": "box", "jaxId": "1FQU69HI60", "id": "BodyBG", "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, "color": appCfg.color.pageBG, "shadowColor": [0,0,0,0.5]
			},
			{
				"type": "dock", "jaxId": "1FD99SIV51", "id": "UIDock", "x": 0, "y": appCfg.size.titleBoxH, "w": "FW", "h": "FH-"+(appCfg.size.titleBoxH), "ui": -1, 
				"autoLayout": 1
			},
			{
				"type": "box", "jaxId": "1FQU4FBHJ1", "id": "HeadBG", "x": 0, "y": 0, "w": "FW", "h": 64, "autoLayout": 1, "color": appCfg.color.headBG, "shadowColor": [0,0,0,0.5]
			},
			{
				"type": "hud", "jaxId": "1FD95JDDL0", "id": "BoxTitle", "x": 0, "y": 0, "w": "FW", "h": appCfg.size.titleBoxH, 
				items: [
					{
						"type": "image", "jaxId": "1FQU4FBHJ7", "id": "ImgLogo", "x": 8, "y": 7, "w": 50, "h": 50, "image": "assets/cklogo_dark.svg", "autoSize": 0, "fitSize": 1
					},
					{
						"type": "image", "jaxId": "1FQU4FBHJ10", "id": "ImgTitle", "x": 63, "y": 7, "w": 150, "h": 50, "image": "assets/cklogo_text.svg", "autoSize": 0, 
						"fitSize": 1
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FD987EU55", "id": "BoxNavi", "x": 230, "y": 0, "w": "FW-150", "h": appCfg.size.titleBoxH, 
				items: [
					{
						"type": BtnNavi(app,"home.svg","Home",null),"jaxId": "1FD995OGR0", 
						"locked": 0, "id": "BtnHome", "x": 0, "y": 48, 
						//函数
						OnClick:function(){
							/*#{1FMHF4OT90Code*/
							self.showUITab("Home");
							/*}#1FMHF4OT90Code*/
						}
					},
					{
						"type": BtnNavi(app,"user.svg","Docs",null),"jaxId": "1FQU5NL5I0", 
						"locked": 0, "id": "BtnDocs", "x": 80, "y": 48, 
						//函数
						OnClick:function(){
							/*#{1FQU5NL5J1Code*/
							self.showUITab("Docs");
							/*let path;
							path=pathLib.join(app.appDir,"cokecodes.md");
							window.open(document.location.origin+"/@markdownit/mdview.html#file="+encodeURIComponent(path),`MDView_${path}`);*/
							/*}#1FQU5NL5J1Code*/
						}
					},
					{
						"type": BtnNavi(app,"user.svg","Account",null),"jaxId": "1FD995QSG0", 
						"locked": 0, "id": "BtnAccount", "x": 160, "y": 48, 
						//函数
						OnClick:function(){
							/*#{1FMHF4OT92Code*/
							self.showUITab("Account");
							/*}#1FMHF4OT92Code*/
						}
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FD95JDDL1", "id": "BoxUser", "x": "FW-20", "y": 0, "w": 70, "h": 64, "anchorH": 2, "autoLayout": 1, 
				items: [
					{
						"type": "button", "jaxId": "1FDU39AKU0", "id": "BtnUser", "x": "FW-10-"+appCfg.size.userPhoto, "y": "FH/2", "w": appCfg.size.userPhoto, "h": appCfg.size.userPhoto, 
						"anchorV": 1, "cursor": "pointer", 
						"hudBtnDown": {
							"type": "box", "jaxId": "1FDU39AKU3", "x": -3, "y": -3, "w": appCfg.size.userPhoto+6, "h": appCfg.size.userPhoto+6, "uiEvent": -1, "color": appCfg.color.headSub, 
							"border": 5, "borderColor": [0,157,255,1], "coner": appCfg.size.userPhoto*0.5+3, "shadowColor": [0,0,0,0.5]
						},
						items: [
							{
								"type": "box", "jaxId": "1FDU359O50", "x": 0, "y": 0, "w": "FW", "h": "FH", "uiEvent": -1, "color": appCfg.color.headSub, "coner": appCfg.size.userPhoto*0.5, 
								"shadowColor": [0,0,0,0.5]
							},
							{
								"type": "text", "jaxId": "1FDU33O040", "id": "TxtUserCh", "x": 0, "y": 0, "w": 50, "h": 50, "uiEvent": -1, "text": "G", "color": [255,255,255], 
								"alignH": 1, "alignV": 1, "fontSize": appCfg.txtSize.larger
							},
							{
								"type": "text", "jaxId": "1FDU33UK30", "id": "TxtUserName", "x": -10, "y": 0, "w": 100, "h": 50, "anchorH": 2, "uiEvent": -1, "text": "Guest", 
								"color": appCfg.color.headSub, "alignH": 2, "alignV": 1, "fontSize": appCfg.txtSize.big
							}
						],
						//函数
						OnClick:function(){
							/*#{1FDU3SAGI0Code*/
							self.OnUserClick();
							/*}#1FDU3SAGI0Code*/
						}
					}
				]
			}
		],
		faces: {
			"mobile": {
				/*ImgTitle*/"#1FQU4FBHJ10": {
					"display": 0
				},
				/*BoxNavi*/"#1FD987EU55": {
					"x": 60
				},
				/*BtnDocs*/"#1FQU5NL5I0": {
					"x": 64
				},
				/*BtnAccount*/"#1FD995QSG0": {
					"display": 0
				},
				/*BoxUser*/"#1FD95JDDL1": {
					"x": "FW-5"
				},
				/*TxtUserName*/"#1FDU33UK30": {
					"display": 0
				},
			}
		},
		/*#{1FD93OB831ExAttrs*/
		/*}#1FD93OB831ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FD93OB831CreateFunc*/
			if(self.w<550){
				self.showFace("mobile");
			}
			uiDock=self.UIDock;
			uiDock.webObj.style.overflowX="hidden";
			uiDock.webObj.style.overflowY="scroll";

			self.showUITab("Home");
			cokeNT.onNotify("Online",this.OnNTOnline.bind(this));
			cokeNT.onNotify("Offline",this.OnNTOffline.bind(this));
			self.checkLogin();
			self.BtnAccount.showFace("blur");
			self.BtnDocs.showFace("blur");
			//self.BtnDocs.enable=0;
			/*}#1FD93OB831CreateFunc*/
		
		}
	};
	/*#{1FD93OB831ExViewDef*/
	//************************************************************************
	//用户UI交互
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//用户头像点击，如果未登录，显示登录对话框，如已登录，显示用户信息对话框:
		cssVO.OnUserClick=function(){
			if(!cokeNT.loginDone){
				app.showDlg(dlgLogin,{});
			}else{
				//显示用户信息
				self.showUITab("Account");
			}
		};
		
		//--------------------------------------------------------------------
		//Show UI:
		cssVO.showUITab=function(name){
			if(name===curTab){
				return;
			}
			if(curTabBtn){
				curTabBtn.showFace("blur");
			}
			switch(name){
				case "Home":
					if(!uiHome){
						uiHome=uiDock.showNewUI(UIHome(app),{});
					}else{
						uiDock.showUI(uiHome,{});
					}
					curTab="Home";
					curTabUI=uiHome;
					curTabBtn=self.BtnHome;
					break;
				case "Account":
					if(!uiAccount){
						uiAccount=uiDock.showNewUI(UIAccount(app),{});
					}else{
						uiDock.showUI(uiAccount,{});
					}
					curTab="Account";
					curTabUI=uiHome;
					curTabBtn=self.BtnAccount;
					break;
				case "Docs":
					if(!uiDocs){
						uiDocs=uiDock.showNewUI(UIBook(app),{book:document.location.origin+"/docs/docs.json"});
					}else{
						uiDock.showUI(uiDocs,{});
					}
					curTab="Docs";
					curTabUI=uiDocs;
					curTabBtn=self.BtnDocs;
					break;
			}
			if(curTabUI.uiSelfScroll){
				uiDock.webObj.style.overflowY="";
			}else{
				uiDock.webObj.style.overflowY="scroll";
			}
			curTabBtn.showFace("hot");
		};
	}
	
	//************************************************************************
	//网络/系统消息处理:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Check if we have available login info:
		cssVO.checkLogin=async function(){
			try{
				await cokeNT.login();
			}catch(error){
			}
		};
		
		//--------------------------------------------------------------------
		//Login done:
		cssVO.OnNTOnline=function(){
			let userName;
			userName=cokeNT.loginVO.name;
			self.TxtUserName.text=userName;
			self.TxtUserCh.text=userName.substring(0,1).toUpperCase();
			self.BtnAccount.enable=1;
		};

		//--------------------------------------------------------------------
		//Offline:
		cssVO.OnNTOffline=function(){
			self.TxtUserName.text="Guest";
			self.TxtUserCh.text="G";
			self.showUITab("Home");
		};
}	
	/*}#1FD93OB831ExViewDef*/
	
	return cssVO;
};

/*#{1FD93OB830PostCode*/
/*}#1FD93OB830PostCode*/

export {WebHome};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "WebHome.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FD93OB830", 
//			"attrs": {
//				"viewName": "\"WebHome\"", "device": "iPad 1024x768", "w": "1024", "h": "768", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FD93OB831", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD93OB832", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FD93OB833", 
//						"attrs": {}, "funcs": {"jaxId":"1FD93OB834","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "0", "viewName": "\"uiView\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "autoLayout": "On"
//					}, 
//					"faces": null, 
//					"viewFaces": {
//						"jaxId": "1FD93OB836", 
//						"entrys": [
//							{
//								"jaxId": "1FRSSRTBQ0", 
//								"attrs": {"Face Name":"\"mobile\"","Face Function":"0"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRST2DTB0", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							}
//						]
//					}, 
//					"funcs": {"jaxId":"1FD93OB837","funcs":[]}, 
//					"subs": [
//						{
//							"type": "object", "def": "HudBox", "jaxId": "1FQU69HI60", 
//							"attrs": {
//								"locked": "0", "id": "\"BodyBG\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//								"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "#appCfg.color.pageBG", "border": "0", "borderStyle": "Solid", 
//								"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", 
//								"shadowColor": "[0,0,0,0.5]"
//							}, 
//							"funcs": {"jaxId":"1FQU69HI62","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudDock", "jaxId": "1FD99SIV51", 
//							"attrs": {
//								"locked": "1", "id": "\"UIDock\"", "x": "0", "y": "#appCfg.size.titleBoxH", "w": "\"FW\"", "h": "#\"FH-\"+(appCfg.size.titleBoxH)", "ui": "-1", 
//								"anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", 
//								"zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FD99SIV53","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudBox", "jaxId": "1FQU4FBHJ1", 
//							"attrs": {
//								"locked": "0", "id": "\"HeadBG\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "64", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//								"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "#appCfg.color.headBG", "border": "0", "borderStyle": "Solid", 
//								"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", 
//								"shadowColor": "[0,0,0,0.5]"
//							}, 
//							"funcs": {"jaxId":"1FQU4FBHJ3","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FD95JDDL0", 
//							"attrs": {
//								"locked": "1", "id": "\"BoxTitle\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "#appCfg.size.titleBoxH", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"funcs": {"jaxId":"1FD95KIG71","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudImage", "jaxId": "1FQU4FBHJ7", 
//									"attrs": {
//										"locked": "0", "id": "\"ImgLogo\"", "x": "8", "y": "7", "w": "50", "h": "50", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "assets/cklogo_dark.svg", "autoSize": "0", 
//										"fitSize": "1"
//									}, 
//									"funcs": {"jaxId":"1FQU4FBHJ9","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudImage", "jaxId": "1FQU4FBHJ10", 
//									"attrs": {
//										"locked": "0", "id": "\"ImgTitle\"", "x": "63", "y": "7", "w": "150", "h": "50", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "assets/cklogo_text.svg", "autoSize": "0", 
//										"fitSize": "1"
//									}, 
//									"faces": {
//										"jaxId": "1FRQKP81H8", 
//										"entrys": [
//											{
//												"jaxId": "1FRST2DTC2", "entryId": "1FRSSRTBQ0", "faceName": "mobile", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRST2DTC3", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FQU4FBHJ12","funcs":[]}, "subs": []
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FD987EU55", 
//							"attrs": {
//								"locked": "1", "id": "\"BoxNavi\"", "x": "230", "y": "0", "w": "\"FW-150\"", "h": "#appCfg.size.titleBoxH", "anchorH": "Left", "anchorV": "Top", 
//								"autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FRQKP81H9", 
//								"entrys": [
//									{
//										"jaxId": "1FRSTDDNU0", "entryId": "1FRSSRTBQ0", "faceName": "mobile", 
//										"attrs": {"x":"60"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSTDDNU1", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FD987EU57","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "Gear1FD988DIR0", "jaxId": "1FD995OGR0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD995OGR1", 
//										"attrs": {
//											"img": {
//												"type": "string", "valText": "\"home.svg\"", "initVal": "", "info": null, 
//												"tip": null
//											}, 
//											"text": {
//												"type": "string", "valText": "\"Home\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD995OGR2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnHome\"", "x": "0", "y": "48", "autoLayout": "Off"
//									}, 
//									"faces": null, 
//									"funcs": {
//										"jaxId": "1FD995OGR4", 
//										"funcs": [
//											{
//												"jaxId": "1FMHF4OT90", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHF4OT91", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "Gear1FD988DIR0", "jaxId": "1FQU5NL5I0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQU5NL5I1", 
//										"attrs": {
//											"img": {
//												"type": "string", "valText": "\"user.svg\"", "initVal": "", "info": null, 
//												"tip": null
//											}, 
//											"text": {
//												"type": "string", "valText": "\"Docs\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQU5NL5I2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnDocs\"", "x": "80", "y": "48", "autoLayout": "Off"
//									}, 
//									"faces": {
//										"jaxId": "1FRT1LFPC1", 
//										"entrys": [
//											{
//												"jaxId": "1FRT1LFPC2", "entryId": "1FRSSRTBQ0", "faceName": "mobile", 
//												"attrs": {"x":"64"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT1LFPC3", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {
//										"jaxId": "1FQU5NL5J0", 
//										"funcs": [
//											{
//												"jaxId": "1FQU5NL5J1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQU5NL5J2", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "Gear1FD988DIR0", "jaxId": "1FD995QSG0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD995QSG1", 
//										"attrs": {
//											"img": {
//												"type": "string", "valText": "\"user.svg\"", "initVal": "", "info": null, 
//												"tip": null
//											}, 
//											"text": {
//												"type": "string", "valText": "\"Account\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD995QSG2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnAccount\"", "x": "160", "y": "48", "autoLayout": "Off"
//									}, 
//									"faces": {
//										"jaxId": "1FRQKP81H11", 
//										"entrys": [
//											{
//												"jaxId": "1FRSTKTSC0", "entryId": "1FRSSRTBQ0", "faceName": "mobile", 
//												"attrs": {"display":"Off"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSTKTSC1", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {
//										"jaxId": "1FD995QSH0", 
//										"funcs": [
//											{
//												"jaxId": "1FMHF4OT92", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMHF4OT93", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FD95JDDL1", 
//							"attrs": {
//								"locked": "0", "id": "\"BoxUser\"", "x": "\"FW-20\"", "y": "0", "w": "70", "h": "64", "anchorH": "Right", "anchorV": "Top", "autoLayout": "On", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FRQKP81H13", 
//								"entrys": [
//									{
//										"jaxId": "1FRSUC2M90", "entryId": "1FRSSRTBQ0", "faceName": "mobile", 
//										"attrs": {"x":"\"FW-5\""}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSUC2M91", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FD95KIG75","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudBtn", "jaxId": "1FDU39AKU0", 
//									"attrs": {
//										"locked": "0", "id": "\"BtnUser\"", "x": "#\"FW-10-\"+appCfg.size.userPhoto", "y": "\"FH/2\"", "w": "#appCfg.size.userPhoto", "h": "#appCfg.size.userPhoto", 
//										"anchorH": "Left", "anchorV": "Center", "autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", 
//										"cursor": "\"pointer\"", "zIndex": "0", "drag": "NA", "enable": "On"
//									}, 
//									"funcs": {
//										"jaxId": "1FDU39AKU2", 
//										"funcs": [
//											{
//												"jaxId": "1FDU3SAGI0", "type": "object", "def": "OnClick", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDU3SD030", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}, 
//									"btnHuds": {
//										"hudBtnDown": {
//											"type": "object", "def": "HudBox", "jaxId": "1FDU39AKU3", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "-3", "y": "-3", "w": "#appCfg.size.userPhoto+6", "h": "#appCfg.size.userPhoto+6", "anchorH": "Left", "anchorV": "Top", 
//												"autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", 
//												"color": "#appCfg.color.headSub", "border": "5", "borderStyle": "Solid", "borderColor": "[0,157,255,1]", "coner": "#appCfg.size.userPhoto*0.5+3", 
//												"gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//											}, 
//											"funcs": {"jaxId":"1FDU39AKU5","funcs":[]}, "subs": []
//										}
//									}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudBox", "jaxId": "1FDU359O50", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "#appCfg.color.headSub", "border": "0", 
//												"borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "#appCfg.size.userPhoto*0.5", "gradient": "\"\"", "shadow": "0", "shadowX": "2", 
//												"shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//											}, 
//											"funcs": {"jaxId":"1FDU359O51","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FDU33O040", 
//											"attrs": {
//												"locked": "0", "id": "\"TxtUserCh\"", "x": "0", "y": "0", "w": "50", "h": "50", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"G\"", "color": "[255,255,255]", 
//												"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Center", "font": "\"\"", "fontSize": "#appCfg.txtSize.larger", 
//												"bold": "0", "italic": "0", "underline": "0"
//											}, 
//											"funcs": {"jaxId":"1FDU33O050","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FDU33UK30", 
//											"attrs": {
//												"locked": "0", "id": "\"TxtUserName\"", "x": "-10", "y": "0", "w": "100", "h": "50", "anchorH": "Right", "anchorV": "Top", "autoLayout": "Off", 
//												"display": "Show", "clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Guest\"", 
//												"color": "#appCfg.color.headSub", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Right", "alignV": "Center", 
//												"font": "\"\"", "fontSize": "#appCfg.txtSize.big", "bold": "0", "italic": "0", "underline": "0"
//											}, 
//											"faces": {
//												"jaxId": "1FRQKP81H18", 
//												"entrys": [
//													{
//														"jaxId": "1FRSTKTSC2", "entryId": "1FRSSRTBQ0", "faceName": "mobile", 
//														"attrs": {"display":"Hide"}, 
//														"anis": {
//															"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSTKTSC3", 
//															"attrs": []
//														}
//														
//													}
//												]
//											}, 
//											"funcs": {"jaxId":"1FDU33UK31","funcs":[]}, "subs": []
//										}
//									]
//									
//								}
//							]
//							
//						}
//					]
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FD93OB838", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FD93OB8310","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}