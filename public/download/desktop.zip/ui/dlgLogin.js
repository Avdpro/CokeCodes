//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
import {BtnStd} from "../gear/BtnStd.js";
import {BtnIcon} from "../gear/BtnIcon.js";
/*#{1FDU0TLOH0Imports*/
import cokeNT from "/@cokecodes/cokeNT.js"
/*}#1FDU0TLOH0Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var dlgLogin=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FDU0TLOH1ExLocal*/
	let stage;
	/*}#1FDU0TLOH1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FDU0TLOH3ExState*/
		/*}#1FDU0TLOH3ExState*/
	},);
	/*#{1FDU0TLOH1PostState*/
	/*}#1FDU0TLOH1PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FDU0TLOH1", 
		"locked": 0, "x": 271, "y": 60, "w": 360, "h": 500, 
		items: [
			{
				"type": "box", "jaxId": "1FDU1HM330", "id": "BG", "x": 0, "y": 0, "w": "FW", "h": 500, "color": appCfg.color.window, "border": 1, "coner": 1, "shadow": 1, 
				"shadowX": 0, "shadowY": 8, "shadowBlur": 8, "shadowColor": [0,0,0,0.3]
			},
			{
				"type": "hud", "jaxId": "1FDUBKBH70", "id": "BoxInput", "x": 0, "y": 0, "w": "FW", "h": "FH", 
				items: [
					{
						"type": "text", "jaxId": "1FDUBBOA50", "id": "LBEmail", "x": "(FW-300)/2", "y": 55, "w": 100, "h": 20, "text": "Email:", "color": [0,0,0], "fontSize": appCfg.txtSize.big
					},
					{
						"type": "edit", "jaxId": "1FDUBBSLS0", "id": "EdEmail", "x": "(FW-300)/2", "y": 80, "w": 300, "h": (appCfg.txtSize.large), "bgColor": [255,255,255,1], 
						"borderStyle": 0, "outline": 0, 
						//Function
						OnUpdate:function(){
							/*#{1FQC5355M0Code*/
							//Check password, maybe login:
							let pswd;
							pswd=self.EdPswd.text;
							if(pswd){
								self.DoLogin();
							}else{
								self.EdPswd.focus();
							}
							/*}#1FQC5355M0Code*/
						}
					},
					{
						"type": "text", "jaxId": "1FDUBC5DO0", "id": "LBPswd", "x": "(FW-300)/2", "y": 120, "w": 100, "h": 20, "text": "Password:", "color": [0,0,0], "fontSize": appCfg.txtSize.big
					},
					{
						"type": "edit", "jaxId": "1FDUBC9380", "id": "EdPswd", "x": "(FW-300)/2", "y": 145, "w": 300, "h": (appCfg.txtSize.large), "bgColor": [255,255,255,1], 
						"borderStyle": 0, "outline": 0, "inputType": "password", 
						//Function
						OnUpdate:function(){
							/*#{1FQC5355M1Code*/
							//TODO: Check email, maybe login:
							let email;
							email=self.EdEmail.text;
							if(email){
								self.DoLogin();
							}else{
								self.EdEmail.focus();
							}
							/*}#1FQC5355M1Code*/
						}
					},
					{
						"type": "text", "jaxId": "1FDUBCCAU0", "id": "LBPswd2", "x": "(FW-300)/2", "y": 185, "w": 100, "h": 20, "display": 0, "text": "Confirm password:", 
						"color": [0,0,0], "fontSize": appCfg.txtSize.big
					},
					{
						"type": "edit", "jaxId": "1FDUBCF0A0", "id": "EdPswd2", "x": "(FW-300)/2", "y": 210, "w": 300, "h": (appCfg.txtSize.large), "display": 0, "bgColor": [255,255,255,1], 
						"borderStyle": 0, "inputType": "password"
					},
					{
						"type": "text", "jaxId": "1FDUBDL8Q0", "id": "LBName", "x": "(FW-300)/2", "y": 250, "w": 100, "h": 20, "display": 0, "text": "User name:", "color": [0,0,0], 
						"fontSize": appCfg.txtSize.big
					},
					{
						"type": "edit", "jaxId": "1FDUBDP0S0", "id": "EdName", "x": "(FW-300)/2", "y": 275, "w": 300, "h": (appCfg.txtSize.large), "display": 0, "bgColor": [255,255,255,1], 
						"borderStyle": 0, "outline": 0
					},
					{
						"type": "text", "jaxId": "1FE06EIGR0", "id": "LBCode", "x": "(FW-300)/2", "y": 315, "w": 100, "h": 20, "display": 0, "text": "Invite code (optional):", 
						"color": [0,0,0], "fontSize": appCfg.txtSize.big
					},
					{
						"type": "edit", "jaxId": "1FE06H4600", "id": "EdCode", "x": "(FW-300)/2", "y": 340, "w": 300, "h": (appCfg.txtSize.large), "display": 0, "bgColor": [255,255,255,1], 
						"borderStyle": 0, "outline": 0
					},
					{
						"type": BtnStd(app,200,"Login",null),"jaxId": "1FDUBDVDE0", 
						"locked": 0, "x": "(FW-200)/2", "y": 200, 
						//函数
						OnClick:function(){
							/*#{1FDUBDVDF6Code*/
							self.DoLogin();
							/*}#1FDUBDVDF6Code*/
						}
					},
					{
						"type": BtnStd(app,200,"Sign up",null),"jaxId": "1FDUBE26D0", 
						"locked": 0, "x": "(FW-200)/2", "y": 250, 
						//函数
						OnClick:function(){
							/*#{1FDUBE26D9Code*/
							self.DoRegister();
							/*}#1FDUBE26D9Code*/
						}
					},
					{
						"type": "button", "jaxId": "1FE5S2D750", "id": "BtnForget", "x": 90, "y": 300, "w": 200, "h": 32, "cursor": "pointer", 
						items: [
							{
								"type": "text", "jaxId": "1FE5S2D753", "x": 0, "y": 0, "w": 200, "h": 32, "cursor": "pointer", "text": "Forget your password?", "color": [80,80,80], 
								"alignH": 1, "alignV": 1, "fontSize": appCfg.txtSize.mid, "underline": 1
							}
						]
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FDUBKBH711", "id": "BoxWorking", "x": 0, "y": 0, "w": "FW", "h": "FH", "display": 0, 
				items: [
					{
						"type": "text", "jaxId": "1FESL6MLQ0", "id": "TxtWork", "x": 0, "y": 70, "w": 380, "h": 28, "text": "Logging in...", "color": [0,0,0], "alignH": 1, 
						"fontSize": appCfg.txtSize.large
					},
					{
						"type": BtnStd(app,150,"Cancel",null),"jaxId": "1FESL6QH20", 
						"locked": 0, "id": "BtnCancelWork", "x": "(FW-150)/2", "y": 138
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FESM8RDP0", "id": "BoxError", "x": 0, "y": 0, "w": "FW", "h": 200, "display": 0, 
				items: [
					{
						"type": "text", "jaxId": "1FESM215Q0", "id": "TxtError", "x": 0, "y": 40, "w": 380, "h": 28, "text": "Logging in...", "color": [0,0,0], "alignH": 1, 
						"fontSize": appCfg.txtSize.large
					},
					{
						"type": BtnStd(app,150,"Close",null),"jaxId": "1FESM1BDD0", 
						"locked": 0, "id": "BtnErrorClose", "x": "(FW-150)/2", "y": 138, 
						//函数
						OnClick:function(){
							/*#{1FESO0JUB0Code*/
							app.closeDlg(self);
							/*}#1FESO0JUB0Code*/
						}
					},
					{
						"type": "text", "jaxId": "1FESM8RDP7", "id": "TxtErrorInfo", "x": 30, "y": 80, "w": 320, "h": 50, "text": "Error text", "color": [0,0,0], "wrap": 1, 
						"fontSize": appCfg.txtSize.mid
					}
				]
			},
			{
				"type": BtnIcon(app,32,"close.svg",null),"jaxId": "1FDU5FUMA7", 
				"locked": 0, "id": "BtnClose", "x": "FW-40", "y": 8, "display": 0, 
				//函数
				OnClick:function(){
					/*#{1FDU5MB4E0Code*/
					app.closeDlg(self);
					return 1;
					/*}#1FDU5MB4E0Code*/
				}
			}
		],
		faces: {
			"register": {
				"$":function(vo){
					/*#{1FDU1PPGR0Func*/
					stage="register";
					/*}#1FDU1PPGR0Func*/
				},
				/*BG*/"#1FDU1HM330": {
					"h": 500, 
					ani:[
						{
							type: 'auto'
						}
					]
				},
				/*BoxInput*/"#1FDUBKBH70": {
					"display": 1
				},
				/*LBPswd2*/"#1FDUBCCAU0": {
					"display": 1
				},
				/*EdPswd2*/"#1FDUBCF0A0": {
					"display": 1
				},
				/*LBName*/"#1FDUBDL8Q0": {
					"display": 1
				},
				/*EdName*/"#1FDUBDP0S0": {
					"display": 1
				},
				/*LBCode*/"#1FE06EIGR0": {
					"display": 1
				},
				/*EdCode*/"#1FE06H4600": {
					"display": 1
				},
				/**/"#1FDUBDVDE0": {
					"display": 0
				},
				/**/"#1FDUBE26D0": {
					"y": 410
				},
				/*BtnForget*/"#1FE5S2D750": {
					"display": 0
				},
				/*BoxWorking*/"#1FDUBKBH711": {
					"display": 0
				},
				/*BoxError*/"#1FESM8RDP0": {
					"display": 0
				},
				/*BtnClose*/"#1FDU5FUMA7": {
					"display": 1
				},
			},
			"login": {
				"$":function(vo){
					/*#{1FDU1Q3RT0Func*/
					stage="login";
					self.EdEmail.focus();
					/*}#1FDU1Q3RT0Func*/
				},
				/*BG*/"#1FDU1HM330": {
					"h": 360, 
					ani:[
						{
							type: 'auto'
						}
					]
				},
				/*BoxInput*/"#1FDUBKBH70": {
					"display": 1
				},
				/*LBPswd2*/"#1FDUBCCAU0": {
					"display": 0
				},
				/*EdPswd2*/"#1FDUBCF0A0": {
					"display": 0
				},
				/*LBName*/"#1FDUBDL8Q0": {
					"display": 0
				},
				/*EdName*/"#1FDUBDP0S0": {
					"display": 0
				},
				/*LBCode*/"#1FE06EIGR0": {
					"display": 0
				},
				/*EdCode*/"#1FE06H4600": {
					"display": 0
				},
				/**/"#1FDUBDVDE0": {
					"display": 1
				},
				/**/"#1FDUBE26D0": {
					"y": 250
				},
				/*BtnForget*/"#1FE5S2D750": {
					"display": 1
				},
				/*BoxWorking*/"#1FDUBKBH711": {
					"display": 0
				},
				/*BoxError*/"#1FESM8RDP0": {
					"display": 0
				},
				/*BtnClose*/"#1FDU5FUMA7": {
					"display": 1
				},
			},
			"work": {
				"$":function(vo){
					/*#{1FESKJPDM0Func*/
					self.TxtWork.text=vo.text||"Working...";
					/*}#1FESKJPDM0Func*/
				},
				/*BG*/"#1FDU1HM330": {
					"h": 200, 
					ani:[
						{
							type: 'auto'
						}
					]
				},
				/*BoxInput*/"#1FDUBKBH70": {
					"display": 0
				},
				/*BoxWorking*/"#1FDUBKBH711": {
					"display": 1
				},
				/*BoxError*/"#1FESM8RDP0": {
					"display": 0
				},
				/*BtnClose*/"#1FDU5FUMA7": {
					"display": 0
				},
			},
			"error": {
				"$":function(vo){
					/*#{1FESLULBD0Func*/
					self.TxtError.text=vo.text||"Error";
					self.TxtErrorInfo.text=vo.info||"Network error. Please varify your network connection.";
					/*}#1FESLULBD0Func*/
				},
				/*BG*/"#1FDU1HM330": {
					"h": 200
				},
				/*BoxInput*/"#1FDUBKBH70": {
					"display": 0
				},
				/*BoxWorking*/"#1FDUBKBH711": {
					"display": 0
				},
				/*BoxError*/"#1FESM8RDP0": {
					"display": 1
				},
			}
		},
		/*#{1FDU0TLOH1ExAttrs*/
		/*}#1FDU0TLOH1ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FDU0TLOH1CreateFunc*/
			/*}#1FDU0TLOH1CreateFunc*/
		
		}
	};
	/*#{1FDU0TLOH1ExViewDef*/
	
	//------------------------------------------------------------------------
	//显示对话框:
	cssVO.showDlg=function(vo){
		let x;
		self.EdEmail.text=vo.email||"";
		self.EdPswd.text="";
		self.EdPswd2.text="";
		self.x="(FW-400)<10?10:(FW-400)";
		self.BG.h=300;
		self.showFace("login");
	};
	
	cssVO.digestMessage=async function(message) {
		const msgUint8 = new TextEncoder().encode(message);                           // encode as (utf-8) Uint8Array
		const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);           // hash the message
		const hashArray = Array.from(new Uint8Array(hashBuffer));                     // convert buffer to byte array
		const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join(''); // convert bytes to hex string
		return hashHex;
	}	
	
	//------------------------------------------------------------------------
	//登录:
	cssVO.DoLogin=async function(){
		let email,pswd,checker,sha,time,result;
		email=self.EdEmail.text;
		pswd=self.EdPswd.text;
		//Check email:
		checker=/^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
		if(!checker.test(email)){
			window.alert("Email is invalide.");
			return;
		}
		self.showFace("work",{text:"Logging in..."});
		time=Date.now();
		sha=await self.digestMessage(pswd);
		//sha=await self.digestMessage(""+time+sha);
		setTimeout(async()=>{
			try{
				result=await cokeNT.login({email:email,passwordSHA:sha,time:time});
				app.closeDlg(self);
			}catch(e){
				self.showFace("error",{text:"Login error",info:e});
			}
		},200);
	};
	
	//------------------------------------------------------------------------
	//注册:
	cssVO.DoRegister=async function(){
		if(stage==="login"){
			let email,pswd;
			self.showFace("register");
			email=self.EdEmail.text;
			pswd=self.EdPswd.text;
			if(!email){
				self.EdEmail.focus();
			}else if(!pswd){
				self.EdPswd.focus();
			}else{
				self.EdPswd2.startEdit();
			}
		}else if(stage==="register"){
			let email,name,pswd,pswd2,checker,sha;
			email=self.EdEmail.text;
			pswd=self.EdPswd.text;
			pswd2=self.EdPswd2.text;
			if(pswd2!==pswd || pswd.length<6){
				window.alert("Password is not confirmed.");
				return;
			}
			
			//Check email:
			checker=/^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
			if(!checker.test(email)){
				window.alert("Email is invalide.");
				return;
			}
			
			name=self.EdName.text.trim();
			if(name.length<3 || name.length>50){
				window.alert("Name is invalide.");
				return;
			}
			
			self.showFace("work",{text:"Registering..."});
			sha=await self.digestMessage(pswd);
			try{
				await cokeNT.register({email:email,passwordSHA:sha,name:name});
				self.showFace("error",{text:"Register sucess",info:"Your userId is "+cokeNT.loginVO.email+"."});
			}catch(e){
				self.showFace("error",{text:"Register error",info:e});
			}
		}
	};
	/*}#1FDU0TLOH1ExViewDef*/
	
	return cssVO;
};

/*#{1FDU0TLOH0PostCode*/
/*}#1FDU0TLOH0PostCode*/

export {dlgLogin};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "dlgLogin.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FDU0TLOH0", 
//			"attrs": {
//				"viewName": "\"dlgLogin\"", "device": "iPad 1024x768", "w": "1024", "h": "768", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FDU0TLOH1", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDU0TLOH2", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FDU0TLOH3", 
//						"attrs": {}, "funcs": {"jaxId":"1FDU0TLOH4","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "0", "viewName": "\"uiView\"", "x": "271", "y": "60", "w": "360", "h": "500"
//					}, 
//					"faces": null, 
//					"viewFaces": {
//						"jaxId": "1FDU0TLOH6", 
//						"entrys": [
//							{
//								"jaxId": "1FDU1PPGR0", 
//								"attrs": {"Face Name":"\"register\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDU206II1", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FDU1Q3RT0", "attrs": {"Face Name":"\"login\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDU206II2", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FESKJPDM0", "attrs": {"Face Name":"\"work\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FESKTC5O0", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FESLULBD0", "attrs": {"Face Name":"\"error\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FESM8RDO0", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							}
//						]
//					}, 
//					"funcs": {"jaxId":"1FDU0TLOH7","funcs":[]}, 
//					"subs": [
//						{
//							"type": "object", "def": "HudBox", "jaxId": "1FDU1HM330", 
//							"attrs": {
//								"locked": "0", "id": "\"BG\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "500", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//								"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "#appCfg.color.window", "border": "1", "borderStyle": "Solid", 
//								"borderColor": "[0,0,0,1]", "coner": "1", "gradient": "\"\"", "shadow": "1", "shadowX": "0", "shadowY": "8", "shadowBlur": "8", "shadowSpread": "0", 
//								"shadowColor": "[0,0,0,0.3]"
//							}, 
//							"faces": {
//								"jaxId": "1FDUVD3VG1", 
//								"entrys": [
//									{
//										"jaxId": "1FE06R6BL0", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//										"attrs": {"h":"360"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE06R6BL1", 
//											"attrs": [
//												{
//													"type": "object", "def": "AniFaceAuto", "exportObj": 0, "genExportCode": 0, "jaxId": "1FE070QOL0", 
//													"attrs": {}
//												}
//											]
//										}
//										
//									},
//									{
//										"jaxId": "1FE06R6BL2", "entryId": "1FDU1PPGR0", "faceName": "register", 
//										"attrs": {"h":"500"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE06R6BL3", 
//											"attrs": [
//												{
//													"type": "object", "def": "AniFaceAuto", "exportObj": 0, "genExportCode": 0, "jaxId": "1FE071S3F0", 
//													"attrs": {}
//												}
//											]
//										}
//										
//									},
//									{
//										"jaxId": "1FESKTC5P0", "entryId": "1FESKJPDM0", "faceName": "work", 
//										"attrs": {"h":"200"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESKTC5P1", 
//											"attrs": [
//												{
//													"type": "object", "def": "AniFaceAuto", "exportObj": 0, "genExportCode": 0, "jaxId": "1FESKTC5P2", 
//													"attrs": {}
//												}
//											]
//										}
//										
//									},
//									{
//										"jaxId": "1FESM8RDO1", "entryId": "1FESLULBD0", "faceName": "error", 
//										"attrs": {"h":"200"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESM8RDO2", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FDU1HM332","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FDUBKBH70", 
//							"attrs": {
//								"locked": "1", "id": "\"BoxInput\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FDUBKBH71", 
//								"entrys": [
//									{
//										"jaxId": "1FDUBKBH72", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBKBH73", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FDUBKBH74", "entryId": "1FDU1PPGR0", "faceName": "register", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBKBH75", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESKTC5P3", "entryId": "1FESKJPDM0", "faceName": "work", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESKTC5P4", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESM8RDO3", "entryId": "1FESLULBD0", "faceName": "error", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESM8RDO4", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FDUBKBH76","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDUBBOA50", 
//									"attrs": {
//										"locked": "0", "id": "\"LBEmail\"", "x": "\"(FW-300)/2\"", "y": "55", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Email:\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.big", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDUBBOA51","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudEdit", "jaxId": "1FDUBBSLS0", 
//									"attrs": {
//										"locked": "0", "id": "\"EdEmail\"", "x": "\"(FW-300)/2\"", "y": "80", "w": "300", "h": "#(appCfg.txtSize.large)", "anchorH": "Left", "anchorV": "Top", 
//										"autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "bgColor": "[255,255,255,1]", 
//										"border": "1", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", "text": "\"\"", "font": "\"\"", "color": "[0,0,0]", "fontSize": "16", 
//										"placeHolder": "\"\"", "selectOnFocus": "1", "outline": "0", "spellCheck": "1", "inputType": "text"
//									}, 
//									"funcs": {
//										"jaxId": "1FDUBBSLS1", 
//										"funcs": [
//											{
//												"jaxId": "1FQC5355M0", "type": "object", "def": "CdyFunc", "name": "OnUpdate", "info": "Function", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQC55SIF3", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}, 
//									"subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDUBC5DO0", 
//									"attrs": {
//										"locked": "0", "id": "\"LBPswd\"", "x": "\"(FW-300)/2\"", "y": "120", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Password:\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.big", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FDUBC5DO1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudEdit", "jaxId": "1FDUBC9380", 
//									"attrs": {
//										"locked": "0", "id": "\"EdPswd\"", "x": "\"(FW-300)/2\"", "y": "145", "w": "300", "h": "#(appCfg.txtSize.large)", "anchorH": "Left", "anchorV": "Top", 
//										"autoLayout": "Off", "display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "bgColor": "[255,255,255,1]", 
//										"border": "1", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", "text": "\"\"", "font": "\"\"", "color": "[0,0,0]", "fontSize": "16", 
//										"placeHolder": "\"\"", "selectOnFocus": "1", "outline": "0", "spellCheck": "1", "inputType": "password"
//									}, 
//									"funcs": {
//										"jaxId": "1FDUBC9381", 
//										"funcs": [
//											{
//												"jaxId": "1FQC5355M1", "type": "object", "def": "CdyFunc", "name": "OnUpdate", "info": "Function", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQC55SIF6", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}, 
//									"subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDUBCCAU0", 
//									"attrs": {
//										"locked": "0", "id": "\"LBPswd2\"", "x": "\"(FW-300)/2\"", "y": "185", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Confirm password:\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.big", "bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"faces": {
//										"jaxId": "1FDUBCCAU1", 
//										"entrys": [
//											{
//												"jaxId": "1FDUBCCAU2", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBCCAU3", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDUBCCAU4", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBCCAU5", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FDUBCCAU6","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudEdit", "jaxId": "1FDUBCF0A0", 
//									"attrs": {
//										"locked": "0", "id": "\"EdPswd2\"", "x": "\"(FW-300)/2\"", "y": "210", "w": "300", "h": "#(appCfg.txtSize.large)", "anchorH": "Left", "anchorV": "Top", 
//										"autoLayout": "Off", "display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "bgColor": "[255,255,255,1]", 
//										"border": "1", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", "text": "\"\"", "font": "\"\"", "color": "[0,0,0]", "fontSize": "16", 
//										"placeHolder": "\"\"", "selectOnFocus": "1", "outline": "1", "spellCheck": "1", "inputType": "password"
//									}, 
//									"faces": {
//										"jaxId": "1FDUBCF0B0", 
//										"entrys": [
//											{
//												"jaxId": "1FDUBCF0B1", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBCF0B2", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDUBCF0B3", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBCF0B4", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FDUBCF0B5","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FDUBDL8Q0", 
//									"attrs": {
//										"locked": "0", "id": "\"LBName\"", "x": "\"(FW-300)/2\"", "y": "250", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"User name:\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.big", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"faces": {
//										"jaxId": "1FDUBDL8Q1", 
//										"entrys": [
//											{
//												"jaxId": "1FDUBDL8Q2", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBDL8Q3", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDUBDL8Q4", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBDL8Q5", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FDUBDL8Q6","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudEdit", "jaxId": "1FDUBDP0S0", 
//									"attrs": {
//										"locked": "0", "id": "\"EdName\"", "x": "\"(FW-300)/2\"", "y": "275", "w": "300", "h": "#(appCfg.txtSize.large)", "anchorH": "Left", "anchorV": "Top", 
//										"autoLayout": "Off", "display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "bgColor": "[255,255,255,1]", 
//										"border": "1", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", "text": "\"\"", "font": "\"\"", "color": "[0,0,0]", "fontSize": "16", 
//										"placeHolder": "\"\"", "selectOnFocus": "1", "outline": "0", "spellCheck": "1", "inputType": "text"
//									}, 
//									"faces": {
//										"jaxId": "1FDUBDP0T0", 
//										"entrys": [
//											{
//												"jaxId": "1FDUBDP0T1", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBDP0T2", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDUBDP0T3", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBDP0T4", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FDUBDP0T5","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FE06EIGR0", 
//									"attrs": {
//										"locked": "0", "id": "\"LBCode\"", "x": "\"(FW-300)/2\"", "y": "315", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Invite code (optional):\"", 
//										"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "#appCfg.txtSize.big", "bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"faces": {
//										"jaxId": "1FE06EIGS0", 
//										"entrys": [
//											{
//												"jaxId": "1FE06EIGS1", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE06EIGS2", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FE06EIGS3", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE06EIGS4", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FE06EIGS5","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "HudEdit", "jaxId": "1FE06H4600", 
//									"attrs": {
//										"locked": "0", "id": "\"EdCode\"", "x": "\"(FW-300)/2\"", "y": "340", "w": "300", "h": "#(appCfg.txtSize.large)", "anchorH": "Left", "anchorV": "Top", 
//										"autoLayout": "Off", "display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "bgColor": "[255,255,255,1]", 
//										"border": "1", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", "text": "\"\"", "font": "\"\"", "color": "[0,0,0]", "fontSize": "16", 
//										"placeHolder": "\"\"", "selectOnFocus": "1", "outline": "0", "spellCheck": "1", "inputType": "text"
//									}, 
//									"faces": {
//										"jaxId": "1FE06H4601", 
//										"entrys": [
//											{
//												"jaxId": "1FE06H4602", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE06H4603", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FE06H4604", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE06H4605", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FE06H4606","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FDAETMLJ0", "jaxId": "1FDUBDVDE0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDUBDVDE1", 
//										"attrs": {
//											"w": {"type":"int","valText":"200","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"Login\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDUBDVDE2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"\"", "x": "\"(FW-200)/2\"", "y": "200", "autoLayout": "Off"
//									}, 
//									"faces": {
//										"jaxId": "1FDUBDVDF0", 
//										"entrys": [
//											{
//												"jaxId": "1FDUBDVDF1", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"On"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBDVDF2", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDUBDVDF3", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Off"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBDVDF4", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {
//										"jaxId": "1FDUBDVDF5", 
//										"funcs": [
//											{
//												"jaxId": "1FDUBDVDF6", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDUBDVDF7", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "Gear1FDAETMLJ0", "jaxId": "1FDUBE26D0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDUBE26D1", 
//										"attrs": {
//											"w": {"type":"int","valText":"200","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"Sign up\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDUBE26D2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"\"", "x": "\"(FW-200)/2\"", "y": "250", "autoLayout": "Off"
//									}, 
//									"faces": {
//										"jaxId": "1FDUBE26D3", 
//										"entrys": [
//											{
//												"jaxId": "1FDUBE26D4", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"y":"410"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBE26D5", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FDUBE26D6", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"y":"250"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FDUBE26D7", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {
//										"jaxId": "1FDUBE26D8", 
//										"funcs": [
//											{
//												"jaxId": "1FDUBE26D9", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDUBE26D10", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "HudBtn", "jaxId": "1FE5S2D750", 
//									"attrs": {
//										"locked": "0", "id": "\"BtnForget\"", "x": "90", "y": "300", "w": "200", "h": "32", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "drag": "NA", "enable": "On"
//									}, 
//									"faces": {
//										"jaxId": "1FE5S2D751", 
//										"entrys": [
//											{
//												"jaxId": "1FE5S4PFL0", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE5S4PFL1", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FE5S4PFL2", "entryId": "1FDU1PPGR0", "faceName": "register", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FE5S4PFL3", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FE5S2D752","funcs":[]}, "btnHuds": {}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FE5S2D753", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "200", "h": "32", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"pointer\"", "zIndex": "0", "text": "\"Forget your password?\"", "color": "[80,80,80]", 
//												"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Center", "font": "\"\"", "fontSize": "#appCfg.txtSize.mid", 
//												"bold": "0", "italic": "0", "underline": "1"
//											}, 
//											"funcs": {"jaxId":"1FE5S2D755","funcs":[]}, "subs": []
//										}
//									]
//									
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FDUBKBH711", 
//							"attrs": {
//								"locked": "0", "id": "\"BoxWorking\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FESHO4OM6", 
//								"entrys": [
//									{
//										"jaxId": "1FESKTC5P5", "entryId": "1FESKJPDM0", "faceName": "work", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESKTC5P6", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESL7GU30", "entryId": "1FDU1PPGR0", "faceName": "register", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESL7GU31", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESL7GU32", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESL7GU33", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESM8RDO5", "entryId": "1FESLULBD0", "faceName": "error", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESM8RDO6", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FDUBKBH713","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FESL6MLQ0", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtWork\"", "x": "0", "y": "70", "w": "380", "h": "28", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Logging in...\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.large", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FESL6MLQ1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FDAETMLJ0", "jaxId": "1FESL6QH20", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FESL6QH21", 
//										"attrs": {
//											"w": {"type":"int","valText":"150","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"Cancel\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FESL6QH22", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnCancelWork\"", "x": "\"(FW-150)/2\"", "y": "138", "autoLayout": "Off"
//									}, 
//									"faces": null, "funcs": {"jaxId":"1FESL6QH30","funcs":[]}
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FESM8RDP0", 
//							"attrs": {
//								"locked": "0", "id": "\"BoxError\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "200", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Hide", 
//								"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FESM8RDP1", 
//								"entrys": [
//									{
//										"jaxId": "1FESM8RDP2", "entryId": "1FESLULBD0", "faceName": "error", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESM8RDP3", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESMBTU20", "entryId": "1FDU1PPGR0", "faceName": "register", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESMBTU21", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESMBTU22", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESMBTU23", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESMBTU24", "entryId": "1FESKJPDM0", "faceName": "work", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESMBTU25", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FESM8RDP4","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FESM215Q0", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtError\"", "x": "0", "y": "40", "w": "380", "h": "28", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Logging in...\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Center", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.large", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FESM215Q1","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FDAETMLJ0", "jaxId": "1FESM1BDD0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FESM1BDD1", 
//										"attrs": {
//											"w": {"type":"int","valText":"150","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"Close\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FESM1BDD2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnErrorClose\"", "x": "\"(FW-150)/2\"", "y": "138", "autoLayout": "Off"
//									}, 
//									"faces": null, 
//									"funcs": {
//										"jaxId": "1FESM1BDE0", 
//										"funcs": [
//											{
//												"jaxId": "1FESO0JUB0", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FESO0TTF0", 
//													"attrs": {}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}
//									
//								},
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FESM8RDP7", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtErrorInfo\"", "x": "30", "y": "80", "w": "320", "h": "50", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Error text\"", "color": "[0,0,0]", 
//										"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "1", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.mid", 
//										"bold": "0", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FESM8RDP9","funcs":[]}, "subs": []
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "Gear1FBOMHCB70", "jaxId": "1FDU5FUMA7", 
//							"args": {
//								"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDU5FUMA8", 
//								"attrs": {
//									"w": {"type":"int","valText":"32","initVal":0,"info":null,"tip":null}, 
//									"image": {
//										"type": "string", "valText": "\"close.svg\"", "initVal": "", "info": null, 
//										"tip": null
//									}
//								}
//							}, 
//							"stateObj": {
//								"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDU5FUMA9", 
//								"attrs": {}
//							}, 
//							"attrs": {
//								"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnClose\"", "x": "\"FW-40\"", "y": "8", "autoLayout": "Off", "display": "Off"
//							}, 
//							"faces": {
//								"jaxId": "1FESHO4OM7", 
//								"entrys": [
//									{
//										"jaxId": "1FESKTC5P7", "entryId": "1FESKJPDM0", "faceName": "work", 
//										"attrs": {"display":"Off"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESKTC5P8", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESKTC5P9", "entryId": "1FDU1PPGR0", "faceName": "register", 
//										"attrs": {"display":"On"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESKTC5P10", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FESKTC5P11", "entryId": "1FDU1Q3RT0", "faceName": "login", 
//										"attrs": {"display":"On"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FESKTC5P12", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {
//								"jaxId": "1FDU5FUMA11", 
//								"funcs": [
//									{
//										"jaxId": "1FDU5MB4E0", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//										"args": {
//											"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDU5MQFH0", 
//											"attrs": {}
//										}, 
//										"attrs": {"Mockup Result":"\"\""}
//									}
//								]
//							}
//							
//						}
//					]
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FDU0TLOH8", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FDU0TLOH10","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}