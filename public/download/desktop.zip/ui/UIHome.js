//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {jaxHudState} from "/jaxweb/lib/JAXHudState.js"
import {BlkHeader} from "../gear/BlkHeader.js";
import {BtnApp} from "../gear/BtnApp.js";
import {BtnStd} from "../gear/BtnStd.js";
/*#{1FDGT2OCJ0Imports*/
import {JAXDisk} from "/jaxweb/lib/JAXDisk.js";
import pathLib from "/jaxweb/lib/JAXPath.js";
import {setupPrj} from "../lib/setupPrj.js";
import {LabelNew} from "../gear/LabelNew.js";
import cokeNT from "/@cokecodes/cokeNT.js";
/*}#1FDGT2OCJ0Imports*/

/*App界面*/
//----------------------------------------------------------------------------
/*App里的UI View*/
var UIHome=function (app){
	let jaxEnv,appCfg,txtLib,appData,state;
	let cssVO,self;
	/*#{1FDGT2OCJ1ExLocal*/
	let curPrjBtns=[];
	/*}#1FDGT2OCJ1ExLocal*/
	
	jaxEnv=app.jaxEnv;
	appCfg=app.appCfg;
	txtLib=app.txtLib;
	appData=app.appData;
	
	state=jaxHudState(jaxEnv,{
		/*#{1FDGT2OCJ3ExState*/
		/*}#1FDGT2OCJ3ExState*/
	},);
	/*#{1FDGT2OCJ1PostState*/
	/*}#1FDGT2OCJ1PostState*/
	
	cssVO={
		"type": "view", "hudState": state, "jaxId": "1FDGT2OCJ1", 
		"locked": 1, "x": "(FW-(FW>1200?1200:FW))/2", "y": 0, "w": "FW>1200?1200:FW", "h": "FH", "autoLayout": 1, 
		items: [
			{
				"type": "image", "jaxId": "1FQU89OGF0", "x": "FW-300", "y": -80, "w": 600, "h": 600, "autoLayout": 1, "alpha": 0.2, "image": "assets/cklogo.svg", 
				"autoSize": 0, "fitSize": 1, "filter": ""
			},
			{
				"type": "hud", "jaxId": "1FRT5SVD80", "id": "MobileHead", "x": 20, "y": 20, "w": "FW-40", "h": 120, "display": 0, "filter": "", 
				items: [
					{
						"type": "text", "jaxId": "1FRT6U69D2", "id": "TxtMobileHead", "x": 0, "y": 0, "w": "FW", "h": "FH", "text": "Easier, Faster and Open Source Full-Stack Dev. in Browsers", 
						"color": [0,100,150], "wrap": 1, "fontSize": 28, "bold": 1
					}
				]
			},
			{
				"type": "text", "jaxId": "1FQU6RE930", "id": "Head1", "x": 20, "y": 20, "w": 1026, "h": 50, "text": "Easier, Faster, Open Source ", "color": [0,100,150], 
				"fontSize": appCfg.txtSize.shuge, "bold": 1
			},
			{
				"type": "text", "jaxId": "1FQU6RFB10", "id": "Head2", "x": 20, "y": 85, "w": 1026, "h": 50, "text": "PWA Full-Stack Dev Environment in Browser", "color": [80,120,150], 
				"fontSize": appCfg.txtSize.huge, "bold": 1
			},
			{
				"type": "hud", "jaxId": "1FDH258PG0", "id": "BlkTools", "x": 20, "y": 160, "w": "FW-40", "h": 180, "autoLayout": 1, "caption": "Dev. Tools", "filter": "", 
				items: [
					{
						"type": "box", "jaxId": "1FQU7LN950", "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, "color": [255,255,255,1], "gradient": appCfg.color.gntBlock, 
						"shadow": 1, "shadowBlur": 10, "shadowColor": [0,0,0,0.5]
					},
					{
						"type": BlkHeader(app,2,"Dev. Tools",null),"jaxId": "1FRT13G2H0", 
						"locked": 0, "id": "BlkBar1", "x": 0, "y": 0, "autoLayout": 1
					},
					{
						"type": "hud", "jaxId": "1FRT0BALK0", "id": "BlkDevDock", "x": 0, "y": 0, "w": "FW", "h": "FH", "filter": "", 
						items: [
							{
								"type": BtnApp(app,80,"disk.svg","Diskit",null),"jaxId": "1FDHD3MEU0", 
								"locked": 0, "id": "BtnDiskit", "x": 135, "y": 55, "bar": 1, "tip": "Diskit: the file manager of this sandbox", 
								//函数
								OnClick:function(){
									/*#{1FDM93T7N0Code*/
									app.DoOpenDiskApp("diskit");
									/*}#1FDM93T7N0Code*/
								}
							},
							{
								"type": BtnApp(app,80,"edit.svg","CCEdit",null),"jaxId": "1FDHD4BKU0", 
								"locked": 0, "id": "BtnCCEdit", "x": 240, "y": 55, "bar": 1, "tip": "CCEdit: the code editor powered by CodeMirror", 
								//函数
								OnClick:function(){
									/*#{1FDM93T7N1Code*/
									app.DoOpenDiskApp("ccedit");
									/*}#1FDM93T7N1Code*/
								}
							},
							{
								"type": BtnApp(app,80,"terminal.svg","Terminal",null),"jaxId": "1FLPLOROF0", 
								"locked": 0, "id": "BtnTerminal", "x": 30, "y": 55, "bar": 1, "tip": "Terminal: Command line tool", 
								//函数
								OnClick:function(){
									/*#{1FLPLOROG1Code*/
									app.DoOpenDiskApp("terminal");
									/*}#1FLPLOROG1Code*/
								}
							},
							{
								"type": BtnApp(app,80,"diff.svg","CCDiff",null),"jaxId": "1FRL71BSD0", 
								"locked": 0, "id": "BtnDiff", "x": 345, "y": 55, "bar": 1, "tip": "CCDiff: The content compare tool.", 
								//函数
								OnClick:function(){
									/*#{1FRL71BSD4Code*/
									/*}#1FRL71BSD4Code*/
								}
							},
							{
								"type": BtnApp(app,80,"cpp.svg","Clang",null),"jaxId": "1FRLAO6AV0", 
								"locked": 0, "id": "BtnClang", "x": 450, "y": 55, "bar": 1, "tip": "Clang: The C++ compiler", 
								//函数
								OnClick:function(){
									/*#{1FRLAO6AV4Code*/
									/*}#1FRLAO6AV4Code*/
								}
							},
							{
								"type": BtnApp(app,80,"py.svg","Pyodide",null),"jaxId": "1FRLBF07P0", 
								"locked": 0, "id": "BtnPyodide", "x": 555, "y": 55, "bar": 1, "tip": "Pyodide is a port of CPython to WebAssembly", 
								//函数
								OnClick:function(){
									/*#{1FRLBF07P4Code*/
									/*}#1FRLBF07P4Code*/
								}
							},
							{
								"type": BtnApp(app,80,"db.svg","DataBase",null),"jaxId": "1FRLGQ79N0", 
								"locked": 0, "id": "BtnDataBase", "x": 660, "y": 55, "bar": 1, "tip": "Host & Manage SQL/Object DataBase", 
								//函数
								OnClick:function(){
									/*#{1FRLGQ79N4Code*/
									/*}#1FRLGQ79N4Code*/
								}
							}
						]
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FMB11PEQ0", "id": "BlkWzd", "x": 20, "y": 360, "w": "FW-40", "h": 180, "autoLayout": 1, "filter": "", 
				items: [
					{
						"type": "box", "jaxId": "1FQU8Q2S00", "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, "color": [255,255,255,1], "gradient": appCfg.color.gntBlock, 
						"shadow": 1, "shadowBlur": 10, "shadowColor": [0,0,0,0.5]
					},
					{
						"type": BlkHeader(app,1,"New Project",null),"jaxId": "1FQULAHV60", 
						"locked": 0, "id": "BlkBar2", "x": 0, "y": 0, "autoLayout": 1
					},
					{
						"type": "hud", "jaxId": "1FMBBOHE00", "id": "BoxPrjType", "x": 0, "y": 0, "w": "FW", "h": "FH", "filter": "", 
						items: [
							{
								"type": "text", "jaxId": "1FQV25OJO0", "x": 20, "y": 40, "w": 100, "h": 20, "text": "Font-End:", "color": [80,120,150], "fontSize": 16, "bold": 1
							},
							{
								"type": BtnApp(app,80,"browser.svg","HTML",null),"jaxId": "1FMBB93960", 
								"locked": 0, "id": "BtnPrjHtml", "x": 30, "y": 65, "prjType": "html", "bar": 2, "tip": "Front-end: Simple HTML project.", 
								//函数
								OnClick:function(){
									/*#{1FMBB93964Code*/
									self.newPrj(this.prjType);
									/*}#1FMBB93964Code*/
								}
							},
							{
								"type": BtnApp(app,80,"react.svg","React",null),"jaxId": "1FMBB993O0", 
								"locked": 0, "id": "BtnPrjReact", "x": 135, "y": 65, "prjType": "react", "bar": 2, "tip": "Front-end: New web project by react framework", 
								//函数
								OnClick:function(){
									/*#{1FMBB993P0Code*/
									self.newPrj(this.prjType);
									/*}#1FMBB993P0Code*/
								}
							},
							{
								"type": BtnApp(app,80,"react.svg","React HMR",null),"jaxId": "1FRLKG72O0", 
								"locked": 0, "id": "BtnPrjReactHMR", "x": 240, "y": 65, "prjType": "reactHmr", "bar": 2, "tip": "Front-end: New web project by react framework", 
								//函数
								OnClick:function(){
									/*#{1FRLKG72P1Code*/
									self.newLoginPrj(this.prjType);
									/*}#1FRLKG72P1Code*/
								}
							},
							{
								"type": BtnApp(app,80,"","VUE",null),"jaxId": "1FMBB8ECB0", 
								"locked": 0, "id": "BtnPrjVue", "x": 345, "y": 65, "prjType": "vue", "bar": 2, "tip": "Front-end: New web project by VUE framework", 
								//函数
								OnClick:function(){
									/*#{1FMBB8ECB4Code*/
									self.newPrj(this.prjType);
									/*}#1FMBB8ECB4Code*/
								}
							},
							{
								"type": "box", "jaxId": "1FQV28VUS0", "x": 445, "y": 35, "w": 1, "h": 135, "shadowColor": [0,0,0,0.5]
							},
							{
								"type": "text", "jaxId": "1FQV25J7K0", "x": 455, "y": 40, "w": 100, "h": 20, "text": "Back-End:", "color": [80,120,150], "fontSize": 16, "bold": 1
							},
							{
								"type": BtnApp(app,80,"","Fastify",null),"jaxId": "1FQV1IQ8F0", 
								"locked": 0, "id": "BtnPrjFast", "x": 465, "y": 65, "prjType": "fastify", "bar": 2, "tip": "Back-End: Fastify server project.", 
								//函数
								OnClick:function(){
									/*#{1FQV1IQ8G1Code*/
									self.newLoginPrj(this.prjType);
									/*}#1FQV1IQ8G1Code*/
								}
							},
							{
								"type": BtnApp(app,80,"","Express",null),"jaxId": "1FQV1JV3P0", 
								"locked": 0, "id": "BtnPrjExpress", "x": 570, "y": 65, "prjType": "vue", "bar": 2, "tip": "Back-end: Express server project", 
								//函数
								OnClick:function(){
									/*#{1FQV1JV3P4Code*/
									/*}#1FQV1JV3P4Code*/
								}
							},
							{
								"type": BtnApp(app,80,"nodejs.svg","Node.js",null),"jaxId": "1FRLKVCC50", 
								"locked": 0, "id": "BtnPrjNodeJS", "x": 675, "y": 65, "prjType": "vue", "bar": 2, "tip": "Back-end: Node.js blank project.", 
								//函数
								OnClick:function(){
									/*#{1FRLKVCC54Code*/
									/*}#1FRLKVCC54Code*/
								}
							},
							{
								"type": "box", "jaxId": "1FQV290V80", "x": 775, "y": 35, "w": 1, "h": 135, "shadowColor": [0,0,0,0.5]
							},
							{
								"type": "text", "jaxId": "1FQV29VUP0", "x": 785, "y": 40, "w": 100, "h": 20, "text": "System:", "color": [80,120,150], "fontSize": 16, "bold": 1
							},
							{
								"type": BtnApp(app,80,"terminal.svg","Terminal",null),"jaxId": "1FMBB8QM00", 
								"locked": 0, "id": "BtnPrjCmd", "x": 795, "y": 65, "prjType": "cmd", "bar": 2, "tip": "System: New command run in terminal", 
								//函数
								OnClick:function(){
									/*#{1FMBB8QM04Code*/
									self.newPrj(this.prjType);
									/*}#1FMBB8QM04Code*/
								}
							},
							{
								"type": BtnApp(app,80,"appdata.svg","Lib package",null),"jaxId": "1FMF988AP0", 
								"locked": 0, "id": "BtnPrjLib", "x": 900, "y": 65, "prjType": "lib", "bar": 2, "tip": "System: New utility library / package", 
								//函数
								OnClick:function(){
									/*#{1FMF988AQ1Code*/
									self.newPrj(this.prjType);
									/*}#1FMF988AQ1Code*/
								}
							}
						]
					},
					{
						"type": "hud", "jaxId": "1FMBBOHE07", "id": "BoxPrjName", "x": 0, "y": 0, "w": "FW", "h": "FH", "display": 0, "filter": "", 
						items: [
							{
								"type": "text", "jaxId": "1FMBBJ93S0", "x": 40, "y": 73, "w": 100, "h": 20, "text": "Input new project disk name:", "color": [0,0,0], "fontSize": appCfg.txtSize.midder
							},
							{
								"type": "edit", "jaxId": "1FMBBJ09R0", "id": "EdPrjName", "x": 40, "y": 104, "w": 200, "h": 40, "bgColor": [255,255,255,1], "borderStyle": 0, 
								"placeHolder": "Project disk name", 
								//Function
								OnUpdate:function(){
									/*#{1FQC4VU2U17Code*/
									self.createPrj();
									/*}#1FQC4VU2U17Code*/
								}
							},
							{
								"type": BtnStd(app,100,"Create",null),"jaxId": "1FMBBOHE012", 
								"locked": 0, "x": 250, "y": 108, 
								//函数
								OnClick:function(){
									/*#{1FMBCL0RA0Code*/
									self.createPrj();
									/*}#1FMBCL0RA0Code*/
								}
							},
							{
								"type": BtnStd(app,100,"Cancel",null),"jaxId": "1FMBCIIM70", 
								"locked": 0, "x": 360, "y": 108, 
								//函数
								OnClick:function(){
									/*#{1FMBCL0RA1Code*/
									self.showFace("PrjType");
									/*}#1FMBCL0RA1Code*/
								}
							}
						]
					},
					{
						"type": "hud", "jaxId": "1FMBGN7SP0", "id": "BoxPrjSetup", "x": 0, "y": 0, "w": "FW", "h": "FH", "display": 0, "filter": "", 
						items: [
							{
								"type": "text", "jaxId": "1FMBH6I3D0", "x": 41, "y": 70, "w": 100, "h": 20, "text": "Seting up your project disk...", "color": [0,0,0], "fontSize": appCfg.txtSize.midder
							},
							{
								"type": "text", "jaxId": "1FMBH6L320", "id": "TxtSetupLog", "x": 91, "y": 110, "w": 100, "h": 20, "text": "Working...", "color": [80,80,80], "fontSize": appCfg.txtSize.mid
							}
						]
					}
				]
			},
			{
				"type": "text", "jaxId": "1FRT3VUAI0", "id": "TxtMobileNotice", "x": 20, "y": 560, "w": "FW-40", "h": 100, "display": 0, "text": "Notice: Current concept preview has only limited support for mobile devices or tablets. Try on desktop to discover more features. ", 
				"color": [180,0,0], "wrap": 1, "fontSize": appCfg.txtSize.mid, "bold": 1
			},
			{
				"type": "hud", "jaxId": "1FDH48B7M0", "id": "BlkPrj", "x": 20, "y": 560, "w": "FW-40", "h": 180, "autoLayout": 1, "filter": "", 
				items: [
					{
						"type": "box", "jaxId": "1FQU8S9IB0", "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, "color": [255,255,255,1], "gradient": appCfg.color.gntBlock, 
						"shadow": 1, "shadowBlur": 10, "shadowColor": [0,0,0,0.5]
					},
					{
						"type": BlkHeader(app,4,"Projects",null),"jaxId": "1FQULC5MS0", 
						"locked": 0, "id": "BlkBar3", "x": 0, "y": 0, "autoLayout": 1
					},
					{
						"type": "hud", "jaxId": "1FRBCMHMF0", "id": "BoxPrjsDock", "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, "clip": 1, "filter": "", 
						items: [
							{
								"type": "hud", "jaxId": "1FRBCM2160", "id": "BoxPrjs", "x": 0, "y": 0, "w": "FW", "h": "FH", "autoLayout": 1, "filter": ""
							}
						]
					},
					{
						"type": "button", "jaxId": "1FRLVH0QJ0", "id": "BtnNoPrj", "x": 35, "y": 57, "w": 687, "h": 40, 
						items: [
							{
								"type": "text", "jaxId": "1FRLVDQL70", "id": "TxtNoPrj", "x": 0, "y": 0, "w": 200, "h": 20, "uiEvent": -1, "text": "No local projects. Let's create a new one!", 
								"color": [80,80,80], "fontSize": appCfg.txtSize.bigger, "bold": 1
							}
						],
						//Function
						OnMouseInOut:function(isIn){
							/*#{1FRLVR39G0Code*/
							if(isIn){
								self.showFace("HintPrj");
							}else{
								self.showFace("OffHintPrj");
							}
							/*}#1FRLVR39G0Code*/
						}
					}
				]
			},
			{
				"type": "hud", "jaxId": "1FRT49GJD0", "id": "MobileFooter", "x": 20, "y": 800, "w": 100, "h": 100, "display": 0, "filter": ""
			}
		],
		faces: {
			"PrjName": {
				"$":function(vo){
					/*#{1FMBBU4PT0Func*/
					window.setTimeout(()=>{
						self.EdPrjName.focus();
					},20);
					/*}#1FMBBU4PT0Func*/
				},
				/*BoxPrjType*/"#1FMBBOHE00": {
					"display": 0
				},
				/*BoxPrjName*/"#1FMBBOHE07": {
					"display": 1
				},
				/*BoxPrjSetup*/"#1FMBGN7SP0": {
					"display": 0
				},
			},
			"PrjType": {
				/*BoxPrjType*/"#1FMBBOHE00": {
					"display": 1
				},
				/*BoxPrjName*/"#1FMBBOHE07": {
					"display": 0
				},
				/*BoxPrjSetup*/"#1FMBGN7SP0": {
					"display": 0
				},
			},
			"PrjSetup": {
				/*BoxPrjType*/"#1FMBBOHE00": {
					"display": 0
				},
				/*BoxPrjName*/"#1FMBBOHE07": {
					"display": 0
				},
				/*BoxPrjSetup*/"#1FMBGN7SP0": {
					"display": 1
				},
			},
			"HintPrj": {
				/*Head1*/"#1FQU6RE930": {
					"alpha": 0.2
				},
				/*Head2*/"#1FQU6RFB10": {
					"alpha": 0.2
				},
				/*BlkTools*/"#1FDH258PG0": {
					"alpha": 0.2
				},
				/*BlkPrj*/"#1FDH48B7M0": {
					"alpha": 0.2
				},
			},
			"OffHintPrj": {
				/*Head1*/"#1FQU6RE930": {
					"alpha": 1
				},
				/*Head2*/"#1FQU6RFB10": {
					"alpha": 1
				},
				/*BlkTools*/"#1FDH258PG0": {
					"alpha": 1
				},
				/*BlkPrj*/"#1FDH48B7M0": {
					"alpha": 1
				},
			},
			"mobile": {
				"$":function(vo){
					/*#{1FRSUGMQQ0Func*/
					self.BlkBar1.setText("Dev. Tools: 7 Apps");
					self.BlkBar2.setText("Create Prj: 9 Templates");
					self.BlkDevDock.webObj.style.overflowX="scroll";
					self.BlkDevDock.webObj.style.overflowY="";
					self.BoxPrjType.webObj.style.overflowX="scroll";
					self.BoxPrjType.webObj.style.overflowY="";
					/*}#1FRSUGMQQ0Func*/
				},
				/**/"#1FQU89OGF0": {
					"display": 0
				},
				/*MobileHead*/"#1FRT5SVD80": {
					"display": 1
				},
				/*Head1*/"#1FQU6RE930": {
					"display": 0
				},
				/*Head2*/"#1FQU6RFB10": {
					"display": 0
				},
				/**/"#1FMBBJ93S0": {
					"x": 10, "y": 40
				},
				/*EdPrjName*/"#1FMBBJ09R0": {
					"x": 15, "y": 70, "w": "FW-30"
				},
				/**/"#1FMBBOHE012": {
					"x": "FW/2-105", "y": 120
				},
				/**/"#1FMBCIIM70": {
					"x": "FW/2+5", "y": 120
				},
				/*TxtMobileNotice*/"#1FRT3VUAI0": {
					"display": 1
				},
				/*TxtNoPrj*/"#1FRLVDQL70": {
					"text": "No Local Projects."
				},
				/*MobileFooter*/"#1FRT49GJD0": {
					"display": 1
				},
			}
		},
		/*#{1FDGT2OCJ1ExAttrs*/
		/*}#1FDGT2OCJ1ExAttrs*/
		OnCreate: function(){
			self=this;
			/*#{1FDGT2OCJ1CreateFunc*/
			if(self.w<550){
				self.showFace("mobile");
				/*while(self.TxtMobileHead.textH>self.MobileHead.h){
					self.TxtMobileHead.fontSize-=2;
					self.TxtMobileHead._update();
				}*/
				let asp=self.TxtMobileHead.textH-self.MobileHead.h;
				self.BlkTools.y+=asp;
				self.BlkWzd.y+=asp;
				self.TxtMobileNotice.y+=asp;
				self.BlkPrj.y+=asp+self.TxtMobileNotice.textH+20;
			}
			self.blockBars=[self.BlkBar1,self.BlkBar2,self.BlkBar3];
			//self.webObj.style.overflowX="scroll";
			//self.webObj.style.overflowY="scroll";
			self.showFace("PrjType");
			self.showPrjs();
			self.BtnNoPrj.display=0;
			self.setupTTY={
				textOut(text){
					self.TxtSetupLog.text=text;
				},
				clearLine(){
					self.TxtSetupLog.text="";
				}
			};
			self.BtnDiff.enable=0;
			self.BtnDiff.showBar("SOON",[190,190,190,1],[100,100,100]);
			self.BtnClang.enable=0;
			self.BtnClang.showBar("SOON",[190,190,190,1],[100,100,100]);
			self.BtnPyodide.enable=0;
			self.BtnPyodide.showBar("SOON",[190,190,190,1],[100,100,100]);
			self.BtnDataBase.enable=0;
			self.BtnDataBase.showBar("SOON",[190,190,190,1],[100,100,100]);
			self.BtnPrjExpress.enable=0;
			self.BtnPrjExpress.showBar("SOON",[190,190,190,1],[100,100,100]);
			self.BtnPrjNodeJS.enable=0;
			self.BtnPrjNodeJS.showBar("SOON",[190,190,190,1],[100,100,100]);
			app.uiHome=self;

			self.BtnPrjReactHMR.showBar("BETA",[29,156,205,1],[255,255,255]);
			self.BtnPrjFast.showBar("BETA",[29,156,205,1],[255,255,255]);
			/*}#1FDGT2OCJ1CreateFunc*/
		
		}
	};
	/*#{1FDGT2OCJ1ExViewDef*/
	//------------------------------------------------------------------------
	//Show local disks:
	cssVO.showPrjs=async function(){
		let disks,i,n,diskName,diskType;
		let pos,cnt,btn,icon;
		n=curPrjBtns.length;
		for(i=0;i<n;i++){
			self.BoxPrjs.removeChild(curPrjBtns[i]);
		}
		curPrjBtns.splice(0,n);
		self.BoxPrjs.x=0;
		pos=30;
		cnt=0;
		disks=await JAXDisk.getDiskNames();
		disks.sort((a,b)=>a>b?1:(b>a?-1:0));
		n=disks.length;
		for(i=0;i<n;i++){
			diskName=disks[i];
			if(diskName.startsWith("-")){
				//TODO: This is an installed package disk:
				continue;
			}
			diskType=await JAXDisk.getDiskAttr(diskName,"diskType");
			if(diskType==="Package" || diskType==="System"){
				continue;
			}
			icon=`/${diskName}/favicon.svg`;
			icon=(await JAXDisk.isExist(icon))?(icon):"";
			btn=this.BoxPrjs.appendNewChild({
				type:BtnApp(app,80,icon,""+diskName),x:pos,y:55,
				diskName:diskName,
				OnClick:function(){
					window.open(document.location.origin+"/@ccedit?disk="+encodeURIComponent(this.diskName),"CCEdit_"+this.diskName);
				}
			});
			curPrjBtns.push(btn);
			pos+=105;
			cnt+=1;
		}
		if(!cnt){
			self.BtnNoPrj.display=1;
		}else{
			self.BtnNoPrj.display=0;
		}
		self.BoxPrjs.newOffset=30;
	};
	
	//------------------------------------------------------------------------
	//New project:
	cssVO.newPrj=function(prjType){
		self.newPrjType=prjType;
		self.showFace("PrjName");
	};
	
	//------------------------------------------------------------------------
	//New project with login:
	cssVO.newLoginPrj=async function(prjType){
		if(await cokeNT.checkLogin()){
			self.newPrjType=prjType;
			self.showFace("PrjName");
		}else{
			window.alert("You need login cokcodes to create this beta project.");
		}
	};

	//------------------------------------------------------------------------
	//Add a new project.
	cssVO.newPrjIcon=function(prjName,vo){
		let i,n,btn,x,box;
		//First, move all current icons right a grid:
		box=self.BoxPrjs;
		x=box.x+105;
		box.newOffset-=105;
		self.BoxPrjs.animate({type:"pose",x:x});
		//Add new button at left side:
		btn=box.appendNewChild({
			type:BtnApp(app,80,"",""+prjName),x:box.newOffset,y:55,alpha:0,
			diskName:prjName,
			OnClick:function(){
				window.open(vo.startURL||(document.location.origin+"/@ccedit?disk="+encodeURIComponent(this.diskName),"CCEdit_"+this.diskName));
			}
		});
		curPrjBtns.push(btn);
		btn.showBar("New",[0,120,40,1],[255,255,255]);
		//btn.newLabel=btn.appendNewChild({type:LabelNew(app,60),x:40,y:-10});
		btn.tgtX=box.newOffset;
		setTimeout(()=>{
			btn.animate({type:"pose",x:btn.tgtX,alpha:1.0});
		},50);
	};
	
	//------------------------------------------------------------------------
	//Create project disk:
	cssVO.createPrj=async function(){
		let diskName,vo;
		let checker=/^[ A-Za-z0-9_-]{3,30}$/;
		diskName=self.EdPrjName.text;
		if(!checker.test(diskName)){
			window.alert("Wrong name: name should be 3~30 chars, starts only allow 'A'~'Z', 'a'~'z', '0'~'9', '-', '_' or space.");
			return;
		}
		if(await JAXDisk.openDisk(diskName)){
			window.alert(`Disk ${diskName} is already exist. Can't create a new with this name.`);
			return;
		}
		try{
			self.showFace("PrjSetup");
			vo=await setupPrj(this.newPrjType,diskName,self.setupTTY);
		}catch(err){
			window.alert(`Create project disk error: ${err}`);
			self.showFace("PrjType");
			return;
		}
		//self.showPrjs();
		self.showFace("PrjType");
		self.newPrjIcon(diskName,vo);
		self.BtnNoPrj.display=0;
	};
	
	/*}#1FDGT2OCJ1ExViewDef*/
	
	return cssVO;
};

/*#{1FDGT2OCJ0PostCode*/
/*}#1FDGT2OCJ0PostCode*/

export {UIHome};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "UIHome.js", "type": "object", "def": "CdyFileUIView", "jaxId": "1FDGT2OCJ0", 
//			"attrs": {
//				"viewName": "\"UIHome\"", "device": "iPad 1024x768", "w": "1024", "h": "768", 
//				"view": {
//					"type": "object", "def": "HudView", "jaxId": "1FDGT2OCJ1", 
//					"args": {
//						"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDGT2OCJ2", 
//						"attrs": {}
//					}, 
//					"stateObj": {
//						"name": "state", "type": "object", "def": "CdyDocObjHudState", "jaxId": "1FDGT2OCJ3", 
//						"attrs": {}, "funcs": {"jaxId":"1FDGT2OCJ4","funcs":[]}
//					}, 
//					"attrs": {
//						"locked": "1", "viewName": "\"uiView\"", "x": "\"(FW-(FW>1200?1200:FW))/2\"", "y": "0", "w": "\"FW>1200?1200:FW\"", "h": "\"FH\"", "autoLayout": "On"
//					}, 
//					"faces": null, 
//					"viewFaces": {
//						"jaxId": "1FDGT2OCJ6", 
//						"entrys": [
//							{
//								"jaxId": "1FMBBU4PT0", 
//								"attrs": {"Face Name":"\"PrjName\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBC0FRN0", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FMBBVDAT0", 
//								"attrs": {"Face Name":"\"PrjType\"","Face Function":"0"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBC0FRN1", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FMBH55VV0", 
//								"attrs": {"Face Name":"\"PrjSetup\"","Face Function":"0"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBH7R3D0", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FRLVMRCJ0", 
//								"attrs": {"Face Name":"\"HintPrj\"","Face Function":"0"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLVP9FD0", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FRLVN70J0", 
//								"attrs": {"Face Name":"\"OffHintPrj\"","Face Function":"0"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLVP9FD1", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							},
//							{
//								"jaxId": "1FRSUGMQQ0", 
//								"attrs": {"Face Name":"\"mobile\"","Face Function":"1"}, 
//								"state": {
//									"name": "state", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRSV36S90", 
//									"attrs": {}
//								}, 
//								"faceTimes": []
//							}
//						]
//					}, 
//					"funcs": {"jaxId":"1FDGT2OCJ7","funcs":[]}, 
//					"subs": [
//						{
//							"type": "object", "def": "HudImage", "jaxId": "1FQU89OGF0", 
//							"attrs": {
//								"locked": "0", "id": "\"\"", "x": "\"FW-300\"", "y": "-80", "w": "600", "h": "600", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//								"clip": "Off", "uiEvent": "On", "alpha": "0.2", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "image": "assets/cklogo.svg", "autoSize": "0", 
//								"fitSize": "1", "filter": "\"\""
//							}, 
//							"faces": {
//								"jaxId": "1FRR1PF591", 
//								"entrys": [
//									{
//										"jaxId": "1FRSV36S91", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSV36S92", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FQU89OGF2","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FRT5SVD80", 
//							"attrs": {
//								"locked": "0", "id": "\"MobileHead\"", "x": "20", "y": "20", "w": "\"FW-40\"", "h": "120", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//							}, 
//							"faces": {
//								"jaxId": "1FRT606B80", 
//								"entrys": [
//									{
//										"jaxId": "1FRT6U69D0", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT6U69D1", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FRT606B81","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudTxt", "jaxId": "1FRT6U69D2", 
//									"attrs": {
//										"locked": "0", "id": "\"TxtMobileHead\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Easier, Faster and Open Source Full-Stack Dev. in Browsers\"", 
//										"color": "[0,100,150]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "1", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//										"fontSize": "28", "bold": "1", "italic": "0", "underline": "0"
//									}, 
//									"funcs": {"jaxId":"1FRT6U69D4","funcs":[]}, "subs": []
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudTxt", "jaxId": "1FQU6RE930", 
//							"attrs": {
//								"locked": "0", "id": "\"Head1\"", "x": "20", "y": "20", "w": "1026", "h": "50", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//								"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Easier, Faster, Open Source \"", "color": "[0,100,150]", 
//								"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.shuge", 
//								"bold": "1", "italic": "0", "underline": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FRL65JJ23", 
//								"entrys": [
//									{
//										"jaxId": "1FRM02C7H0", "entryId": "1FRLVMRCJ0", "faceName": "HintPrj", 
//										"attrs": {"alpha":"0.2"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRM02C7H1", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRM02C7H2", "entryId": "1FRLVN70J0", "faceName": "OffHintPrj", 
//										"attrs": {"alpha":"1"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRM02C7H3", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRSVGJ770", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSVGJ771", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FQU6RE941","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudTxt", "jaxId": "1FQU6RFB10", 
//							"attrs": {
//								"locked": "0", "id": "\"Head2\"", "x": "20", "y": "85", "w": "1026", "h": "50", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//								"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"PWA Full-Stack Dev Environment in Browser\"", 
//								"color": "[80,120,150]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//								"fontSize": "#appCfg.txtSize.huge", "bold": "1", "italic": "0", "underline": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FRL65JJ24", 
//								"entrys": [
//									{
//										"jaxId": "1FRM02C7H4", "entryId": "1FRLVMRCJ0", "faceName": "HintPrj", 
//										"attrs": {"alpha":"0.2"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRM02C7H5", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRM02C7H6", "entryId": "1FRLVN70J0", "faceName": "OffHintPrj", 
//										"attrs": {"alpha":"1"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRM02C7H7", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRSVGJ772", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//										"attrs": {"display":"Hide"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSVGJ773", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FQU6RFB11","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FDH258PG0", 
//							"attrs": {
//								"locked": "0", "id": "\"BlkTools\"", "x": "20", "y": "160", "w": "\"FW-40\"", "h": "180", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", 
//								"caption": {"type":"auto","valText":"\"Dev. Tools\"","info":null,"tip":null}, "filter": "\"\""
//							}, 
//							"faces": {
//								"jaxId": "1FRL65JJ37", 
//								"entrys": [
//									{
//										"jaxId": "1FRLVP9FD2", "entryId": "1FRLVMRCJ0", "faceName": "HintPrj", 
//										"attrs": {"alpha":"0.2"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRLVP9FD3", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRLVP9FD4", "entryId": "1FRLVN70J0", "faceName": "OffHintPrj", 
//										"attrs": {"alpha":"1"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRLVP9FD5", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FDH258PG2","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudBox", "jaxId": "1FQU7LN950", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[255,255,255,1]", "border": "0", "borderStyle": "Solid", 
//										"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "#appCfg.color.gntBlock", "shadow": "1", "shadowX": "2", "shadowY": "2", "shadowBlur": "10", 
//										"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//									}, 
//									"funcs": {"jaxId":"1FQU7LN961","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FQUKUAUG0", "jaxId": "1FRT13G2H0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRT13G2H1", 
//										"attrs": {
//											"color": {"type":"int","valText":"2","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"Dev. Tools\"", "initVal": "", 
//												"info": null, "tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRT13G2H2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BlkBar1\"", "x": "0", "y": "0", "autoLayout": "On"
//									}, 
//									"faces": null, "funcs": {"jaxId":"1FRT13G2H3","funcs":[]}
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FRT0BALK0", 
//									"attrs": {
//										"locked": "0", "id": "\"BlkDevDock\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//									}, 
//									"funcs": {"jaxId":"1FRT0BALK2","funcs":[]}, 
//									"subs": [
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FDHD3MEU0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDHD3MEU1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"disk.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Diskit\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDHD3MEU2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnDiskit\"", "x": "135", "y": "55", "autoLayout": "Off", 
//												"bar": {"type":"auto","valText":"1","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Diskit: the file manager of this sandbox\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FDHD3MEU3", 
//												"funcs": [
//													{
//														"jaxId": "1FDM93T7N0", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDM95RSM0", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FDHD4BKU0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDHD4BKU1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"edit.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"CCEdit\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDHD4BKU2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnCCEdit\"", "x": "240", "y": "55", "autoLayout": "Off", 
//												"bar": {"type":"auto","valText":"1","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"CCEdit: the code editor powered by CodeMirror\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FDHD4BKU3", 
//												"funcs": [
//													{
//														"jaxId": "1FDM93T7N1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDM95RSM1", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FLPLOROF0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FLPLOROF1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"terminal.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Terminal\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FLPLOROF2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnTerminal\"", "x": "30", "y": "55", "autoLayout": "Off", 
//												"bar": {"type":"auto","valText":"1","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Terminal: Command line tool\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FLPLOROG0", 
//												"funcs": [
//													{
//														"jaxId": "1FLPLOROG1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FLPLOROG2", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FRL71BSD0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRL71BSD1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"diff.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"CCDiff\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRL71BSD2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnDiff\"", "x": "345", "y": "55", "autoLayout": "Off", 
//												"bar": {"type":"auto","valText":"1","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"CCDiff: The content compare tool.\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FRL71BSD3", 
//												"funcs": [
//													{
//														"jaxId": "1FRL71BSD4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRL71BSD5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FRLAO6AV0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLAO6AV1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"cpp.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Clang\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLAO6AV2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnClang\"", "x": "450", "y": "55", "autoLayout": "Off", 
//												"bar": {"type":"auto","valText":"1","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Clang: The C++ compiler\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FRLAO6AV3", 
//												"funcs": [
//													{
//														"jaxId": "1FRLAO6AV4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLAO6AV5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FRLBF07P0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLBF07P1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"py.svg\"", "initVal": "", "info": null, 
//														"tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Pyodide\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLBF07P2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPyodide\"", "x": "555", "y": "55", "autoLayout": "Off", 
//												"bar": {"type":"auto","valText":"1","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Pyodide is a port of CPython to WebAssembly\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FRLBF07P3", 
//												"funcs": [
//													{
//														"jaxId": "1FRLBF07P4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLBF07P5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FRLGQ79N0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLGQ79N1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"db.svg\"", "initVal": "", "info": null, 
//														"tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"DataBase\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLGQ79N2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnDataBase\"", "x": "660", "y": "55", "autoLayout": "Off", 
//												"bar": {"type":"auto","valText":"1","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Host & Manage SQL/Object DataBase\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FRLGQ79N3", 
//												"funcs": [
//													{
//														"jaxId": "1FRLGQ79N4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLGQ79N5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										}
//									]
//									
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FMB11PEQ0", 
//							"attrs": {
//								"locked": "0", "id": "\"BlkWzd\"", "x": "20", "y": "360", "w": "\"FW-40\"", "h": "180", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//							}, 
//							"funcs": {"jaxId":"1FMB11PEQ1","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudBox", "jaxId": "1FQU8Q2S00", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[255,255,255,1]", "border": "0", "borderStyle": "Solid", 
//										"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "#appCfg.color.gntBlock", "shadow": "1", "shadowX": "2", "shadowY": "2", "shadowBlur": "10", 
//										"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//									}, 
//									"funcs": {"jaxId":"1FQU8Q2S01","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FQUKUAUG0", "jaxId": "1FQULAHV60", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQULAHV61", 
//										"attrs": {
//											"color": {"type":"int","valText":"1","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"New Project\"", "initVal": "", 
//												"info": null, "tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQULAHV70", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BlkBar2\"", "x": "0", "y": "0", "autoLayout": "On"
//									}, 
//									"faces": null, "funcs": {"jaxId":"1FQULAHV72","funcs":[]}
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FMBBOHE00", 
//									"attrs": {
//										"locked": "0", "id": "\"BoxPrjType\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//									}, 
//									"faces": {
//										"jaxId": "1FMBBOHE01", 
//										"entrys": [
//											{
//												"jaxId": "1FMBC0FRO0", "entryId": "1FMBBU4PT0", "faceName": "PrjName", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBC0FRO1", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FMBC0FRO2", "entryId": "1FMBBVDAT0", "faceName": "PrjType", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBC0FRO3", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FMBH7R3D1", "entryId": "1FMBH55VV0", "faceName": "PrjSetup", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBH7R3D2", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FMBBOHE02","funcs":[]}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FQV25OJO0", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "20", "y": "40", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Font-End:\"", "color": "[80,120,150]", 
//												"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "16", 
//												"bold": "1", "italic": "0", "underline": "0"
//											}, 
//											"funcs": {"jaxId":"1FQV25OJO1","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FMBB93960", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB93961", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"browser.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"HTML\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB93962", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjHtml\"", "x": "30", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"html\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Front-end: Simple HTML project.\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FMBB93963", 
//												"funcs": [
//													{
//														"jaxId": "1FMBB93964", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB93965", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FMBB993O0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB993O1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"react.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"React\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB993O2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjReact\"", "x": "135", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"react\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Front-end: New web project by react framework\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FMBB993O3", 
//												"funcs": [
//													{
//														"jaxId": "1FMBB993P0", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB993P1", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FRLKG72O0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLKG72O1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"react.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"React HMR\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLKG72O2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjReactHMR\"", "x": "240", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"reactHmr\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Front-end: New web project by react framework\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FRLKG72P0", 
//												"funcs": [
//													{
//														"jaxId": "1FRLKG72P1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLKG72P2", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FMBB8ECB0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB8ECB1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//														"tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"VUE\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB8ECB2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjVue\"", "x": "345", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"vue\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Front-end: New web project by VUE framework\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FMBB8ECB3", 
//												"funcs": [
//													{
//														"jaxId": "1FMBB8ECB4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB8ECB5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "HudBox", "jaxId": "1FQV28VUS0", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "445", "y": "35", "w": "1", "h": "135", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[180,180,180,1]", "border": "0", "borderStyle": "Solid", 
//												"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", 
//												"shadowColor": "[0,0,0,0.5]"
//											}, 
//											"funcs": {"jaxId":"1FQV28VUS2","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FQV25J7K0", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "455", "y": "40", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Back-End:\"", "color": "[80,120,150]", 
//												"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "16", 
//												"bold": "1", "italic": "0", "underline": "0"
//											}, 
//											"funcs": {"jaxId":"1FQV25J7K2","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FQV1IQ8F0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQV1IQ8F1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//														"tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Fastify\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQV1IQ8F2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjFast\"", "x": "465", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"fastify\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Back-End: Fastify server project.\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FQV1IQ8G0", 
//												"funcs": [
//													{
//														"jaxId": "1FQV1IQ8G1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQV1IQ8G2", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FQV1JV3P0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQV1JV3P1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//														"tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Express\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQV1JV3P2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjExpress\"", "x": "570", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"vue\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Back-end: Express server project\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FQV1JV3P3", 
//												"funcs": [
//													{
//														"jaxId": "1FQV1JV3P4", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQV1JV3P5", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FRLKVCC50", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLKVCC51", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"nodejs.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Node.js\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLKVCC52", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjNodeJS\"", "x": "675", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"vue\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"Back-end: Node.js blank project.\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FRLKVCC53", 
//												"funcs": [
//													{
//														"jaxId": "1FRLKVCC54", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLKVCC55", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "HudBox", "jaxId": "1FQV290V80", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "775", "y": "35", "w": "1", "h": "135", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[180,180,180,1]", "border": "0", "borderStyle": "Solid", 
//												"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "\"\"", "shadow": "0", "shadowX": "2", "shadowY": "2", "shadowBlur": "3", "shadowSpread": "0", 
//												"shadowColor": "[0,0,0,0.5]"
//											}, 
//											"funcs": {"jaxId":"1FQV290V81","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FQV29VUP0", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "785", "y": "40", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"System:\"", "color": "[80,120,150]", 
//												"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "16", 
//												"bold": "1", "italic": "0", "underline": "0"
//											}, 
//											"funcs": {"jaxId":"1FQV29VUP1","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FMBB8QM00", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB8QM01", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"terminal.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Terminal\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB8QM02", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjCmd\"", "x": "795", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"cmd\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"System: New command run in terminal\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FMBB8QM03", 
//												"funcs": [
//													{
//														"jaxId": "1FMBB8QM04", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBB8QM05", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDH24MFV1", "jaxId": "1FMF988AP0", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMF988AP1", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "80", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"img": {
//														"type": "string", "valText": "\"appdata.svg\"", "initVal": "", 
//														"info": null, "tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Lib package\"", "initVal": "", 
//														"info": null, "tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMF988AP2", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BtnPrjLib\"", "x": "900", "y": "65", "autoLayout": "Off", 
//												"prjType": {"type":"auto","valText":"\"lib\"","info":null,"tip":null}, 
//												"bar": {"type":"auto","valText":"2","info":null,"tip":null}, 
//												"tip": {
//													"type": "auto", "valText": "\"System: New utility library / package\"", "initVal": undefined, 
//													"info": null, "tip": null
//												}
//											}, 
//											"faces": null, 
//											"funcs": {
//												"jaxId": "1FMF988AQ0", 
//												"funcs": [
//													{
//														"jaxId": "1FMF988AQ1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMF988AQ2", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										}
//									]
//									
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FMBBOHE07", 
//									"attrs": {
//										"locked": "0", "id": "\"BoxPrjName\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//									}, 
//									"faces": {
//										"jaxId": "1FMBBOHE08", 
//										"entrys": [
//											{
//												"jaxId": "1FMBC0FRO4", "entryId": "1FMBBU4PT0", "faceName": "PrjName", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBC0FRO5", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FMBC0FRO6", "entryId": "1FMBBVDAT0", "faceName": "PrjType", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBC0FRO7", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FMBH7R3D3", "entryId": "1FMBH55VV0", "faceName": "PrjSetup", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBH7R3D4", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FMBBOHE09","funcs":[]}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FMBBJ93S0", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "40", "y": "73", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Input new project disk name:\"", "color": "[0,0,0]", 
//												"autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", "fontSize": "#appCfg.txtSize.midder", 
//												"bold": "0", "italic": "0", "underline": "0"
//											}, 
//											"faces": {
//												"jaxId": "1FRT0MP2Q17", 
//												"entrys": [
//													{
//														"jaxId": "1FRT3A8B00", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//														"attrs": {"x":"10","y":"40"}, 
//														"anis": {
//															"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT3A8B01", 
//															"attrs": []
//														}
//														
//													}
//												]
//											}, 
//											"funcs": {"jaxId":"1FMBBJ93S1","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudEdit", "jaxId": "1FMBBJ09R0", 
//											"attrs": {
//												"locked": "0", "id": "\"EdPrjName\"", "x": "40", "y": "104", "w": "200", "h": "40", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//												"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "bgColor": "[255,255,255,1]", 
//												"border": "1", "borderStyle": "Solid", "borderColor": "[0,0,0,1]", "coner": "0", "text": "\"\"", "font": "\"\"", "color": "[0,0,0]", "fontSize": "16", 
//												"placeHolder": "\"Project disk name\"", "inputType": "text", "selectOnFocus": "1", "outline": "1", "spellCheck": "1"
//											}, 
//											"faces": {
//												"jaxId": "1FRT0MP2Q18", 
//												"entrys": [
//													{
//														"jaxId": "1FRT3A8B02", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//														"attrs": {"x":"15","y":"70","w":"\"FW-30\""}, 
//														"anis": {
//															"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT3A8B03", 
//															"attrs": []
//														}
//														
//													}
//												]
//											}, 
//											"funcs": {
//												"jaxId": "1FMBBJ09R1", 
//												"funcs": [
//													{
//														"jaxId": "1FQC4VU2U17", "type": "object", "def": "CdyFunc", "name": "OnUpdate", "info": "Function", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQC4VU2U18", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}, 
//											"subs": []
//										},
//										{
//											"type": "object", "def": "Gear1FDAETMLJ0", "jaxId": "1FMBBOHE012", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBBOHE013", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "100", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Create\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBBOHE014", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"\"", "x": "250", "y": "108", "autoLayout": "Off"
//											}, 
//											"faces": {
//												"jaxId": "1FRT0MP2Q19", 
//												"entrys": [
//													{
//														"jaxId": "1FRT3A8B04", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//														"attrs": {"x":"\"FW/2-105\"","y":"120"}, 
//														"anis": {
//															"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT3A8B05", 
//															"attrs": []
//														}
//														
//													}
//												]
//											}, 
//											"funcs": {
//												"jaxId": "1FMBBOHE016", 
//												"funcs": [
//													{
//														"jaxId": "1FMBCL0RA0", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBCLGK00", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										},
//										{
//											"type": "object", "def": "Gear1FDAETMLJ0", "jaxId": "1FMBCIIM70", 
//											"args": {
//												"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBCIIM71", 
//												"attrs": {
//													"w": {
//														"type": "int", "valText": "100", "initVal": 0, "info": null, 
//														"tip": null
//													}, 
//													"text": {
//														"type": "string", "valText": "\"Cancel\"", "initVal": "", "info": null, 
//														"tip": null
//													}
//												}
//											}, 
//											"stateObj": {
//												"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBCIIM72", 
//												"attrs": {}
//											}, 
//											"attrs": {
//												"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"\"", "x": "360", "y": "108", "autoLayout": "Off"
//											}, 
//											"faces": {
//												"jaxId": "1FRT0MP2Q20", 
//												"entrys": [
//													{
//														"jaxId": "1FRT3A8B06", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//														"attrs": {"x":"\"FW/2+5\"","y":"120"}, 
//														"anis": {
//															"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT3A8B07", 
//															"attrs": []
//														}
//														
//													}
//												]
//											}, 
//											"funcs": {
//												"jaxId": "1FMBCIIM80", 
//												"funcs": [
//													{
//														"jaxId": "1FMBCL0RA1", "type": "object", "def": "CdyFunc", "name": "OnClick", "info": "函数", "tip": "", 
//														"args": {
//															"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FMBCLGK01", 
//															"attrs": {}
//														}, 
//														"attrs": {"Mockup Result":"\"\""}
//													}
//												]
//											}
//											
//										}
//									]
//									
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FMBGN7SP0", 
//									"attrs": {
//										"locked": "0", "id": "\"BoxPrjSetup\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//										"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//									}, 
//									"faces": {
//										"jaxId": "1FMBGN7SP1", 
//										"entrys": [
//											{
//												"jaxId": "1FMBH7R3D5", "entryId": "1FMBH55VV0", "faceName": "PrjSetup", 
//												"attrs": {"display":"Show"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBH7R3D6", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FMBH7R3D7", "entryId": "1FMBBU4PT0", "faceName": "PrjName", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBH7R3D8", 
//													"attrs": []
//												}
//												
//											},
//											{
//												"jaxId": "1FMBH7R3D9", "entryId": "1FMBBVDAT0", "faceName": "PrjType", 
//												"attrs": {"display":"Hide"}, 
//												"anis": {
//													"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FMBH7R3D10", 
//													"attrs": []
//												}
//												
//											}
//										]
//									}, 
//									"funcs": {"jaxId":"1FMBGN7SP2","funcs":[]}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FMBH6I3D0", 
//											"attrs": {
//												"locked": "0", "id": "\"\"", "x": "41", "y": "70", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Seting up your project disk...\"", 
//												"color": "[0,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//												"fontSize": "#appCfg.txtSize.midder", "bold": "0", "italic": "0", "underline": "0"
//											}, 
//											"funcs": {"jaxId":"1FMBH6I3E0","funcs":[]}, "subs": []
//										},
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FMBH6L320", 
//											"attrs": {
//												"locked": "0", "id": "\"TxtSetupLog\"", "x": "91", "y": "110", "w": "100", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//												"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Working...\"", 
//												"color": "[80,80,80]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", 
//												"font": "\"\"", "fontSize": "#appCfg.txtSize.mid", "bold": "0", "italic": "0", "underline": "0"
//											}, 
//											"funcs": {"jaxId":"1FMBH6L330","funcs":[]}, "subs": []
//										}
//									]
//									
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudTxt", "jaxId": "1FRT3VUAI0", 
//							"attrs": {
//								"locked": "0", "id": "\"TxtMobileNotice\"", "x": "20", "y": "560", "w": "\"FW-40\"", "h": "100", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"Notice: Current concept preview has only limited support for mobile devices or tablets. Try on desktop to discover more features. \"", 
//								"color": "[180,0,0]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "1", "ellipsis": "0", "alignH": "Left", "alignV": "Top", "font": "\"\"", 
//								"fontSize": "#appCfg.txtSize.mid", "bold": "1", "italic": "0", "underline": "0"
//							}, 
//							"faces": {
//								"jaxId": "1FRT3VUAI1", 
//								"entrys": [
//									{
//										"jaxId": "1FRT413OL0", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT413OL1", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FRT3VUAI2","funcs":[]}, "subs": []
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FDH48B7M0", 
//							"attrs": {
//								"locked": "0", "id": "\"BlkPrj\"", "x": "20", "y": "560", "w": "\"FW-40\"", "h": "180", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//								"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//							}, 
//							"faces": {
//								"jaxId": "1FRL65JJ334", 
//								"entrys": [
//									{
//										"jaxId": "1FRLVP9FE0", "entryId": "1FRLVMRCJ0", "faceName": "HintPrj", 
//										"attrs": {"alpha":"0.2"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRLVP9FE1", 
//											"attrs": []
//										}
//										
//									},
//									{
//										"jaxId": "1FRLVP9FE2", "entryId": "1FRLVN70J0", "faceName": "OffHintPrj", 
//										"attrs": {"alpha":"1"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRLVP9FE3", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FDH48B7M1","funcs":[]}, 
//							"subs": [
//								{
//									"type": "object", "def": "HudBox", "jaxId": "1FQU8S9IB0", 
//									"attrs": {
//										"locked": "0", "id": "\"\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "color": "[255,255,255,1]", "border": "0", "borderStyle": "Solid", 
//										"borderColor": "[0,0,0,1]", "coner": "0", "gradient": "#appCfg.color.gntBlock", "shadow": "1", "shadowX": "2", "shadowY": "2", "shadowBlur": "10", 
//										"shadowSpread": "0", "shadowColor": "[0,0,0,0.5]"
//									}, 
//									"funcs": {"jaxId":"1FQU8S9IC0","funcs":[]}, "subs": []
//								},
//								{
//									"type": "object", "def": "Gear1FQUKUAUG0", "jaxId": "1FQULC5MS0", 
//									"args": {
//										"name": "gearArgs", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQULC5MS1", 
//										"attrs": {
//											"color": {"type":"int","valText":"4","initVal":0,"info":null,"tip":null}, 
//											"text": {
//												"type": "string", "valText": "\"Projects\"", "initVal": "", "info": null, 
//												"tip": null
//											}
//										}
//									}, 
//									"stateObj": {
//										"name": "gearState", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FQULC5MS2", 
//										"attrs": {}
//									}, 
//									"attrs": {
//										"locked": {"type":"auto","valText":"0","info":"","tip":""}, "id": "\"BlkBar3\"", "x": "0", "y": "0", "autoLayout": "On"
//									}, 
//									"faces": null, "funcs": {"jaxId":"1FQULC5MS3","funcs":[]}
//								},
//								{
//									"type": "object", "def": "HudObj", "jaxId": "1FRBCMHMF0", 
//									"attrs": {
//										"locked": "0", "id": "\"BoxPrjsDock\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//										"display": "Show", "clip": "On", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//									}, 
//									"funcs": {"jaxId":"1FRBCMHMF2","funcs":[]}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudObj", "jaxId": "1FRBCM2160", 
//											"attrs": {
//												"locked": "0", "id": "\"BoxPrjs\"", "x": "0", "y": "0", "w": "\"FW\"", "h": "\"FH\"", "anchorH": "Left", "anchorV": "Top", "autoLayout": "On", 
//												"display": "Show", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//											}, 
//											"funcs": {"jaxId":"1FRBCM2161","funcs":[]}, "subs": []
//										}
//									]
//									
//								},
//								{
//									"type": "object", "def": "HudBtn", "jaxId": "1FRLVH0QJ0", 
//									"attrs": {
//										"locked": "0", "id": "\"BtnNoPrj\"", "x": "35", "y": "57", "w": "687", "h": "40", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//										"clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "drag": "NA", "enable": "On"
//									}, 
//									"funcs": {
//										"jaxId": "1FRLVHE5R1", 
//										"funcs": [
//											{
//												"jaxId": "1FRLVR39G0", "type": "object", "def": "CdyFunc", "name": "OnMouseInOut", "info": "Function", "tip": "", 
//												"args": {
//													"name": "args", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FRLVR39G1", 
//													"attrs": {
//														"isIn": {
//															"type": "int", "valText": "1", "initVal": "", "info": null, 
//															"tip": null
//														}
//													}
//												}, 
//												"attrs": {"Mockup Result":"\"\""}
//											}
//										]
//									}, 
//									"btnHuds": {}, 
//									"subs": [
//										{
//											"type": "object", "def": "HudTxt", "jaxId": "1FRLVDQL70", 
//											"attrs": {
//												"locked": "0", "id": "\"TxtNoPrj\"", "x": "0", "y": "0", "w": "200", "h": "20", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", "display": "Show", 
//												"clip": "Off", "uiEvent": "TreeOff", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "text": "\"No local projects. Let's create a new one!\"", 
//												"color": "[80,80,80]", "autoSizeW": "0", "autoSizeH": "0", "select": "0", "wrap": "0", "ellipsis": "0", "alignH": "Left", "alignV": "Top", 
//												"font": "\"\"", "fontSize": "#appCfg.txtSize.bigger", "bold": "1", "italic": "0", "underline": "0"
//											}, 
//											"faces": {
//												"jaxId": "1FRR1PF5B1", 
//												"entrys": [
//													{
//														"jaxId": "1FRSV36S93", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//														"attrs": {"text":"\"No Local Projects.\""}, 
//														"anis": {
//															"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRSV36S94", 
//															"attrs": []
//														}
//														
//													}
//												]
//											}, 
//											"funcs": {"jaxId":"1FRLVDQL71","funcs":[]}, "subs": []
//										}
//									]
//									
//								}
//							]
//							
//						},
//						{
//							"type": "object", "def": "HudObj", "jaxId": "1FRT49GJD0", 
//							"attrs": {
//								"locked": "0", "id": "\"MobileFooter\"", "x": "20", "y": "800", "w": "100", "h": "100", "anchorH": "Left", "anchorV": "Top", "autoLayout": "Off", 
//								"display": "Hide", "clip": "Off", "uiEvent": "On", "alpha": "1", "rotate": "0", "cursor": "\"\"", "zIndex": "0", "filter": "\"\""
//							}, 
//							"faces": {
//								"jaxId": "1FRT49GJD1", 
//								"entrys": [
//									{
//										"jaxId": "1FRT49GJD2", "entryId": "1FRSUGMQQ0", "faceName": "mobile", 
//										"attrs": {"display":"Show"}, 
//										"anis": {
//											"name": "Animation", "type": "object", "def": "ani", "jaxId": "1FRT49GJD3", 
//											"attrs": []
//										}
//										
//									}
//								]
//							}, 
//							"funcs": {"jaxId":"1FRT49GJD4","funcs":[]}, "subs": []
//						}
//					]
//				}, 
//				"notes": {
//					"type": "object", "def": "HudNote", "jaxId": "1FDGT2OCJ8", 
//					"attrs": {"locked":"0"}, "faces": null, 
//					"viewFaces": {"jaxId":"1FDGT2OCJ10","entrys":[]}, "subs": []
//				}
//			}
//		}/*Doc}#*/;
//	}