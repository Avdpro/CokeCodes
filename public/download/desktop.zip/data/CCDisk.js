//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {JAXDataObj} from "/jaxweb/lib/JAXDataObj.js"
/*#{1FD9CKN510Imports*/
import {JAXDisk} from "/jaxweb/lib/JAXDisk.js"
/*}#1FD9CKN510Imports*/
/*DataClass*/
var CCFile, CCFolder, CCDisk;
let __Proto;

//*****************************************************
/*CCFile: Data object class*/
//*****************************************************
{
	CCFile=function(appData, disk, item){
		var jaxEnv,app;
		/*#{1FD9E38RQ0Pre*/
		/*}#1FD9E38RQ0Pre*/
		if(!appData){return;}
		JAXDataObj.call(this,appData.jaxEnv);
		this.appData=appData;
		
		//Data attributes:
		this.type = "file";
		this.isFolder = 0;
		this.path = "";
		this.name = "";
		this.baseVersion = 0;
		this.modified = 0;
		this.size = 0;
		this.modifiedTime = 0;
		/*#{1FD9E38RQ0Post*/
		/*}#1FD9E38RQ0Post*/
	};
	__Proto=CCFile.prototype={};
	
	
	/*#{1FD9E38RQ0Functions*/
	/*}#1FD9E38RQ0Functions*/
};

//*****************************************************
/*CCFolder: Data object class*/
//*****************************************************
{
	CCFolder=function(appData, disk, item){
		var jaxEnv,app;
		/*#{1FD9E326S0Pre*/
		/*}#1FD9E326S0Pre*/
		if(!appData){return;}
		JAXDataObj.call(this,appData.jaxEnv);
		this.appData=appData;
		
		//Data attributes:
		this.type = "folder";
		this.isFolder = 1;
		this.name = "";
		this.baseVersion = 0;
		this.modified = 0;
		this.modifiedTime = 0;
		/*#{1FD9E326S0Post*/
		this.folderItem=item;
		this.disk=disk;
		this.name=item.name;
		this.path=item.path;
		this.diskPath=item.diskPath;
		this.modified=item.modified?1:0;
		this.modifiedTime=item.modifiedTime||0;
		/*}#1FD9E326S0Post*/
	};
	__Proto=CCFolder.prototype={};
	
	
	/*#{1FD9E326S0Functions*/
	//------------------------------------------------------------------------
	//得到目录下的项目列表
	__Proto.getSubItems=function(fileSet){
		/*#{1FBS4TI4Q0Code*/
		return this.disk.getSubItems(this.path,fileSet?fileSet:null);
		/*}#1FBS4TI4Q0Code*/
	};
	
	//------------------------------------------------------------------------
	//得到目录下的目录列表
	__Proto.getSubFolders=function(){
		/*#{1FBTKC9RB0Code*/
		return this.disk.getSubFolders(this.path);
		/*}#1FBTKC9RB0Code*/
	};
	/*}#1FD9E326S0Functions*/
};

//*****************************************************
/*CCDisk: Data object class*/
//*****************************************************
{
	CCDisk=function(appData, diskObj, diskName){
		var jaxEnv,app;
		/*#{1FD9DNECB0Pre*/
		/*}#1FD9DNECB0Pre*/
		if(!appData){return;}
		JAXDataObj.call(this,appData.jaxEnv);
		this.appData=appData;
		
		//Data attributes:
		this.type = "disk";
		this.name = diskName;
		this.diskId = "";
		this.baseVersion = 0;
		this.modified = 0;
		this.modifiedTime = 0;
		/*#{1FD9DNECB0Post*/
		this.diskObj=diskObj;
		this.path="";
		this.diskPath=diskName;
		/*}#1FD9DNECB0Post*/
	};
	__Proto=CCDisk.prototype={};
	
	
	/*#{1FD9DNECB0Functions*/
	//------------------------------------------------------------------------
	//得到指定路径下的文件夹列表
	__Proto.getSubFolders=function(path){
		/*#{1FBTJMJG80Code*/
		let disk=this.diskObj;
		path=path?path:"";
		return disk.getEntries(path).then(list => {
			var dirList=[],item;
			for(item of list){
				item.disk=disk;
				item.path=path?(path+"/"+item.name):item.name;
				item.diskPath=disk.name+":"+item.path;
				if(item.dir){
					dirList.push(new CCFolder(app.appData,this,item));
				}
			}
			dirList.sort((v1,v2)=>{
				return v1.name>v2.name?1:(v1.name<v2.name?-1:0)
			});
			return dirList;
		});
		/*}#1FBTJMJG80Code*/
	};
	
	//------------------------------------------------------------------------
	//得到指定路径下的项目列表
	__Proto.getSubItems=function(path, fileSet){
		/*#{1FBS4QOIB3Code*/
		let disk=this.diskObj;
		//处理单参数fileSet:
		if(path instanceof Set){
			fileSet=path;
			path="";
		}
		path=path?path:"";
		return disk.getEntries(path).then(list => {
			var dirList=[],item;
			for(item of list){
				if(fileSet && !fileSet.has(item.name)){
					continue;
				}
				item.disk=disk;
				item.path=path?(path+"/"+item.name):item.name;
				item.diskPath=disk.name+":"+item.path;
				if(item.dir){
					dirList.push(new CCFolder(app.appData,this,item));
				}else{
					dirList.push(new CCFile(app.appData,this,item));
				}
			}
			dirList.sort((v1,v2)=>{
				if(v1.isFolder && !v2.isFolder) return -1;
				if(!v1.isFolder && v2.isFolder) return 1;
				return v1.name>v2.name?1:(v1.name<v2.name?-1:0)
			});
			return dirList;
		});
		/*}#1FBS4QOIB3Code*/
	};
	
	var diskMap={};
	var app=null;
	
	//------------------------------------------------------------------------
	//初始化系统
	CCDisk.init=function(app_){
		if(app){
			throw "Disk system is already inited!";
		}
		app=app_;
		return JAXDisk.init();
	};
	
	//------------------------------------------------------------------------
	//得到一个disk列表:
	CCDisk.getDiskList=function(){
		return new Promise((resolve, reject) => {
			var disks,name,list=[];
			disks=JAXDisk.getDisks();
			for(name of disks){
				list.push(name);
			}
			resolve(list);
		});
	};
	
	//------------------------------------------------------------------------
	//得到一个disk对象
	CCDisk.getDisk=function(name){
		let disk;
		disk=diskMap[name];
		if(disk){
			return new Promise((resolve,reject)=>{resolve(disk);});
		}
		return JAXDisk.openDisk(name,0).then(diskObj=>{
			if(diskObj) {
				disk=new CCDisk(app.appData,diskObj,name);
				diskMap[name] = disk;
			}
			return disk;
		});
	};
	
	//------------------------------------------------------------------------
	//添加一个目录
	__Proto.addNewFolder=function(path,name){
		let disk=this.diskObj;
		let self=this;
		if(!name){
			name=JAXEnv.getFileName(path);
		}
		return disk.isExist(path).then(exist=>{
			if(exist){
				throw("Path is already existed!");
			}
			return disk.newDir(path).then(obj=>{
				var time;
				time=Date.now();
				if(obj){
					obj={};
					obj.name=name;
					obj.disk=self;
					obj.path=path;
					obj.diskPath=self.name+":"+path;
					obj.createTime=time;
					obj.modifyTime=time;
					return new CCFolder(app.appData,self,obj);
				}
				throw("Add new folder error.");
			});
		});
	};
	
	//------------------------------------------------------------------------
	//检查一组文件是不是有存在,返回一个数组，包含存在的路径
	__Proto.checkFilesExist=function(pathes){
		let disk,pList,eList,i,n;
		
		function checkOne(path){
			return disk.isExist(path).then(exist=>{
				if(exist){
					eList.push(path);
				}
			});
		}
		
		disk=this.diskObj;
		pList=[];eList=[];
		n=pathes.length;
		for(i=0;i<n;i++){
			pList.push(checkOne(pathes[i]));
		}
		return Promise.all(pList).then(()=>{
			return eList
		});
	};

	//------------------------------------------------------------------------
	//添加一个文件
	__Proto.uploadOneFile=function(path,file,overwrite=1){
		let disk;
		disk=this.diskObj;
		if(overwrite){
			return this.diskObj.saveFile(path,file);
		}else{
			return disk.isExist(path).then(exist=>{
				if(!exist){
					return this.diskObj.saveFile(path,file);
				}
				return;
			});
		}
	};
	
	//------------------------------------------------------------------------
	//删除一组文件:
	__Proto.delItems=function(files){
		let pList,disk,i,n,path;
		disk=this.diskObj;
		pList=[];
		n=files.length;
		for(i=0;i<n;i++){
			path=files[i];
			pList.push(disk.del(path));
		}
		return Promise.allSettled(pList);
	};
	
	//---------------------------------------------------------------------------
	//把指定目录/文件做成Zip:
	__Proto.makeZip=async function (path,items) {
		var disk,self,zipFile;

		disk=this.diskObj;
		self=this;
		async function zipDir(dirPath,zipPath,list){
			let i,n,stub;
			zipFile.folder(zipPath);
			if(!list){
				list=await disk.getEntries(dirPath);
			}
			n=list.length;
			for(i=0;i<n;i++){
				stub=list[i];
				if(stub.dir){
					await zipDir(JAXEnv.genFilePath(dirPath,stub.name),JAXEnv.genFilePath(zipPath,stub.name));
				}else{
					let fileData;
					fileData=await disk.loadFile(JAXEnv.genFilePath(dirPath,stub.name));
					if(fileData) {
						zipFile.file(JAXEnv.genFilePath(zipPath, stub.name), fileData);
					}
				}
			}
		}

		zipFile=new JSZip();
		return zipDir(path,"",items).then(()=>{
			return zipFile.generateAsync({type : "uint8array"});
		});
	};
	
	//------------------------------------------------------------------------
	//把zip文件展开到指定目录里:
	__Proto.extractZip=async function(basePath,zipFile,dirZipName=0){
		var self,zipDir,zipDirs,zipName,disk;
		self=this;
		disk=this.diskObj;
		zipDirs=[];
		zipName=zipFile.name;
		{
			let pos;
			pos=zipName.lastIndexOf(".");
			if(pos>0){
				zipName=zipName.substring(0,pos);
			}
		}
		if(dirZipName){
			zipDir=basePath+(basePath?"/":"")+zipName;
		}else{
			zipDir=basePath;
		}

		async function doFiles(list){
			let filePath,fileObj,i,n,path,zipObj;
			n=list.length;
			for(i=0;i<n;i++){
				path=list[i].path;
				zipObj=list[i].zipObj;
				filePath=JAXEnv.genFilePath(zipDir,path);
				await zipObj.async("uint8array").then((buf)=>{
					return disk.saveFile(filePath,buf);
				});
			}
			return true;
		}

		async function doDirs(list){
			let i,n,path;
			n=list.length;
			for(i=0;i<n;i++){
				path=list[i];
				await disk.newDir(path);
			}
			return true;
		}

		return zipFile.arrayBuffer().then(buf=>{
			return JSZip.loadAsync(buf).then(zip=>{
				let list=[];
				zip.forEach((path,zipObj)=>{
					console.log("File in zip: "+path);
					if(zipObj.dir){
						let dirPath;
						dirPath=JAXEnv.genFilePath(zipDir,path);
						zipDirs.push(dirPath);
					}else{
						let filePath,fileObj;
						list.push({path:path,zipObj:zipObj});
					}
				});
				return doFiles(list).then(()=>{
					return doDirs(zipDirs);
				});
			});
		});
	};
	/*}#1FD9DNECB0Functions*/
};

/*#{1FD9CKN510ExCodes*/
/*}#1FD9CKN510ExCodes*/
export {CCFile,CCFolder,CCDisk};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"jaxId": "1FD9CKN510", "def": "CdyFileDataClass", 
//			"attrs": {"fileName":"\"CCDisk\"","description":"\"\""}, 
//			"classObjs": {
//				"name": "classObjs", "type": "object", "def": "CdyDocObj", "jaxId": "1FD9CKN511", 
//				"attrs": {
//					"CCFile": {
//						"type": "object", "def": "CdyDataClass", "name": "CCFile", "tip": "", "jaxId": "1FD9E38RQ0", 
//						"attrs": {}, 
//						"args": {
//							"name": "Arguments", "type": "object", "def": "ClassObjArgObj", "jaxId": "1FD9E83GE0", 
//							"attrs": {
//								"superClass": "\"JAXDataObj\"", 
//								"disk": {"type":"auto","valText":"null","info":null,"tip":null}, 
//								"item": {"type":"auto","valText":"null","info":null,"tip":null}
//							}
//						}, 
//						"pptsObj": {
//							"name": "Properties", "type": "object", "def": "ClassObjPptObj", "jaxId": "1FD9E83GE1", 
//							"attrs": {
//								"type": {
//									"type": "string", "valText": "\"file\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"isFolder": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"path": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"name": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"baseVersion": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"modified": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"size": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"modifiedTime": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}
//							}
//						}, 
//						"funcsObj": {"jaxId":"1FD9E83GE2","funcs":[]}, 
//						"mockObjs": {
//							"name": "Mockups", "type": "object", "def": "CdyDocObj", "jaxId": "1FD9E83GE3", 
//							"attrs": {}
//						}
//					}, 
//					"CCFolder": {
//						"type": "object", "def": "CdyDataClass", "name": "CCFolder", "tip": "", "jaxId": "1FD9E326S0", 
//						"attrs": {}, 
//						"args": {
//							"name": "Arguments", "type": "object", "def": "ClassObjArgObj", "jaxId": "1FD9E83GE4", 
//							"attrs": {
//								"superClass": "\"JAXDataObj\"", 
//								"disk": {"type":"auto","valText":"null","info":null,"tip":null}, 
//								"item": {"type":"auto","valText":"null","info":null,"tip":null}
//							}
//						}, 
//						"pptsObj": {
//							"name": "Properties", "type": "object", "def": "ClassObjPptObj", "jaxId": "1FD9E83GE5", 
//							"attrs": {
//								"type": {
//									"type": "string", "valText": "\"folder\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"isFolder": {"type":"int","valText":"1","initVal":"","info":null,"tip":null}, 
//								"name": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"baseVersion": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"modified": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"modifiedTime": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}
//							}
//						}, 
//						"funcsObj": {"jaxId":"1FD9E83GE6","funcs":[]}, 
//						"mockObjs": {
//							"name": "Mockups", "type": "object", "def": "CdyDocObj", "jaxId": "1FD9E83GE7", 
//							"attrs": {}
//						}
//					}, 
//					"CCDisk": {
//						"type": "object", "def": "CdyDataClass", "name": "CCDisk", "tip": "", "jaxId": "1FD9DNECB0", 
//						"attrs": {}, 
//						"args": {
//							"name": "Arguments", "type": "object", "def": "ClassObjArgObj", "jaxId": "1FD9DSUG50", 
//							"attrs": {
//								"superClass": "\"JAXDataObj\"", 
//								"diskObj": {"type":"auto","valText":"null","info":null,"tip":null}, 
//								"diskName": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}
//							}
//						}, 
//						"pptsObj": {
//							"name": "Properties", "type": "object", "def": "ClassObjPptObj", "jaxId": "1FD9DSUG51", 
//							"attrs": {
//								"type": {
//									"type": "string", "valText": "\"disk\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"name": {
//									"type": "string", "valText": "#diskName", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"diskId": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"baseVersion": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"modified": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"modifiedTime": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}
//							}
//						}, 
//						"funcsObj": {"jaxId":"1FD9DSUG52","funcs":[]}, 
//						"mockObjs": {
//							"name": "Mockups", "type": "object", "def": "CdyDocObj", "jaxId": "1FD9DSUG53", 
//							"attrs": {}
//						}
//					}
//				}
//			}
//		}/*Doc}#*/;
//	}