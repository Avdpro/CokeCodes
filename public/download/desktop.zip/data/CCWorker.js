//Auto genterated by Cody
import {$V} from "/jaxweb/lib/JAXEnv.js"
/*#{1FD9FKBJE0Imports*/
import {Store, get, set, del, clear, keys, drop} from "/jaxweb/extern/idb-keyval.js"
import {JAXDisk} from "/jaxweb/lib/JAXDisk.js"
/*}#1FD9FKBJE0Imports*/
/*自定义数据类*/
var CCWorker;
let __Proto;

//*****************************************************
/*CCWorker: Data object class*/
//*****************************************************
{
	CCWorker=function(appData){
		var jaxEnv,app;
		/*#{1FD9FKIR00Pre*/
		/*}#1FD9FKIR00Pre*/
		if(!appData){return;}
		JAXDataObj.call(this,appData.jaxEnv);
		this.appData=appData;
		
		//Data attributes:
		/*#{1FD9FKIR00Post*/
		/*}#1FD9FKIR00Post*/
	};
	__Proto=CCWorker.prototype={};
	
	
	/*#{1FD9FKIR00Functions*/
	//------------------------------------------------------------------------
	//检查当前是否正确安装了ServiceWorker:
	CCWorker.checkWorker=async function(version){
		//TODO: Code this:
		let reg,swObj,store,scope;
		scope=CCWorker.diskPath?"/jaxweb/disks/":"/jaxweb/";
		reg=await navigator.serviceWorker.getRegistration(scope);
		if(!reg){
			return false;
		}
		if(version>0){
			store = new Store('JAXSys', "ServiceWorker");
			return get("version", store).then(ver=>{
				return ver>version;
			});
		}
		return true;
	};
	
	//------------------------------------------------------------------------
	//检查当前的工具磁盘:
	CCWorker.checkLibs=async function(){
		let text,vo,diskName;
		let libs={};
		async function checkDisk(diskName){
			let disk;
			disk=await JAXDisk.openDisk(diskName);
			if(disk){
				text=await disk.loadText("disk.json");
				try{
					vo=JSON.parse(text);
					libs[diskName]=vo;
				}catch(e){
					libs[diskName]=null;
				}
			}else{
				libs[diskName]=null;
			}
		}
		await checkDisk("jaxlib");//JAX基础库
		await checkDisk("jaxext");//外部需求
		await checkDisk("desktop");//离线桌面
		await checkDisk("diskit");//文件浏览器
		await checkDisk("ccedit");//代码编辑器
		await checkDisk("cody");//App/Web开发编辑器
		return libs;
	};
	
	//------------------------------------------------------------------------
	//安装ServiceWorker
	CCWorker.installWorker=async function(wokerName,version){
		return navigator.serviceWorker.register('../JAXDiskSW.js',{scope:'/jaxweb/disks/'}).then(()=>{
			console.log("JAXDisk SW registered!");
			if(version>0){
				store = new Store('JAXSys', "ServiceWorker");
				return set("version", version, store).then(ver=>{
					return true;
				})
			}
			return true;
		}).catch(()=>{
			return false;
		});
	};
	
	//------------------------------------------------------------------------
	//升级ServiceWorker:
	CCWorker.updateWorker=async function(workerName,version){
		//TODO: Code this:
	};
	/*}#1FD9FKIR00Functions*/
};

/*#{1FD9FKBJE0ExCodes*/
/*}#1FD9FKBJE0ExCodes*/
export {CCWorker};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"jaxId": "1FD9FKBJE0", "def": "CdyFileDataClass", 
//			"attrs": {"fileName":"\"CCWorker\"","description":"\"\""}, 
//			"classObjs": {
//				"name": "classObjs", "type": "object", "def": "CdyDocObj", "jaxId": "1FD9FKBJE1", 
//				"attrs": {
//					"CCWorker": {
//						"type": "object", "def": "CdyDataClass", "name": "CCWorker", "tip": "", "jaxId": "1FD9FKIR00", 
//						"attrs": {}, 
//						"args": {
//							"name": "Arguments", "type": "object", "def": "ClassObjArgObj", "jaxId": "1FD9FLQ210", 
//							"attrs": {"superClass":"\"JAXDataObj\""}
//						}, 
//						"pptsObj": {
//							"name": "Properties", "type": "object", "def": "ClassObjPptObj", "jaxId": "1FD9FLQ211", 
//							"attrs": {}
//						}, 
//						"funcsObj": {"jaxId":"1FD9FLQ212","funcs":[]}, 
//						"mockObjs": {
//							"name": "Mockups", "type": "object", "def": "CdyDocObj", "jaxId": "1FD9FLQ213", 
//							"attrs": {}
//						}
//					}
//				}
//			}
//		}/*Doc}#*/;
//	}