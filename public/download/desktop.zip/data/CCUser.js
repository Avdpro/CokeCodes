//Auto genterated by Cody
import {JAXEnv,$JXV,$V} from "/jaxweb/lib/JAXEnv.js"
import {JAXDataObj} from "/jaxweb/lib/JAXDataObj.js"
/*#{1FDRQS4JQ0Imports*/
/*}#1FDRQS4JQ0Imports*/
/*DataClass*/
var CCUser;
let __Proto;

//*****************************************************
/*CCUser: Data object class*/
//*****************************************************
{
	CCUser=function(appData){
		var jaxEnv,app;
		/*#{1FDRQS9PM0Pre*/
		/*}#1FDRQS9PM0Pre*/
		if(!appData){return;}
		JAXDataObj.call(this,appData.jaxEnv);
		this.appData=appData;
		
		//Data attributes:
		this.userId = "";
		this.name = "";
		this.email = "";
		this.photo = "";
		this.rank = "";
		this.loginTime = 0;
		this.points = 0;
		this.coins = 0;
		this.rankExpire = 0;
		this.emailVarify = 0;
		/*#{1FDRQS9PM0Post*/
		/*}#1FDRQS9PM0Post*/
	};
	__Proto=CCUser.prototype={};
	
	
	/*#{1FDRQS9PM0Functions*/
	//------------------------------------------------------------------------
	//从VO读取登录信息:
	__Proto.loadLoginInfo=function(vo){
		/*#{1FBS3S1RN3Code*/
		this.userId=vo.userId||"";
		this.name=vo.name||"Guest";
		this.toke=vo.token||"";
		this.tokenExpire=vo.tokenExpire||0;
		this.photo=vo.photo;
		this.email=vo.email;
		this.emailVarify=vo.emailVarify;
		this.rank=vo.rank;
		this.rankExpire=vo.rankExpire;
		this.points=vo.points||0;
		this.coins=vo.coins||0;
		/*}#1FBS3S1RN3Code*/
	};
	/*}#1FDRQS9PM0Functions*/
};

/*#{1FDRQS4JQ0ExCodes*/
/*}#1FDRQS4JQ0ExCodes*/
export {CCUser};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"jaxId": "1FDRQS4JQ0", "def": "CdyFileDataClass", 
//			"attrs": {"fileName":"\"CCUser\"","description":"\"\""}, 
//			"classObjs": {
//				"name": "classObjs", "type": "object", "def": "CdyDocObj", "jaxId": "1FDRQS4JQ1", 
//				"attrs": {
//					"CCUser": {
//						"type": "object", "def": "CdyDataClass", "name": "CCUser", "tip": "", "jaxId": "1FDRQS9PM0", 
//						"attrs": {}, 
//						"args": {
//							"name": "Arguments", "type": "object", "def": "ClassObjArgObj", "jaxId": "1FDSCU9GV0", 
//							"attrs": {"superClass":"\"JAXDataObj\""}
//						}, 
//						"pptsObj": {
//							"name": "Properties", "type": "object", "def": "ClassObjPptObj", "jaxId": "1FDSCU9GV1", 
//							"attrs": {
//								"userId": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"name": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"email": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"photo": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"rank": {
//									"type": "string", "valText": "\"\"", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"loginTime": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"points": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"coins": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"rankExpire": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}, 
//								"emailVarify": {"type":"int","valText":"0","initVal":"","info":null,"tip":null}
//							}
//						}, 
//						"funcsObj": {"jaxId":"1FDSCU9GV2","funcs":[]}, 
//						"mockObjs": {
//							"name": "Mockups", "type": "object", "def": "CdyDocObj", "jaxId": "1FDSCU9GV3", 
//							"attrs": {}
//						}
//					}
//				}
//			}
//		}/*Doc}#*/;
//	}