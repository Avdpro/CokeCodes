//Auto genterated by Cody
/*App的多语言文本库文件*/
//----------------------------------------------------------------------------
/*Object for text lib*/
var textLib={
	EN:
	{
	},
	CN:
	{
	}

};

export {textLib};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"jaxId": "1FD92U5O90", "def": "CdyFileTextLib", 
//			"attrs": {
//				"EN": {
//					"name": "EN", "type": "object", "def": "CdyLanguage", "jaxId": "1FD92U5O91", 
//					"attrs": {}
//				}, 
//				"CN": {
//					"name": "CN", "type": "object", "def": "CdyLanguage", "jaxId": "1FD92U5O92", 
//					"attrs": {}
//				}
//			}, 
//			"textLib": {
//				"name": "textLib", "type": "object", "def": "CdyTextLib", "jaxId": "1FD92U5O93", 
//				"attrs": {}
//			}
//		}/*Doc}#*/;
//	}