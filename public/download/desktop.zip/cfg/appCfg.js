//Auto genterated by Cody
/*App的基础配置文件文件*/

/*#{1FD92U5O70ExImports*/
/*}#1FD92U5O70ExImports*/
//----------------------------------------------------------------------------
/*VO Object*/
var appCfg={
	"txtSize": {
		"small": 12, "smallMid": 14, "mid": 16, "midder": 18, "big": 20, "bigger": 24, "large": 28, "larger": 32, "huge": 40, "huger": 48, "shuge": 60, "bigMid": 18
	},
	"size": {
		"btnNavi": 32, "userPhoto": 50, "naviBoxH": 50, "titleBoxH": 64, "btnStdH": 32
	},
	"color": {
		"btnStdFace": [30,100,180,1], "btnStdDown": [35,105,200,1], "btnStdGray": [200,200,200,1], "btnStdText": [255,255,255,1], "highLight": [220,240,255,1], 
		"window": [250,250,250,1], "btnDown": [50,147,250,1], "headBG": [82,94,107,1], "headMain": [255,255,255,1], "headSub": [149,165,175,1], "pageBG": [234,234,234,1], 
		"gntBlock": "linear-gradient(to right, rgba(255,255,255,1), 50%, rgba(234,234,234,1))", "gntBlockHead1": "linear-gradient(to right, rgba(220,90,0,1), 50%, rgba(150,100,0,0))", 
		"appBoxBG": [29,156,205,1], "appBoxBGOver": [0,50,100,1], "appBoxBGDown": [29,156,205,1], "appBoxBGGray": [199,212,223,1], "gntBlockHead2": "linear-gradient(to right, rgba(29,156,205,1), 50%, rgba(82,94,167,0))", 
		"gntBlockHead3": "linear-gradient(to right, rgba(82,94,107,1), 50%, rgba(82,94,107,0))", "gntBlockHead4": "linear-gradient(to right, rgba(0,120,40,1), 50%, rgba(0,120,40,0))", 
		"btnQAUp": [148,165,179,1], "btnQADown": [80,90,100,1], "btnQAOver": [100,125,145,1]
	},
	"shortCuts": {
	},
	/*#{1FD92U5O801*/
	/*}#1FD92U5O801*/
};

/*#{1FD92U5O70ExFuncs*/
//Check platform and set shortcut
var userAgent = navigator.userAgent;
var platform = navigator.platform;

var gecko = /gecko\/\d/i.test(userAgent);
var ie_upto10 = /MSIE \d/.test(userAgent);
var ie_11up = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(userAgent);
var edge = /Edge\/(\d+)/.exec(userAgent);
var ie = ie_upto10 || ie_11up || edge;
var ie_version = ie && (ie_upto10 ? document.documentMode || 6 : +(edge || ie_11up)[1]);
var webkit = !edge && /WebKit\//.test(userAgent);
var qtwebkit = webkit && /Qt\/\d+\.\d+/.test(userAgent);
var chrome = !edge && /Chrome\//.test(userAgent);
var presto = /Opera\//.test(userAgent);
var safari = /Apple Computer/.test(navigator.vendor);
var firefox = userAgent.toLowerCase().indexOf('firefox') > -1;
var mac_geMountainLion = /Mac OS X 1\d\D([8-9]|\d\d)\D/.test(userAgent);
var phantom = /PhantomJS/.test(userAgent);

var ios = safari && (/Mobile\/\w+/.test(userAgent) || navigator.maxTouchPoints > 2);
var android = /Android/.test(userAgent);

var mobile = ios || android || /webOS|BlackBerry|Opera Mini|Opera Mobi|IEMobile/i.test(userAgent);
var mac = ios || /Mac/.test(platform);
var chromeOS = /\bCrOS\b/.test(userAgent);
var windows = /win/i.test(platform);

//****************************************************************************
//Device Info:
//****************************************************************************
{
	appCfg.deviceInfo={
		"mac":mac,
		"windows":windows,
		"ios":ios,
		"android":android,
		"safari":safari,
		"chrome":chrome,
		"firefox":firefox,
		"mobile":mobile,
		//TODO: add language etc.
	};
	appCfg.isMobile=mobile||(window.innerWidth<550);
	appCfg.isSafari=safari;
}
/*}#1FD92U5O70ExFuncs*/

export {appCfg};
/*Cody Project Doc*/
//	
//	function $$$prjDoc() {
//		return /*#{Doc*/{
//			"name": "appCfg.js", "type": "object", "def": "CdyFileAppCfg", "jaxId": "1FD92U5O70", 
//			"attrs": {
//				"appCfg": {
//					"name": "appCfg", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD92U5O80", 
//					"attrs": {
//						"txtSize": {
//							"name": "txtSize", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD953NKI0", 
//							"attrs": {
//								"small": {"type":"int","valText":"12","initVal":"","info":null,"tip":null}, 
//								"smallMid": {"type":"int","valText":"14","initVal":"","info":null,"tip":null}, 
//								"mid": {"type":"int","valText":"16","initVal":"","info":null,"tip":null}, 
//								"midder": {"type":"int","valText":"18","initVal":"","info":null,"tip":null}, 
//								"big": {"type":"int","valText":"20","initVal":"","info":null,"tip":null}, 
//								"bigger": {"type":"int","valText":"24","initVal":"","info":null,"tip":null}, 
//								"large": {"type":"int","valText":"28","initVal":"","info":null,"tip":null}, 
//								"larger": {"type":"int","valText":"32","initVal":"","info":null,"tip":null}, 
//								"huge": {"type":"int","valText":"40","initVal":"","info":null,"tip":null}, 
//								"huger": {"type":"int","valText":"48","initVal":"","info":null,"tip":null}, 
//								"shuge": {"type":"int","valText":"60","initVal":"","info":null,"tip":null}, 
//								"bigMid": {"type":"int","valText":"18","initVal":"","info":null,"tip":null}
//							}
//						}, 
//						"size": {
//							"name": "size", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FD953NKI1", 
//							"attrs": {
//								"btnNavi": {"type":"int","valText":"32","initVal":"","info":null,"tip":null}, 
//								"userPhoto": {"type":"int","valText":"50","initVal":"","info":null,"tip":null}, 
//								"naviBoxH": {"type":"int","valText":"50","initVal":"","info":null,"tip":null}, 
//								"titleBoxH": {"type":"int","valText":"64","initVal":"","info":null,"tip":null}, 
//								"btnStdH": {"type":"int","valText":"32","initVal":"","info":null,"tip":null}
//							}
//						}, 
//						"color": {
//							"name": "color", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDAF6F8J0", 
//							"attrs": {
//								"btnStdFace": {
//									"type": "colorRGBA", "valText": "[30,100,180,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"btnStdDown": {
//									"type": "colorRGBA", "valText": "[35,105,200,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"btnStdGray": {
//									"type": "colorRGBA", "valText": "[200,200,200,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"btnStdText": {
//									"type": "colorRGBA", "valText": "[255,255,255,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"highLight": {
//									"type": "colorRGBA", "valText": "[220,240,255,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"window": {
//									"type": "colorRGBA", "valText": "[250,250,250,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"btnDown": {
//									"type": "colorRGBA", "valText": "[50,147,250,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"headBG": {
//									"type": "colorRGBA", "valText": "[82,94,107,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"headMain": {
//									"type": "colorRGBA", "valText": "[255,255,255,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"headSub": {
//									"type": "colorRGBA", "valText": "[149,165,175,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"pageBG": {
//									"type": "colorRGBA", "valText": "[234,234,234,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"gntBlock": {
//									"type": "string", "valText": "\"linear-gradient(to right, rgba(255,255,255,1), 50%, rgba(234,234,234,1))\"", "initVal": "", 
//									"info": null, "tip": "Selected"
//								}, 
//								"gntBlockHead1": {
//									"type": "string", "valText": "\"linear-gradient(to right, rgba(220,90,0,1), 50%, rgba(150,100,0,0))\"", "initVal": "", 
//									"info": null, "tip": "Selected"
//								}, 
//								"appBoxBG": {
//									"type": "colorRGBA", "valText": "[29,156,205,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"appBoxBGOver": {
//									"type": "colorRGBA", "valText": "[0,50,100,1]", "initVal": "", "info": null, 
//									"tip": null
//								}, 
//								"appBoxBGDown": {
//									"type": "colorRGBA", "valText": "[29,156,205,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"appBoxBGGray": {
//									"type": "colorRGBA", "valText": "[199,212,223,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"gntBlockHead2": {
//									"type": "string", "valText": "\"linear-gradient(to right, rgba(29,156,205,1), 50%, rgba(82,94,167,0))\"", "initVal": "", 
//									"info": null, "tip": "Selected"
//								}, 
//								"gntBlockHead3": {
//									"type": "string", "valText": "\"linear-gradient(to right, rgba(82,94,107,1), 50%, rgba(82,94,107,0))\"", "initVal": "", 
//									"info": null, "tip": "Selected"
//								}, 
//								"gntBlockHead4": {
//									"type": "string", "valText": "\"linear-gradient(to right, rgba(0,120,40,1), 50%, rgba(0,120,40,0))\"", "initVal": "", 
//									"info": null, "tip": "Selected"
//								}, 
//								"btnQAUp": {
//									"type": "colorRGBA", "valText": "[148,165,179,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"btnQADown": {
//									"type": "colorRGBA", "valText": "[80,90,100,1]", "initVal": "", 
//									"info": null, "tip": null
//								}, 
//								"btnQAOver": {
//									"type": "colorRGBA", "valText": "[100,125,145,1]", "initVal": "", 
//									"info": null, "tip": null
//								}
//							}
//						}, 
//						"shortCuts": {
//							"name": "shortCuts", "type": "object", "def": "CdyDocObjJSON", "jaxId": "1FDBPCR1F0", 
//							"attrs": {}
//						}
//					}
//				}
//			}
//		}/*Doc}#*/;
//	}