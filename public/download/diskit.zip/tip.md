### Quick tips

#### Concept Demo:
This is CokeCokes file manager **concept demo**. More features and addons incomming.

#### Shortcut keys:
- Copy file(s): `Cmd+C`/`Ctrl+C`
- Paste file(s): `Cmd+V`/`Ctrl+V`
- Delete selected item(s): `Delete`

#### Upload files:
- **Basic**ly, you can upload files by click the upload file button and select files you want to upload. Single zip will be asked if need to be extracted.

- Use **Drag and Drop**: you can drag files and folders directly from your desktop/device (in file manager app like **File Explorer**, **Finder**) and drop into **Diskit** file list. 

- Use **Copy and Paste**: you can copy files and folders in your desktop/device (in file manager app like **File Explorer**, **Finder**) and paste into **Diskit** file list. 

#### Open file:
Double click on file to open it. Code files will be opened with CCEditor. Markdown fils will be opened with MDView tool. Html and other file will open in new browser tab(window). 


